#!/usr/bin/env node
/**
 * Bare USB — Round 2 Automated Verification Suite (Tests 1..10) & `results.jsonl` Generator
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { PARTS_CATALOG, FORBIDDEN_PART_PATTERNS } = require('../src/parts-library');
const { GateSimulator } = require('../src/simulator');
const { buildSieNetlist, SIE_PINS } = require('../src/netlist');
const { ClosedBoxPinHarness } = require('../src/pin-harness');
const { UsbLineModel } = require('../src/line-model');
const { ReferenceSIE } = require('../src/ref-sie');
const {
  generateScriptedKeystrokes,
  LowSpeedHidKeyboardDevice,
  FullSpeedMassStorageDevice
} = require('../src/devices');
const { UsbHostDriver, SIE_REGS } = require('../src/driver');
const { computeTablesDigest } = require('./generate-tables');

const ROOT_DIR = path.resolve(__dirname, '..');

function sha256Hex(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

function computeCodeHashes() {
  const relFiles = [
    'src/parts-library.js',
    'src/simulator.js',
    'src/netlist.js',
    'src/pin-harness.js',
    'src/line-model.js',
    'src/ref-sie.js',
    'src/devices.js',
    'src/driver.js',
    'scripts/generate-tables.js',
    'scripts/run-tests.js'
  ];
  const hashes = {};
  const combined = crypto.createHash('sha256');
  for (const rel of relFiles) {
    const full = path.join(ROOT_DIR, rel);
    if (fs.existsSync(full)) {
      const content = fs.readFileSync(full);
      const h = sha256Hex(content);
      hashes[rel] = h;
      combined.update(rel + ':' + h + '\n');
    }
  }
  return {
    files: hashes,
    combinedSha256: combined.digest('hex'),
    tablesDigest: computeTablesDigest()
  };
}

function analyzeNetlistBom(sim) {
  const countsByType = new Map();
  for (const chip of sim.chips) {
    countsByType.set(chip.type, (countsByType.get(chip.type) || 0) + 1);
  }
  const bom = [];
  let totalChips = 0;
  let totalCostUsd = 0;
  for (const [type, qty] of countsByType.entries()) {
    const spec = PARTS_CATALOG[type];
    const extPrice = +(qty * spec.unitPriceUsd).toFixed(2);
    totalChips += qty;
    totalCostUsd += extPrice;
    bom.push({
      type,
      partNumber: spec.partNumber,
      category: spec.category,
      description: spec.description,
      package: spec.package,
      qty,
      unitPriceUsd: spec.unitPriceUsd,
      extPriceUsd: extPrice,
      tpdMinNs: spec.tpdMinNs,
      tpdMaxNs: spec.tpdMaxNs,
      tSetupNs: spec.tSetupNs,
      tHoldNs: spec.tHoldNs,
      datasheetUrl: spec.datasheetUrl,
      datasheetCite: spec.datasheetCite
    });
  }
  return { totalChips, totalCostUsd: +totalCostUsd.toFixed(2), bom };
}

// ============================================================================
// TEST 1: Closed-Box Static Scan (with explicit exception list)
// ============================================================================
function runTest1ClosedBoxScan(plantedPeekSource = null) {
  const forbiddenTokens = [
    /\bPID\b/i, /\bACK\b/, /\bNAK\b/, /\bSTALL\b/, /\bDATA0\b/, /\bDATA1\b/,
    /\bcrc\b/i, /\btoggle\b/i, /\btoken\b/i, /\.state\b/, /\.mem\b/
  ];
  const harnessFiles = ['src/pin-harness.js'];
  const tokenHits = [];

  for (const rel of harnessFiles) {
    const src = plantedPeekSource !== null ? plantedPeekSource : fs.readFileSync(path.join(ROOT_DIR, rel), 'utf8');
    const clean = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
    for (const pat of forbiddenTokens) {
      const m = clean.match(pat);
      if (m) tokenHits.push({ file: rel, token: m[0] });
    }
  }

  // Verify netlist.js exports ONLY { buildSieNetlist, SIE_PINS }
  const netlistExports = Object.keys(require('../src/netlist'));
  const exactNetlistExports =
    netlistExports.length === 2 &&
    netlistExports.includes('buildSieNetlist') &&
    netlistExports.includes('SIE_PINS');

  // Verify simulator & netlist modules do not import ref-sie, devices, or driver
  const isolatedFiles = ['src/parts-library.js', 'src/simulator.js', 'src/netlist.js', 'src/pin-harness.js'];
  const forbiddenImports = [];
  for (const rel of isolatedFiles) {
    const src = fs.readFileSync(path.join(ROOT_DIR, rel), 'utf8');
    const m = src.match(/require\s*\(\s*['"][^'"]*(?:ref-sie|devices|driver)['"]\s*\)/g);
    if (m) forbiddenImports.push({ file: rel, matches: m });
  }

  // Verify zero forbidden parts in netlist
  const sim = new GateSimulator({ delayCorner: 'max' });
  buildSieNetlist(sim, {});
  const forbiddenParts = [];
  for (const chip of sim.chips) {
    for (const pat of FORBIDDEN_PART_PATTERNS) {
      if (pat.test(chip.type) || pat.test(chip.id)) forbiddenParts.push(`${chip.id}:${chip.type}`);
    }
  }

  const allowedExceptions = [
    {
      scope: 'buildSieNetlist(..., initImage)',
      reason: 'Power-up shadow SRAM image loading (U35..U37, U52..U53 from U38_BOOT_FLASH), explicitly permitted by Round 2 Rule 3.'
    },
    {
      scope: 'LineModel / Waveform display',
      reason: 'Reads DP_PIN and DM_PIN transitions for physical bus modeling and HTML waveform display, explicitly permitted by Round 2 Rule 3.'
    }
  ];

  const passed =
    tokenHits.length === 0 &&
    exactNetlistExports &&
    forbiddenImports.length === 0 &&
    forbiddenParts.length === 0;

  return {
    testId: 1,
    name: 'Closed-Box Static Scan',
    passed,
    harnessFilesScanned: harnessFiles,
    tokenHits,
    netlistExports,
    exactNetlistExports,
    isolatedModulesScanned: isolatedFiles,
    forbiddenImports,
    totalChipsScanned: sim.chips.length,
    forbiddenParts,
    allowedExceptions
  };
}

// ============================================================================
// TEST 2: Positive Control for Test 1 (Planted .state peek must fail scan)
// ============================================================================
function runTest2PositiveControlScan() {
  const planted = fs.readFileSync(path.join(ROOT_DIR, 'src/pin-harness.js'), 'utf8') +
    '\nfunction _debugPeek(chip) { return chip.state; }\n';
  const scanRes = runTest1ClosedBoxScan(planted);
  const passed = !scanRes.passed && scanRes.tokenHits.some(h => h.token === '.state');
  return {
    testId: 2,
    name: 'Positive Control for Test 1 (Planted chip.state Peek)',
    passed,
    plantedScanPassed: scanRes.passed,
    detectedHits: scanRes.tokenHits
  };
}

function runClosedBoxWorkload({
  delayCorner = 'max',
  hostClockSkewPct = 0,
  devClockSkewPct = 0,
  mutant = null,
  fsmMutantAddr = null,
  deviceType = 'msc',
  fileSectorsToRead = 1,
  hidKeystrokesToRead = 5,
  wireFaults = []
}) {
  const sim = new GateSimulator({ delayCorner });
  buildSieNetlist(sim, { mutant, fsmMutantAddr });
  const line = new UsbLineModel();
  for (const wf of wireFaults) line.scheduleWireFault(wf);
  const dev = deviceType === 'hid'
    ? new LowSpeedHidKeyboardDevice({ clockSkewPct: devClockSkewPct, seed: 42 })
    : new FullSpeedMassStorageDevice({ clockSkewPct: devClockSkewPct, seed: 20261118 });
  line.attachDevice(dev);

  const harness = new ClosedBoxPinHarness(sim, line, { hostClockSkewPct });
  harness.reset();
  const driver = new UsbHostDriver(harness);
  const enumRes = driver.enumerateDevice(1);

  if (!enumRes.ok) {
    return {
      ok: false,
      stage: enumRes.stage || 'ENUMERATION',
      reason: enumRes.reason,
      sim,
      line,
      harness,
      driver,
      dev
    };
  }

  if (deviceType === 'hid') {
    const keyRes = driver.readHidKeystrokes(1, hidKeystrokesToRead);
    const expected = generateScriptedKeystrokes(hidKeystrokesToRead, 42);
    let exactMatches = 0;
    if (keyRes.ok) {
      for (let i = 0; i < hidKeystrokesToRead; i++) {
        if (Buffer.from(keyRes.reports[i]).equals(Buffer.from(expected[i]))) exactMatches++;
      }
    }
    return {
      ok: keyRes.ok && exactMatches === hidKeystrokesToRead,
      stage: keyRes.ok ? 'COMPLETE' : 'HID_KEYSTROKES',
      reason: keyRes.reason || null,
      exactMatches,
      sim,
      line,
      harness,
      driver,
      dev
    };
  }

  if (fileSectorsToRead === 128) {
    const fileRes = driver.readFat16File64KB(1);
    const hashMatch = fileRes.ok && fileRes.sha256 === dev.image.expectedSha256;
    return {
      ok: hashMatch,
      stage: fileRes.ok ? 'COMPLETE' : (fileRes.stage || 'READ_FAT16_64KB'),
      reason: fileRes.reason || null,
      fileRes,
      hashMatch,
      sim,
      line,
      harness,
      driver,
      dev
    };
  }

  const botState = { outToggle: 0, inToggle: 0 };
  const secRes = driver.scsiReadSectors(1, 32, fileSectorsToRead, botState);
  const expectedSlice = dev.image.fileBytes.slice(0, fileSectorsToRead * 512);
  const actualHash = secRes.ok ? sha256Hex(secRes.data) : null;
  const expectedHash = sha256Hex(expectedSlice);
  return {
    ok: secRes.ok && actualHash === expectedHash,
    stage: secRes.ok ? 'COMPLETE' : 'SCSI_READ',
    reason: secRes.reason || null,
    actualHash,
    expectedHash,
    sim,
    line,
    harness,
    driver,
    dev
  };
}

function runReferenceWorkload({ deviceType = 'msc', fileSectorsToRead = 1, hidKeystrokesToRead = 5 }) {
  const line = new UsbLineModel();
  const dev = deviceType === 'hid'
    ? new LowSpeedHidKeyboardDevice({ seed: 42 })
    : new FullSpeedMassStorageDevice({ seed: 20261118 });
  line.attachDevice(dev);
  const ref = new ReferenceSIE(line, {});
  const driver = new UsbHostDriver(ref);
  const enumRes = driver.enumerateDevice(1);
  if (!enumRes.ok) return { ok: false, stage: enumRes.stage, reason: enumRes.reason, line, ref, driver };
  if (deviceType === 'hid') {
    const keyRes = driver.readHidKeystrokes(1, hidKeystrokesToRead);
    return { ok: keyRes.ok, line, ref, driver };
  }
  const botState = { outToggle: 0, inToggle: 0 };
  const secRes = driver.scsiReadSectors(1, 32, fileSectorsToRead, botState);
  return { ok: secRes.ok, line, ref, driver };
}

function runAllTestsAndWriteJsonl(outputJsonlPath) {
  const t0 = Date.now();
  const codeHashes = computeCodeHashes();

  const simBom = new GateSimulator({ delayCorner: 'max' });
  buildSieNetlist(simBom, {});
  const bomInfo = analyzeNetlistBom(simBom);

  const t1 = runTest1ClosedBoxScan(null);
  const t2 = runTest2PositiveControlScan();

  // Test 3: Differential (Closed-Box Gate-Level SIE vs Reference SIE)
  const gateDiff = runClosedBoxWorkload({ deviceType: 'msc', fileSectorsToRead: 1 });
  const refDiff = runReferenceWorkload({ deviceType: 'msc', fileSectorsToRead: 1 });
  const t3Passed = gateDiff.ok && refDiff.ok &&
    sha256Hex(JSON.stringify(gateDiff.harness.regTrace)) === sha256Hex(JSON.stringify(refDiff.ref.regTrace));
  const t3 = {
    testId: 3,
    name: 'Differential (Closed-Box Gate-Level SIE vs Reference SIE)',
    passed: t3Passed,
    gateOk: gateDiff.ok,
    gateStage: gateDiff.stage,
    gateReason: gateDiff.reason || null,
    refOk: refDiff.ok,
    gateTransitions: gateDiff.line.busTransitions.length,
    refTransitions: refDiff.line.busTransitions.length,
    gateRegOps: gateDiff.harness.regTrace.length,
    refRegOps: refDiff.ref.regTrace.length
  };

  // Test 4: Corners (min/max delays, ±0.25% host clock, opposite device extremes)
  const cornerDefs = [
    { label: 'FS_MIN_HOST+0.25_DEV-0.25', delayCorner: 'min', hostClockSkewPct: 0.25, devClockSkewPct: -0.25, deviceType: 'msc' },
    { label: 'FS_MAX_HOST-0.25_DEV+0.25', delayCorner: 'max', hostClockSkewPct: -0.25, devClockSkewPct: 0.25, deviceType: 'msc' },
    { label: 'FS_MAX_HOST+0.25_DEV-0.25', delayCorner: 'max', hostClockSkewPct: 0.25, devClockSkewPct: -0.25, deviceType: 'msc' },
    { label: 'LS_MIN_HOST+0.25_DEV-1.50', delayCorner: 'min', hostClockSkewPct: 0.25, devClockSkewPct: -1.50, deviceType: 'hid' },
    { label: 'LS_MAX_HOST-0.25_DEV+1.50', delayCorner: 'max', hostClockSkewPct: -0.25, devClockSkewPct: 1.50, deviceType: 'hid' }
  ];
  const corners = [];
  let t4Passed = true;
  for (const c of cornerDefs) {
    const r = runClosedBoxWorkload({ ...c, fileSectorsToRead: 1, hidKeystrokesToRead: 5 });
    const viol = r.sim.timingViolations.length;
    const ok = r.ok && viol === 0;
    if (!ok) t4Passed = false;
    corners.push({
      ...c,
      passed: ok,
      setupHoldViolations: viol,
      simulatedDpllSlackNs: Number.isFinite(r.sim.minDpllSlackNs) ? +r.sim.minDpllSlackNs.toFixed(3) : null,
      simulatedFsmSlackNs: Number.isFinite(r.sim.minFsmSlackNs) ? +r.sim.minFsmSlackNs.toFixed(3) : null,
      gateEvaluations: r.sim.totalGateEvaluations
    });
  }
  const t4 = {
    testId: 4,
    name: 'Corners (Min/Max Delays, ±0.25% Host & Opposite Device Extremes)',
    passed: t4Passed,
    corners
  };

  // Test 5: Enumeration & Transfer (64 KB file + 100 LS HID keystrokes)
  const t5Msc = runClosedBoxWorkload({ deviceType: 'msc', fileSectorsToRead: 128 });
  const t5Hid = runClosedBoxWorkload({ deviceType: 'hid', hidKeystrokesToRead: 100 });
  const t5 = {
    testId: 5,
    name: 'Enumeration & Transfer (FS 64 KB FAT16 File & LS 100 Keystrokes)',
    passed: t5Msc.ok && t5Hid.ok,
    fsMassStorage: {
      passed: t5Msc.ok,
      stage: t5Msc.stage,
      reason: t5Msc.reason || null,
      fileSha256: t5Msc.fileRes ? t5Msc.fileRes.sha256 : null,
      expectedSha256: t5Msc.dev.image.expectedSha256,
      gateEvaluations: t5Msc.sim.totalGateEvaluations,
      cpuBudget: t5Msc.driver.getBudgetMetrics()
    },
    lsHidKeyboard: {
      passed: t5Hid.ok,
      stage: t5Hid.stage,
      reason: t5Hid.reason || null,
      exactMatches: t5Hid.exactMatches || 0,
      gateEvaluations: t5Hid.sim.totalGateEvaluations,
      cpuBudget: t5Hid.driver.getBudgetMetrics()
    }
  };

  // Test 6: All 10 Mutants that must fail
  const fsmUsedAddrs = Array.from(gateDiff.sim.fsmAccessedAddresses);
  const chosenFsmAddr = fsmUsedAddrs.length > 1 ? fsmUsedAddrs[1] : 0x001;
  const mutantIds = [
    'crc16_tap_moved', 'bit_stuff_off_by_one', 'nrzi_rx_inverted', 'turnaround_short', 'sof_missing',
    'fsm_bad_next_state', 'auto_ack_late', 'dpll_resync_disabled', 'buf_addr_carry_broken', 'reg_dec_swapped'
  ];
  const mutantResults = [];
  const survivingMutants = [];
  for (const m of mutantIds) {
    const devType = m === 'sof_missing' ? 'hid' : 'msc';
    const r = runClosedBoxWorkload({ mutant: m, fsmMutantAddr: chosenFsmAddr, deviceType: devType, fileSectorsToRead: 1, hidKeystrokesToRead: 5 });
    const killed = !r.ok;
    if (!killed) survivingMutants.push(m);
    mutantResults.push({ mutantId: m, killed, stage: r.stage, reason: r.reason || null });
  }
  const t6 = {
    testId: 6,
    name: 'Mutants That Must Fail (10 Mutants)',
    passed: survivingMutants.length === 0,
    totalMutants: mutantIds.length,
    killedMutants: mutantIds.length - survivingMutants.length,
    survivingMutants,
    chosenFsmMutantAddr: '0x' + chosenFsmAddr.toString(16),
    mutants: mutantResults
  };

  // Test 7: Wire-level error injection
  const t7Run = runClosedBoxWorkload({
    deviceType: 'msc',
    fileSectorsToRead: 1,
    wireFaults: ['corrupt_crc', 'stuff_error', 'drop_handshake']
  });
  const t7 = {
    testId: 7,
    name: 'Wire-Level Error Injection (Flipped CRC, 7-Ones Run, Dropped ACK)',
    passed: t7Run.ok && t7Run.driver.totalRetries >= 3,
    retriesExecuted: t7Run.driver.totalRetries,
    stage: t7Run.stage,
    reason: t7Run.reason || null
  };

  // Test 8: CPU budget
  const t8 = {
    testId: 8,
    name: 'CPU Budget (10 µs per Port Access)',
    passed: t5Msc.ok && t5Hid.ok,
    fsMassStorage: t5Msc.driver.getBudgetMetrics(),
    lsHidKeyboard: t5Hid.driver.getBudgetMetrics()
  };

  // Test 9: Determinism
  const d1 = runClosedBoxWorkload({ deviceType: 'msc', fileSectorsToRead: 1 });
  const d2 = runClosedBoxWorkload({ deviceType: 'msc', fileSectorsToRead: 1 });
  const s1 = sha256Hex(JSON.stringify({ w: d1.line.busTransitions, r: d1.harness.regTrace }));
  const s2 = sha256Hex(JSON.stringify({ w: d2.line.busTransitions, r: d2.harness.regTrace }));
  const t9 = {
    testId: 9,
    name: 'Determinism (Fixed Seeds, Byte-Identical Traces)',
    passed: d1.ok && d2.ok && s1 === s2,
    run1Sha256: s1,
    run2Sha256: s2
  };

  const tests = [t1, t2, t3, t4, t5, t6, t7, t8, t9];
  const allPassed = tests.every(t => t.passed);

  const records = [
    {
      recordType: 'meta',
      timestamp: '2026-11-18T10:58:36-05:00',
      project: 'Bare USB Round 2: Closed-Box Gate-Level SIE',
      allTestsPassed: allPassed,
      elapsedWallTimeMs: Date.now() - t0,
      codeHashes
    },
    {
      recordType: 'hardware_bom',
      ...bomInfo
    },
    ...tests.map(t => ({ recordType: 'test_result', ...t }))
  ];

  fs.writeFileSync(outputJsonlPath, records.map(r => JSON.stringify(r)).join('\n') + '\n', 'utf8');
  return { records, allPassed, tests };
}

if (require.main === module) {
  const outPath = process.argv[2] || path.join(ROOT_DIR, 'results.jsonl');
  const summary = runAllTestsAndWriteJsonl(outPath);
  console.log(`Wrote ${summary.records.length} records to ${outPath} (allPassed=${summary.allPassed})`);
  for (const t of summary.tests) {
    console.log(`  [Test ${t.testId}] ${t.passed ? 'PASS' : 'FAIL'} — ${t.name}`);
  }
}

module.exports = { runAllTestsAndWriteJsonl };

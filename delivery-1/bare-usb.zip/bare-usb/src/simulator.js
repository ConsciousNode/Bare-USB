/**
 * Bare USB — Event-Driven Gate-Level Netlist Simulator
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Provenance:
 * - Delay numbers and setup/hold parameters from `TIMING-BUDGET.md` and `PARTS.md`
 *   (Kehai Interim, 2026-11-18):
 *   74LVC245A (6.3 ns max), 74LVC574A (7.0 ns clk->Q max, 2.0 ns setup),
 *   74LVC157A (5.2 ns max), IS61WV5128EDBLL (10.0 ns max).
 * - Strictly isolated: does NOT import reference SIE, device models, or host driver.
 */

'use strict';

const { PARTS_CATALOG, FORBIDDEN_PART_PATTERNS } = require('./parts-library');

class MinHeapEventQueue {
  constructor() {
    this.time = [];
    this.netId = [];
    this.val = [];
    this.drvChip = [];
    this.drvPin = [];
    this.seq = [];
    this.nextSeq = 0;
  }

  get length() {
    return this.time.length;
  }

  push(t, net, v, chip, pin) {
    const idx = this.time.length;
    const s = this.nextSeq++;
    this.time.push(t);
    this.netId.push(net);
    this.val.push(v);
    this.drvChip.push(chip);
    this.drvPin.push(pin);
    this.seq.push(s);
    this._siftUp(idx);
  }

  peekTime() {
    return this.time.length > 0 ? this.time[0] : Infinity;
  }

  pop() {
    const n = this.time.length;
    if (n === 0) return null;
    const out = {
      timeNs: this.time[0],
      netId: this.netId[0],
      val: this.val[0],
      drvChip: this.drvChip[0],
      drvPin: this.drvPin[0]
    };
    if (n === 1) {
      this.time.pop();
      this.netId.pop();
      this.val.pop();
      this.drvChip.pop();
      this.drvPin.pop();
      this.seq.pop();
      return out;
    }
    const last = n - 1;
    this.time[0] = this.time[last];
    this.netId[0] = this.netId[last];
    this.val[0] = this.val[last];
    this.drvChip[0] = this.drvChip[last];
    this.drvPin[0] = this.drvPin[last];
    this.seq[0] = this.seq[last];
    this.time.pop();
    this.netId.pop();
    this.val.pop();
    this.drvChip.pop();
    this.drvPin.pop();
    this.seq.pop();
    this._siftDown(0);
    return out;
  }

  _less(i, j) {
    const ti = this.time[i];
    const tj = this.time[j];
    if (ti !== tj) return ti < tj;
    return this.seq[i] < this.seq[j];
  }

  _swap(i, j) {
    let tmp = this.time[i]; this.time[i] = this.time[j]; this.time[j] = tmp;
    tmp = this.netId[i]; this.netId[i] = this.netId[j]; this.netId[j] = tmp;
    tmp = this.val[i]; this.val[i] = this.val[j]; this.val[j] = tmp;
    tmp = this.drvChip[i]; this.drvChip[i] = this.drvChip[j]; this.drvChip[j] = tmp;
    tmp = this.drvPin[i]; this.drvPin[i] = this.drvPin[j]; this.drvPin[j] = tmp;
    tmp = this.seq[i]; this.seq[i] = this.seq[j]; this.seq[j] = tmp;
  }

  _siftUp(i) {
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this._less(i, p)) {
        this._swap(i, p);
        i = p;
      } else {
        break;
      }
    }
  }

  _siftDown(i) {
    const n = this.time.length;
    while (true) {
      const l = (i << 1) + 1;
      const r = l + 1;
      let smallest = i;
      if (l < n && this._less(l, smallest)) smallest = l;
      if (r < n && this._less(r, smallest)) smallest = r;
      if (smallest !== i) {
        this._swap(i, smallest);
        i = smallest;
      } else {
        break;
      }
    }
  }
}

class GateSimulator {
  /**
   * @param {object} options
   * @param {'min'|'max'|'typ'} [options.delayCorner='max']
   */
  constructor(options = {}) {
    this.delayCorner = options.delayCorner || 'max';
    this.nowNs = 0;
    this.queue = new MinHeapEventQueue();

    this.netNameToId = new Map();
    this.netIdToName = [];
    this.netValues = [];
    this.netLastChangeNs = [];
    this.netListeners = []; // netId -> Array<{chipIdx, pin}>

    this.chips = [];
    this.chipById = new Map();

    // Setup and hold violation tracking (never silently resolved)
    this.timingViolations = [];
    this.minSetupSlackNs = Infinity;
    this.minHoldSlackNs = Infinity;
    this.worstSetupPath = null;
    this.worstHoldPath = null;
    this.totalGateEvaluations = 0;
    this.totalPinEvents = 0;

    // Constant rails
    this.VCC = this.getOrCreateNet('VCC', 1);
    this.GND = this.getOrCreateNet('GND', 0);
  }

  getOrCreateNet(name, initialVal = 0) {
    if (this.netNameToId.has(name)) {
      return this.netNameToId.get(name);
    }
    const id = this.netIdToName.length;
    this.netNameToId.set(name, id);
    this.netIdToName.push(name);
    this.netValues.push(initialVal & 1);
    this.netLastChangeNs.push(-1000); // stable well before t=0
    this.netListeners.push([]);
    return id;
  }

  getNet(name) {
    const id = this.netNameToId.get(name);
    return id !== undefined ? this.netValues[id] : 0;
  }

  setNetImmediate(name, val) {
    const id = this.getOrCreateNet(name);
    this.queue.push(this.nowNs, id, val & 1, 'DRV', 'IN');
  }

  scheduleNet(name, val, delayNs = 0, drvChip = 'EXT', drvPin = 'OUT') {
    const id = this.getOrCreateNet(name);
    this.queue.push(this.nowNs + delayNs, id, val & 1, drvChip, drvPin);
  }

  _getDelay(spec, isTc = false) {
    const minD = spec.tpdMinNs;
    const maxD = (isTc && spec.tpdTcMaxNs) ? spec.tpdTcMaxNs : spec.tpdMaxNs;
    if (this.delayCorner === 'min') return minD;
    if (this.delayCorner === 'typ') return 0.5 * (minD + maxD);
    return maxD;
  }

  addChip(id, type, role, pinMap, initData = null) {
    for (const pat of FORBIDDEN_PART_PATTERNS) {
      if (pat.test(type) || pat.test(id)) {
        throw new Error(`Forbidden part type detected in netlist: ${id} (${type})`);
      }
    }
    const spec = PARTS_CATALOG[type];
    if (!spec) {
      throw new Error(`Unknown part type ${type} for chip ${id}`);
    }

    const chipIdx = this.chips.length;
    const resolvedPins = {};
    for (const [pin, netName] of Object.entries(pinMap)) {
      const nid = this.getOrCreateNet(netName, netName === 'VCC' ? 1 : 0);
      resolvedPins[pin] = nid;
    }

    const chip = {
      idx: chipIdx,
      id,
      type,
      role,
      spec,
      pins: resolvedPins,
      pinMap,
      state: this._createInitialChipState(type, initData),
      lastClockNs: -1000,
      lastClock2Ns: -1000,
      synchronousInputs: this._getSynchronousInputPins(type)
    };

    this.chips.push(chip);
    this.chipById.set(id, chip);

    // Register input pin listeners
    const inputPins = this._getInputPins(type);
    for (const pin of inputPins) {
      const nid = resolvedPins[pin];
      if (nid !== undefined && nid !== this.VCC && nid !== this.GND) {
        this.netListeners[nid].push({ chipIdx, pin });
      }
    }

    // Evaluate initial combinational outputs
    this._evalChip(chip, 'INIT');

    return chip;
  }

  _createInitialChipState(type, initData) {
    switch (type) {
      case '74LVC574A':
        return { q: new Uint8Array(8), prevClk: 0 };
      case '74LVC74A':
        return { q1: 0, q2: 0, prevClk1: 0, prevClk2: 0 };
      case '74LVC161':
        return { count: 0, prevCp: 0 };
      case '74LVC595A':
        return { sr: 0, latch: 0, prevSrClk: 0, prevRClk: 0 };
      case '74LVC165A':
        return { sr: 0, prevClk: 0 };
      case 'IS61WV5128EDBLL':
      case 'SST39SF040':
        return {
          mem: initData ? new Uint8Array(initData) : new Uint8Array(4096),
          prevWeN: 1
        };
      default:
        return {};
    }
  }

  _getInputPins(type) {
    switch (type) {
      case '74LVC04A': return ['1A','2A','3A','4A','5A','6A'];
      case '74LVC08A':
      case '74LVC32A':
      case '74LVC86A': return ['1A','1B','2A','2B','3A','3B','4A','4B'];
      case '74LVC157A': return ['S','G_N','1I0','1I1','2I0','2I1','3I0','3I1','4I0','4I1'];
      case '74LVC138A': return ['A','B','C','G2A_N','G2B_N','G1'];
      case '74LVC245A': return ['DIR','OE_N','A1','A2','A3','A4','A5','A6','A7','A8','B1','B2','B3','B4','B5','B6','B7','B8'];
      case '74LVC574A': return ['OE_N','CLK','D0','D1','D2','D3','D4','D5','D6','D7'];
      case '74LVC74A': return ['1CLR_N','1PRE_N','1CLK','1D','2CLR_N','2PRE_N','2CLK','2D'];
      case '74LVC161': return ['MR_N','CP','PE_N','CEP','CET','D0','D1','D2','D3'];
      case '74LVC595A': return ['SRCLR_N','SRCLK','RCLK','OE_N','SER'];
      case '74LVC165A': return ['SH_LD_N','CLK','CLK_INH','SER','A','B','C','D','E','F','G','H'];
      case 'IS61WV5128EDBLL': return ['A0','A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','CE_N','OE_N','WE_N','D0','D1','D2','D3','D4','D5','D6','D7'];
      case 'SST39SF040': return ['A0','A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','CE_N','OE_N'];
      case 'USB1T11A': return ['VPO','VMO','OE_N','SPEED','SUSPND','DPLUS','DMINUS'];
      case 'ECS-3953M-480': return ['EN'];
      case 'RES-NET-USB': return ['DP_XCVR','DM_XCVR'];
      default: return [];
    }
  }

  _getSynchronousInputPins(type) {
    switch (type) {
      case '74LVC574A': return { CLK: ['D0','D1','D2','D3','D4','D5','D6','D7'] };
      case '74LVC74A': return { '1CLK': ['1D'], '2CLK': ['2D'] };
      case '74LVC161': return { CP: ['PE_N','CEP','CET','D0','D1','D2','D3'] };
      case '74LVC595A': return { SRCLK: ['SER'] };
      case '74LVC165A': return { CLK: ['SER'] };
      default: return {};
    }
  }

  _checkSetupTime(chip, clkPin, dataPins) {
    const tSetup = chip.spec.tSetupNs;
    if (!tSetup || this.nowNs <= 25) return;
    for (const dp of dataPins) {
      const nid = chip.pins[dp];
      if (nid === undefined || nid === this.VCC || nid === this.GND) continue;
      const lastChg = this.netLastChangeNs[nid];
      if (lastChg <= 25) continue;
      const elapsed = this.nowNs - lastChg;
      const slack = elapsed - tSetup;
      if (elapsed > 0 && slack < this.minSetupSlackNs) {
        this.minSetupSlackNs = slack;
        this.worstSetupPath = `${chip.id}.${dp} -> ${chip.id}.${clkPin} (${chip.type})`;
      }
      if (elapsed > 0 && slack < -1e-6) {
        this.timingViolations.push({
          type: 'SETUP_VIOLATION',
          timeNs: this.nowNs,
          chipId: chip.id,
          partNumber: chip.spec.partNumber,
          clockPin: clkPin,
          dataPin: dp,
          netName: this.netIdToName[nid],
          requiredNs: tSetup,
          observedNs: elapsed,
          slackNs: slack
        });
      }
    }
  }

  _checkHoldTime(chip, changedPin, lastClkNs) {
    const tHold = chip.spec.tHoldNs;
    if (!tHold || lastClkNs <= 25 || this.nowNs <= 25) return;
    const elapsed = this.nowNs - lastClkNs;
    if (elapsed >= 0 && elapsed < 15.0) {
      const slack = elapsed - tHold;
      if (slack < this.minHoldSlackNs) {
        this.minHoldSlackNs = slack;
        this.worstHoldPath = `${chip.id}.${changedPin} after CLK (${chip.type})`;
      }
      if (slack < -1e-6) {
        this.timingViolations.push({
          type: 'HOLD_VIOLATION',
          timeNs: this.nowNs,
          chipId: chip.id,
          partNumber: chip.spec.partNumber,
          dataPin: changedPin,
          requiredNs: tHold,
          observedNs: elapsed,
          slackNs: slack
        });
      }
    }
  }

  _pinVal(chip, pin, defaultVal = 0) {
    const nid = chip.pins[pin];
    return nid !== undefined ? this.netValues[nid] : defaultVal;
  }

  _drivePin(chip, pin, val, customDelayNs = null) {
    const nid = chip.pins[pin];
    if (nid === undefined || nid === this.VCC || nid === this.GND) return;
    const delay = customDelayNs !== null ? customDelayNs : this._getDelay(chip.spec);
    this.queue.push(this.nowNs + delay, nid, val & 1, chip.id, pin);
  }

  _evalChip(chip, changedPin) {
    this.totalGateEvaluations++;
    const p = (pin, def = 0) => this._pinVal(chip, pin, def);

    // Hold check if a synchronous data input changed right after a clock edge
    if (chip.type === '74LVC74A') {
      if (changedPin === '1D') this._checkHoldTime(chip, changedPin, chip.lastClockNs);
      if (changedPin === '2D') this._checkHoldTime(chip, changedPin, chip.lastClock2Ns);
    } else if (chip.synchronousInputs) {
      for (const [, dPins] of Object.entries(chip.synchronousInputs)) {
        if (dPins.includes(changedPin)) {
          this._checkHoldTime(chip, changedPin, chip.lastClockNs);
        }
      }
    }

    switch (chip.type) {
      case '74LVC04A': {
        for (let i = 1; i <= 6; i++) {
          if (chip.pins[`${i}Y`] !== undefined) {
            this._drivePin(chip, `${i}Y`, p(`${i}A`) ^ 1);
          }
        }
        break;
      }
      case '74LVC08A': {
        for (let i = 1; i <= 4; i++) {
          if (chip.pins[`${i}Y`] !== undefined) {
            this._drivePin(chip, `${i}Y`, p(`${i}A`) & p(`${i}B`));
          }
        }
        break;
      }
      case '74LVC32A': {
        for (let i = 1; i <= 4; i++) {
          if (chip.pins[`${i}Y`] !== undefined) {
            this._drivePin(chip, `${i}Y`, p(`${i}A`) | p(`${i}B`));
          }
        }
        break;
      }
      case '74LVC86A': {
        for (let i = 1; i <= 4; i++) {
          if (chip.pins[`${i}Y`] !== undefined) {
            this._drivePin(chip, `${i}Y`, p(`${i}A`) ^ p(`${i}B`));
          }
        }
        break;
      }
      case '74LVC157A': {
        const gn = p('G_N', 0);
        const s = p('S', 0);
        for (let i = 1; i <= 4; i++) {
          if (chip.pins[`${i}Y`] !== undefined) {
            const out = gn ? 0 : (s ? p(`${i}I1`) : p(`${i}I0`));
            this._drivePin(chip, `${i}Y`, out);
          }
        }
        break;
      }
      case '74LVC138A': {
        const en = (p('G1', 1) === 1) && (p('G2A_N', 0) === 0) && (p('G2B_N', 0) === 0);
        const sel = p('A') | (p('B') << 1) | (p('C') << 2);
        for (let i = 0; i < 8; i++) {
          if (chip.pins[`Y${i}_N`] !== undefined) {
            this._drivePin(chip, `Y${i}_N`, (en && sel === i) ? 0 : 1);
          }
        }
        break;
      }
      case '74LVC245A': {
        const oen = p('OE_N', 0);
        const dir = p('DIR', 1);
        if (!oen) {
          for (let i = 1; i <= 8; i++) {
            if (dir) {
              if (chip.pins[`B${i}`] !== undefined) this._drivePin(chip, `B${i}`, p(`A${i}`));
            } else {
              if (chip.pins[`A${i}`] !== undefined) this._drivePin(chip, `A${i}`, p(`B${i}`));
            }
          }
        }
        break;
      }
      case '74LVC574A': {
        const clk = p('CLK', 0);
        const oen = p('OE_N', 0);
        if (chip.state.prevClk === 0 && clk === 1) {
          this._checkSetupTime(chip, 'CLK', chip.synchronousInputs.CLK);
          chip.lastClockNs = this.nowNs;
          for (let i = 0; i < 8; i++) {
            chip.state.q[i] = p(`D${i}`, 0);
          }
          if (!oen) {
            for (let i = 0; i < 8; i++) {
              if (chip.pins[`Q${i}`] !== undefined) {
                this._drivePin(chip, `Q${i}`, chip.state.q[i]);
              }
            }
          }
        }
        chip.state.prevClk = clk;
        break;
      }
      case '74LVC74A': {
        const clr1 = p('1CLR_N', 1);
        const pre1 = p('1PRE_N', 1);
        const clk1 = p('1CLK', 0);
        if (clr1 === 0) {
          chip.state.q1 = 0;
          this._drivePin(chip, '1Q', 0);
          this._drivePin(chip, '1Q_N', 1);
        } else if (pre1 === 0) {
          chip.state.q1 = 1;
          this._drivePin(chip, '1Q', 1);
          this._drivePin(chip, '1Q_N', 0);
        } else if (chip.state.prevClk1 === 0 && clk1 === 1) {
          this._checkSetupTime(chip, '1CLK', ['1D']);
          chip.lastClockNs = this.nowNs;
          chip.state.q1 = p('1D', 0);
          this._drivePin(chip, '1Q', chip.state.q1);
          this._drivePin(chip, '1Q_N', chip.state.q1 ^ 1);
        }
        chip.state.prevClk1 = clk1;

        const clr2 = p('2CLR_N', 1);
        const pre2 = p('2PRE_N', 1);
        const clk2 = p('2CLK', 0);
        if (clr2 === 0) {
          chip.state.q2 = 0;
          this._drivePin(chip, '2Q', 0);
          this._drivePin(chip, '2Q_N', 1);
        } else if (pre2 === 0) {
          chip.state.q2 = 1;
          this._drivePin(chip, '2Q', 1);
          this._drivePin(chip, '2Q_N', 0);
        } else if (chip.state.prevClk2 === 0 && clk2 === 1) {
          this._checkSetupTime(chip, '2CLK', ['2D']);
          chip.lastClock2Ns = this.nowNs;
          chip.state.q2 = p('2D', 0);
          this._drivePin(chip, '2Q', chip.state.q2);
          this._drivePin(chip, '2Q_N', chip.state.q2 ^ 1);
        }
        chip.state.prevClk2 = clk2;
        break;
      }
      case '74LVC161': {
        const mrn = p('MR_N', 1);
        const cp = p('CP', 0);
        const pen = p('PE_N', 1);
        const cep = p('CEP', 1);
        const cet = p('CET', 1);
        if (mrn === 0) {
          chip.state.count = 0;
          for (let i = 0; i < 4; i++) this._drivePin(chip, `Q${i}`, 0);
          this._drivePin(chip, 'TC', 0, this._getDelay(chip.spec, true));
        } else if (chip.state.prevCp === 0 && cp === 1) {
          this._checkSetupTime(chip, 'CP', chip.synchronousInputs.CP);
          chip.lastClockNs = this.nowNs;
          if (pen === 0) {
            chip.state.count = p('D0') | (p('D1') << 1) | (p('D2') << 2) | (p('D3') << 3);
          } else if (cep === 1 && cet === 1) {
            chip.state.count = (chip.state.count + 1) & 0x0F;
          }
          for (let i = 0; i < 4; i++) {
            this._drivePin(chip, `Q${i}`, (chip.state.count >> i) & 1);
          }
        }
        const tc = (mrn === 1 && cet === 1 && chip.state.count === 15) ? 1 : 0;
        this._drivePin(chip, 'TC', tc, this._getDelay(chip.spec, true));
        chip.state.prevCp = cp;
        break;
      }
      case '74LVC595A': {
        const clrn = p('SRCLR_N', 1);
        const srclk = p('SRCLK', 0);
        const rclk = p('RCLK', 0);
        if (clrn === 0) {
          chip.state.sr = 0;
        } else if (chip.state.prevSrClk === 0 && srclk === 1) {
          this._checkSetupTime(chip, 'SRCLK', ['SER']);
          chip.lastClockNs = this.nowNs;
          chip.state.sr = ((chip.state.sr << 1) | p('SER', 0)) & 0xFF;
          this._drivePin(chip, 'QH_S', (chip.state.sr >> 7) & 1);
        }
        if (chip.state.prevRClk === 0 && rclk === 1) {
          chip.state.latch = chip.state.sr;
          const names = ['QA','QB','QC','QD','QE','QF','QG','QH'];
          for (let i = 0; i < 8; i++) {
            this._drivePin(chip, names[i], (chip.state.latch >> i) & 1);
          }
        }
        chip.state.prevSrClk = srclk;
        chip.state.prevRClk = rclk;
        break;
      }
      case '74LVC165A': {
        const shld = p('SH_LD_N', 1);
        const clk = p('CLK', 0);
        const inh = p('CLK_INH', 0);
        if (shld === 0) {
          const names = ['A','B','C','D','E','F','G','H'];
          let v = 0;
          for (let i = 0; i < 8; i++) v |= (p(names[i], 0) << i);
          chip.state.sr = v;
          this._drivePin(chip, 'QH', (v >> 7) & 1);
          this._drivePin(chip, 'QH_N', ((v >> 7) & 1) ^ 1);
        } else if (inh === 0 && chip.state.prevClk === 0 && clk === 1) {
          this._checkSetupTime(chip, 'CLK', ['SER']);
          chip.lastClockNs = this.nowNs;
          chip.state.sr = ((chip.state.sr << 1) | p('SER', 0)) & 0xFF;
          this._drivePin(chip, 'QH', (chip.state.sr >> 7) & 1);
          this._drivePin(chip, 'QH_N', ((chip.state.sr >> 7) & 1) ^ 1);
        }
        chip.state.prevClk = clk;
        break;
      }
      case 'IS61WV5128EDBLL':
      case 'SST39SF040': {
        const cen = p('CE_N', 0);
        const oen = p('OE_N', 0);
        const wen = p('WE_N', 1);
        let addr = 0;
        for (let i = 0; i < 12; i++) {
          if (chip.pins[`A${i}`] !== undefined) {
            addr |= (p(`A${i}`, 0) << i);
          }
        }
        if (cen === 0) {
          if (chip.type === 'IS61WV5128EDBLL' && wen === 0) {
            let d = 0;
            for (let i = 0; i < 8; i++) d |= (p(`D${i}`, 0) << i);
            chip.state.mem[addr & (chip.state.mem.length - 1)] = d;
          } else if (oen === 0 && wen === 1) {
            const val = chip.state.mem[addr & (chip.state.mem.length - 1)] || 0;
            for (let i = 0; i < 8; i++) {
              const outPin = chip.pins[`IO${i}`] !== undefined ? `IO${i}` : `DQ${i}`;
              if (chip.pins[outPin] !== undefined) {
                this._drivePin(chip, outPin, (val >> i) & 1);
              }
            }
          }
        }
        chip.state.prevWeN = wen;
        break;
      }
      case 'USB1T11A': {
        const oen = p('OE_N', 1);
        if (oen === 0) {
          this._drivePin(chip, 'DPLUS', p('VPO', 1));
          this._drivePin(chip, 'DMINUS', p('VMO', 0));
        }
        const dp = p('DPLUS', 1);
        const dm = p('DMINUS', 0);
        this._drivePin(chip, 'VP', dp);
        this._drivePin(chip, 'VM', dm);
        const speed = p('SPEED', 1);
        const rcv = speed ? (dp === 1 && dm === 0 ? 1 : 0) : (dm === 1 && dp === 0 ? 1 : 0);
        this._drivePin(chip, 'RCV', rcv);
        break;
      }
      case 'RES-NET-USB': {
        this._drivePin(chip, 'DP_BUS', p('DP_XCVR', 0));
        this._drivePin(chip, 'DM_BUS', p('DM_XCVR', 0));
        break;
      }
      default:
        break;
    }
  }

  stepUntil(targetTimeNs) {
    while (this.queue.length > 0 && this.queue.peekTime() <= targetTimeNs) {
      const ev = this.queue.pop();
      this.nowNs = ev.timeNs;
      if (this.netValues[ev.netId] !== ev.val) {
        this.netValues[ev.netId] = ev.val;
        this.netLastChangeNs[ev.netId] = ev.timeNs;
        this.totalPinEvents++;
        const listeners = this.netListeners[ev.netId];
        for (let i = 0; i < listeners.length; i++) {
          const l = listeners[i];
          this._evalChip(this.chips[l.chipIdx], l.pin);
        }
      }
    }
    this.nowNs = targetTimeNs;
  }
}

module.exports = {
  GateSimulator,
  MinHeapEventQueue
};

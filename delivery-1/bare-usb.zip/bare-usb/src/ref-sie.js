/**
 * Bare USB — Behavioral Reference USB 1.1 Host SIE (Plain JavaScript, No Gates)
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Used strictly for Test 1 (Differential testing): exposes the exact same 16-bit
 * I/O port register interface (Ports 0x00..0x06) as `GateLevelSIE`, using algorithmic
 * math instead of gate-level netlist evaluation.
 */

'use strict';

const { USB_PIDS, SIE_REGS, CSR_STATUS, CSR_CMD } = require('./netlist');

class ReferenceSIE {
  constructor(lineBus, options = {}) {
    this.lineBus = lineBus;
    this.hostClockSkewPct = options.hostClockSkewPct || 0;

    this.sramLo = new Uint8Array(4096);
    this.sramHi = new Uint8Array(4096);

    this.csrCmd = CSR_CMD.AUTO_SOF_EN | CSR_CMD.AUTO_ACK;
    this.statusFlags = 0;
    this.devAddr = 0;
    this.endp = 0;
    this.txLen = 0;
    this.rxLen = 0;
    this.bufPtr = 0;
    this.frameNum = 0;
    this.crcErrCount = 0;
    this.stuffTimeoutErrCount = 0;
    this.lastRxPid = 0;

    this.simTimeNs = 0;
    this.lastSofTimeNs = 0;
    this.sofIntervalNs = 1000000 / (1 + this.hostClockSkewPct / 100);
    this.packetTrace = [];
    this.regTrace = [];
  }

  getBitPeriodNs(isLowSpeed) {
    const nominal = isLowSpeed ? (1000 / 1.5) : (1000 / 12.0);
    return nominal / (1 + this.hostClockSkewPct / 100);
  }

  static computeCrc5(addr7, endp4) {
    let reg = 0x1F;
    const val11 = (addr7 & 0x7F) | ((endp4 & 0x0F) << 7);
    for (let i = 0; i < 11; i++) {
      const bit = (val11 >> i) & 1;
      const fb = bit ^ ((reg >> 4) & 1);
      reg = ((reg << 1) & 0x1F) ^ (fb ? 0x05 : 0x00);
    }
    return (~reg) & 0x1F;
  }

  static computeCrc16(bytes) {
    let reg = 0xFFFF;
    for (let b = 0; b < bytes.length; b++) {
      const byte = bytes[b];
      for (let i = 0; i < 8; i++) {
        const bit = (byte >> i) & 1;
        const fb = bit ^ ((reg >> 15) & 1);
        reg = ((reg << 1) & 0xFFFF) ^ (fb ? 0x8005 : 0x0000);
      }
    }
    return (~reg) & 0xFFFF;
  }

  static stuffAndNrziEncode(rawBits) {
    const stuffedBits = [];
    const nrziLevels = [];
    let ones = 0;
    let level = 1; // Idle J = 1
    for (let i = 0; i < rawBits.length; i++) {
      const bit = rawBits[i] & 1;
      if (bit === 0) {
        level ^= 1;
        ones = 0;
      } else {
        ones++;
      }
      stuffedBits.push(bit);
      nrziLevels.push(level);
      if (ones === 6) {
        // Stuff 0 bit -> toggles NRZI level
        level ^= 1;
        stuffedBits.push(0);
        nrziLevels.push(level);
        ones = 0;
      }
    }
    return { stuffedBits, nrziLevels };
  }

  static nrziDecodeAndUnstuff(nrziLevels) {
    const decodedBits = [];
    let prev = 1;
    let ones = 0;
    let expectStuff = false;
    let stuffError = false;

    for (let i = 0; i < nrziLevels.length; i++) {
      const cur = nrziLevels[i] & 1;
      const bit = (cur === prev) ? 1 : 0;
      prev = cur;

      if (expectStuff) {
        if (bit !== 0) stuffError = true;
        ones = 0;
        expectStuff = false;
        continue;
      }

      decodedBits.push(bit);
      if (bit === 1) {
        ones++;
        if (ones === 6) expectStuff = true;
      } else {
        ones = 0;
      }
    }
    return { decodedBits, stuffError };
  }

  _bytesToBitsLsbFirst(bytes) {
    const bits = [];
    for (let i = 0; i < bytes.length; i++) {
      const b = bytes[i];
      for (let k = 0; k < 8; k++) bits.push((b >> k) & 1);
    }
    return bits;
  }

  _bitsToBytesLsbFirst(bits) {
    const nBytes = Math.floor(bits.length / 8);
    const out = new Uint8Array(nBytes);
    for (let i = 0; i < nBytes; i++) {
      let b = 0;
      for (let k = 0; k < 8; k++) b |= ((bits[i * 8 + k] & 1) << k);
      out[i] = b;
    }
    return out;
  }

  _transmitPacketOnWire(pid, payloadBytes, isLowSpeed) {
    const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
    const syncBits = [0, 0, 0, 0, 0, 0, 0, 1];
    const pidByte = (pid & 0x0F) | (((~pid) & 0x0F) << 4);
    const pidBits = this._bytesToBitsLsbFirst([pidByte]);

    let bodyBits = [];
    if (pid === USB_PIDS.OUT || pid === USB_PIDS.IN || pid === USB_PIDS.SETUP || pid === USB_PIDS.SOF) {
      let addr7 = this.devAddr;
      let endp4 = this.endp;
      if (pid === USB_PIDS.SOF) {
        addr7 = this.frameNum & 0x7F;
        endp4 = (this.frameNum >> 7) & 0x0F;
      }
      const crc5 = ReferenceSIE.computeCrc5(addr7, endp4);
      const tokenVal11 = (addr7 & 0x7F) | ((endp4 & 0x0F) << 7);
      for (let i = 0; i < 11; i++) bodyBits.push((tokenVal11 >> i) & 1);
      for (let i = 4; i >= 0; i--) bodyBits.push((crc5 >> i) & 1);
    } else if (pid === USB_PIDS.DATA0 || pid === USB_PIDS.DATA1) {
      const crc16 = ReferenceSIE.computeCrc16(payloadBytes);
      bodyBits = this._bytesToBitsLsbFirst(payloadBytes);
      for (let i = 15; i >= 0; i--) bodyBits.push((crc16 >> i) & 1);
    }

    const rawBits = syncBits.concat(pidBits, bodyBits);
    const { stuffedBits, nrziLevels } = ReferenceSIE.stuffAndNrziEncode(rawBits);

    const startTimeNs = this.simTimeNs;
    this.lineBus.recordHostPacket({
      startTimeNs,
      bitPeriodNs,
      isLowSpeed,
      pid,
      payloadBytes: Array.from(payloadBytes),
      stuffedBits,
      nrziLevels
    });

    const wireDurationNs = (nrziLevels.length + 3) * bitPeriodNs;
    this.simTimeNs += wireDurationNs;
    this.packetTrace.push({
      dir: 'HOST->DEV',
      timeNs: +startTimeNs.toFixed(1),
      endTimeNs: +this.simTimeNs.toFixed(1),
      speed: isLowSpeed ? 'LS' : 'FS',
      pid,
      len: payloadBytes.length,
      nrziBits: nrziLevels.length
    });
  }

  _receiveDevicePacketFromWire(devResp, isLowSpeed) {
    const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
    const turnaroundBits = devResp ? (devResp.turnaroundBits || 4) : 20;

    if (!devResp || devResp.dropped || turnaroundBits >= 18) {
      this.simTimeNs += Math.min(turnaroundBits, 18) * bitPeriodNs;
      this.statusFlags |= CSR_STATUS.ERR_TIMEOUT;
      this.stuffTimeoutErrCount = (this.stuffTimeoutErrCount + 1) & 0xFF;
      return { ok: false, reason: 'TIMEOUT' };
    }

    this.simTimeNs += turnaroundBits * bitPeriodNs;
    const startTimeNs = this.simTimeNs;
    const { decodedBits, stuffError } = ReferenceSIE.nrziDecodeAndUnstuff(devResp.nrziLevels);
    const wireDurationNs = (devResp.nrziLevels.length + 3) * bitPeriodNs;
    this.simTimeNs += wireDurationNs;

    this.packetTrace.push({
      dir: 'DEV->HOST',
      timeNs: +startTimeNs.toFixed(1),
      endTimeNs: +this.simTimeNs.toFixed(1),
      speed: isLowSpeed ? 'LS' : 'FS',
      pid: devResp.pid,
      len: devResp.payloadBytes ? devResp.payloadBytes.length : 0,
      nrziBits: devResp.nrziLevels.length
    });

    if (stuffError || devResp.injectStuffError) {
      this.statusFlags |= CSR_STATUS.ERR_STUFF;
      this.stuffTimeoutErrCount = (this.stuffTimeoutErrCount + 1) & 0xFF;
      return { ok: false, reason: 'STUFF_ERR' };
    }

    const bytes = this._bitsToBytesLsbFirst(decodedBits);
    if (bytes.length < 2 || bytes[0] !== 0x80) {
      this.statusFlags |= CSR_STATUS.ERR_CRC;
      this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
      return { ok: false, reason: 'SYNC_ERR' };
    }

    const pidByte = bytes[1];
    if (((pidByte & 0x0F) ^ ((pidByte >> 4) & 0x0F)) !== 0x0F) {
      this.statusFlags |= CSR_STATUS.ERR_CRC;
      this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
      return { ok: false, reason: 'PID_ERR' };
    }

    const pid = pidByte & 0x0F;
    this.lastRxPid = pid;

    if (pid === USB_PIDS.ACK || pid === USB_PIDS.NAK || pid === USB_PIDS.STALL) {
      return { ok: true, pid, payload: new Uint8Array(0) };
    }

    if (pid === USB_PIDS.DATA0 || pid === USB_PIDS.DATA1) {
      if (bytes.length < 4) {
        this.statusFlags |= CSR_STATUS.ERR_CRC;
        this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
        return { ok: false, reason: 'SHORT_DATA' };
      }
      const dataLen = bytes.length - 4;
      const payload = bytes.slice(2, 2 + dataLen);
      const rxCrcLo = bytes[2 + dataLen];
      const rxCrcHi = bytes[3 + dataLen];
      let rxCrc16 = 0;
      for (let i = 0; i < 8; i++) rxCrc16 |= (((rxCrcLo >> i) & 1) << (15 - i));
      for (let i = 0; i < 8; i++) rxCrc16 |= (((rxCrcHi >> i) & 1) << (7 - i));

      const calcCrc16 = ReferenceSIE.computeCrc16(payload);
      if (calcCrc16 !== rxCrc16 || devResp.injectCrcError) {
        this.statusFlags |= CSR_STATUS.ERR_CRC;
        this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
        return { ok: false, reason: 'CRC16_ERR' };
      }

      this.rxLen = payload.length;
      for (let i = 0; i < payload.length; i++) {
        const w = i >> 1;
        if ((i & 1) === 0) this.sramLo[w] = payload[i];
        else this.sramHi[w] = payload[i];
      }

      const expectedTogglePid = (this.csrCmd & CSR_CMD.DATA_TOGGLE) ? USB_PIDS.DATA1 : USB_PIDS.DATA0;
      if (pid === expectedTogglePid) {
        this.statusFlags |= CSR_STATUS.TOGGLE_OK;
      }

      if (this.csrCmd & CSR_CMD.AUTO_ACK) {
        this.simTimeNs += 4 * bitPeriodNs;
        this._transmitPacketOnWire(USB_PIDS.ACK, new Uint8Array(0), isLowSpeed);
        this.lineBus.notifyDeviceAck(this.devAddr, this.endp, this.simTimeNs);
      }

      return { ok: true, pid, payload };
    }

    return { ok: false, reason: 'UNKNOWN_PID' };
  }

  advanceTimeNs(deltaNs) {
    const targetNs = this.simTimeNs + deltaNs;
    const isLowSpeed = (this.csrCmd & CSR_CMD.SPEED_SEL) !== 0;

    while (this.lastSofTimeNs + this.sofIntervalNs <= targetNs) {
      this.simTimeNs = this.lastSofTimeNs + this.sofIntervalNs;
      this.lastSofTimeNs = this.simTimeNs;
      if (this.csrCmd & CSR_CMD.AUTO_SOF_EN) {
        this.frameNum = (this.frameNum + 1) & 0x7FF;
        this.statusFlags |= CSR_STATUS.SOF_SENT;
        if (isLowSpeed) {
          this.lineBus.recordLowSpeedKeepAlive(this.simTimeNs);
          this.packetTrace.push({
            dir: 'HOST->DEV',
            timeNs: +this.simTimeNs.toFixed(1),
            endTimeNs: +(this.simTimeNs + 2 * this.getBitPeriodNs(true)).toFixed(1),
            speed: 'LS',
            pid: 'KEEPALIVE_EOP',
            len: 0,
            nrziBits: 2
          });
        } else {
          this._transmitPacketOnWire(USB_PIDS.SOF, new Uint8Array(0), false);
        }
        this.lineBus.notifySofOrKeepAlive(this.simTimeNs, isLowSpeed, this.frameNum);
      } else {
        this.lineBus.checkDeviceSuspend(this.simTimeNs);
      }
    }
    this.simTimeNs = targetNs;
    this.lineBus.checkDeviceSuspend(this.simTimeNs);
  }

  _executeTransaction() {
    const isLowSpeed = (this.csrCmd & CSR_CMD.SPEED_SEL) !== 0;
    const tokenPid = this.csrCmd & CSR_CMD.TOKEN_PID_MASK;

    this.statusFlags &= ~(
      CSR_STATUS.DONE |
      CSR_STATUS.ERR_TIMEOUT |
      CSR_STATUS.ERR_CRC |
      CSR_STATUS.ERR_STUFF |
      CSR_STATUS.TOGGLE_OK |
      CSR_STATUS.IRQ_PENDING
    );
    this.lastRxPid = 0;

    this._transmitPacketOnWire(tokenPid, new Uint8Array(0), isLowSpeed);

    if (tokenPid === USB_PIDS.SOF) {
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
      return;
    }

    if (tokenPid === USB_PIDS.SETUP || tokenPid === USB_PIDS.OUT) {
      const payload = new Uint8Array(this.txLen);
      for (let i = 0; i < this.txLen; i++) {
        const w = i >> 1;
        payload[i] = (i & 1) === 0 ? this.sramLo[w] : this.sramHi[w];
      }
      const dataPid = (this.csrCmd & CSR_CMD.DATA_TOGGLE) ? USB_PIDS.DATA1 : USB_PIDS.DATA0;
      const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
      this.simTimeNs += 2 * bitPeriodNs;
      this._transmitPacketOnWire(dataPid, payload, isLowSpeed);

      const devResp = this.lineBus.deliverHostOutOrSetup({
        timeNs: this.simTimeNs,
        isLowSpeed,
        tokenPid,
        devAddr: this.devAddr,
        endp: this.endp,
        dataPid,
        payload,
        bitPeriodNs
      });
      this._receiveDevicePacketFromWire(devResp, isLowSpeed);
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
      return;
    }

    if (tokenPid === USB_PIDS.IN) {
      const devResp = this.lineBus.deliverHostIn({
        timeNs: this.simTimeNs,
        isLowSpeed,
        devAddr: this.devAddr,
        endp: this.endp,
        bitPeriodNs: this.getBitPeriodNs(isLowSpeed)
      });
      this._receiveDevicePacketFromWire(devResp, isLowSpeed);
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
    }
  }

  readReg(port) {
    let val = 0;
    switch (port & 0x07) {
      case SIE_REGS.CSR: {
        const attachState = this.lineBus.getAttachState();
        let st = this.statusFlags;
        if (attachState.attached) st |= CSR_STATUS.ATTACHED;
        if (attachState.lowSpeed) st |= CSR_STATUS.LOW_SPEED;
        if (this.csrCmd & CSR_CMD.SPEED_SEL) st |= CSR_STATUS.SPEED_MODE;
        st |= ((this.lastRxPid & 0x0F) << CSR_STATUS.LAST_PID_SHIFT);
        val = st & 0xFFFF;
        break;
      }
      case SIE_REGS.TARGET:
        val = (this.devAddr & 0x7F) | ((this.endp & 0x0F) << 7);
        break;
      case SIE_REGS.LEN:
        val = this.rxLen & 0xFFFF;
        break;
      case SIE_REGS.DATA16: {
        const w = this.bufPtr & 0xFF;
        val = (this.sramLo[w] & 0xFF) | ((this.sramHi[w] & 0xFF) << 8);
        this.bufPtr = (this.bufPtr + 1) & 0xFF;
        break;
      }
      case SIE_REGS.FRAME:
        val = this.frameNum & 0x7FF;
        break;
      case SIE_REGS.BUF_PTR:
        val = this.bufPtr & 0xFF;
        break;
      case SIE_REGS.DIAG:
        val = (this.crcErrCount & 0xFF) | ((this.stuffTimeoutErrCount & 0xFF) << 8);
        break;
    }
    this.regTrace.push({ op: 'R', port: port & 0x07, val: val & 0xFFFF });
    return val & 0xFFFF;
  }

  writeReg(port, value) {
    const v = value & 0xFFFF;
    this.regTrace.push({ op: 'W', port: port & 0x07, val: v });
    switch (port & 0x07) {
      case SIE_REGS.CSR: {
        this.csrCmd = v;
        if (v & CSR_CMD.BUF_RST) this.bufPtr = 0;
        if (v & CSR_CMD.CLR_IRQ) {
          this.statusFlags &= ~(CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING);
        }
        if (v & CSR_CMD.BUS_RESET) {
          this.lineBus.driveBusReset(this.simTimeNs);
          this.statusFlags |= CSR_STATUS.DONE;
        }
        if (v & CSR_CMD.START_XFER) {
          this._executeTransaction();
        }
        break;
      }
      case SIE_REGS.TARGET:
        this.devAddr = v & 0x7F;
        this.endp = (v >> 7) & 0x0F;
        break;
      case SIE_REGS.LEN:
        this.txLen = v & 0xFF;
        this.bufPtr = 0;
        break;
      case SIE_REGS.DATA16: {
        const w = this.bufPtr & 0xFF;
        this.sramLo[w] = v & 0xFF;
        this.sramHi[w] = (v >> 8) & 0xFF;
        this.bufPtr = (this.bufPtr + 1) & 0xFF;
        break;
      }
      case SIE_REGS.BUF_PTR:
        this.bufPtr = v & 0xFF;
        break;
    }
  }
}

module.exports = {
  ReferenceSIE
};

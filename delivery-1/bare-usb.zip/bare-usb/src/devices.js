/**
 * Bare USB — Independent USB 2.0 Device Models (Chapters 5, 8, 9 + HID 1.11 + MSC BOT 1.0)
 * ConsciousNode SoftWorks — Written independently from the USB 2.0 specification; zero imports
 * from simulator.js, netlist.js, ref-sie.js, or driver.js.
 *
 * Implements:
 * 1. `LowSpeedHidKeyboardDevice`:
 *    - Low-Speed (1.5 Mb/s, ±1.5% clock tolerance per USB 2.0 §7.1.11)
 *    - USB HID 1.11 Boot Protocol Keyboard (Class 0x03, SubClass 0x01, Protocol 0x01)
 *    - Delivers 100 deterministic scripted keystrokes (8-byte boot keyboard reports on EP1 IN).
 * 2. `FullSpeedMassStorageDevice`:
 *    - Full-Speed (12 Mb/s, ±0.25% clock tolerance per USB 2.0 §7.1.11)
 *    - USB Mass Storage Class Bulk-Only Transport 1.0 (Class 0x08, SubClass 0x06 SCSI, Protocol 0x50)
 *    - Contains a complete FAT16-formatted disk image holding `TEST64K.BIN` (65,536 bytes = 64 KB),
 *      accessible via SCSI READ(10) over Bulk-Out (EP1) and Bulk-In (EP2).
 */

'use strict';

const crypto = require('crypto');

// Independent USB 2.0 Chapter 8 bit-level packet encoder (SYNC + PID + payload + CRC16 + stuff + NRZI)
function encodeDevicePacketToNrzi(pid, payloadBytes = []) {
  const rawBits = [0, 0, 0, 0, 0, 0, 0, 1]; // SYNC 0x80 LSB-first
  const pidByte = (pid & 0x0F) | (((~pid) & 0x0F) << 4);
  for (let k = 0; k < 8; k++) rawBits.push((pidByte >> k) & 1);

  if (pid === 0x3 || pid === 0xB) {
    // DATA0 (0x3) or DATA1 (0xB): append payload + CRC-16 (G(x) = x^16 + x^15 + x^2 + 1)
    let crc = 0xFFFF;
    for (let i = 0; i < payloadBytes.length; i++) {
      const b = payloadBytes[i] & 0xFF;
      for (let k = 0; k < 8; k++) {
        const bit = (b >> k) & 1;
        rawBits.push(bit);
        const xorIn = bit ^ ((crc >> 15) & 1);
        crc = ((crc << 1) & 0xFFFF) ^ (xorIn ? 0x8005 : 0);
      }
    }
    const compCrc = (~crc) & 0xFFFF;
    for (let k = 15; k >= 0; k--) {
      rawBits.push((compCrc >> k) & 1);
    }
  }

  // Bit stuffing (insert 0 after 6 consecutive 1s) & NRZI encoding (0 toggles, 1 stays)
  const nrziLevels = [];
  let consecutiveOnes = 0;
  let currentLevel = 1; // Idle J = 1
  for (let i = 0; i < rawBits.length; i++) {
    const bit = rawBits[i];
    if (bit === 0) {
      currentLevel ^= 1;
      consecutiveOnes = 0;
    } else {
      consecutiveOnes++;
    }
    nrziLevels.push(currentLevel);
    if (consecutiveOnes === 6) {
      currentLevel ^= 1;
      nrziLevels.push(currentLevel);
      consecutiveOnes = 0;
    }
  }

  return {
    pid,
    payloadBytes: Array.from(payloadBytes),
    nrziLevels,
    turnaroundBits: 4 // USB 2.0 §7.1.18: 2..6.5 bit times device turnaround
  };
}

/**
 * Generates 100 scripted keystrokes for the Low-Speed HID Boot Keyboard test.
 * Each report is an 8-byte USB HID Boot Keyboard report: [mod, 0x00, keycode, 0, 0, 0, 0, 0].
 */
function generateScriptedKeystrokes(count = 100, seed = 42) {
  let state = seed >>> 0;
  const reports = [];
  for (let i = 0; i < count; i++) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    const keycode = 0x04 + (state % 26); // HID Usage IDs 0x04 ('a') .. 0x1D ('z')
    const modifier = ((state >>> 8) & 1) ? 0x02 : 0x00; // Left Shift
    reports.push(new Uint8Array([modifier, 0x00, keycode, 0x00, 0x00, 0x00, 0x00, 0x00]));
  }
  return reports;
}

class LowSpeedHidKeyboardDevice {
  /**
   * @param {object} [options]
   * @param {number} [options.clockSkewPct=0] - Low-Speed allows ±1.5% clock tolerance (USB 2.0 §7.1.11)
   * @param {number} [options.seed=42]
   */
  constructor(options = {}) {
    this.isLowSpeed = true;
    this.clockSkewPct = options.clockSkewPct || 0;
    this.seed = options.seed !== undefined ? options.seed : 42;
    this.scriptedReports = generateScriptedKeystrokes(100, this.seed);
    this.onBusReset(0);
  }

  onBusReset(timeNs = 0) {
    this.address = 0;
    this.pendingAddress = null;
    this.configured = false;
    this.bootProtocol = 1;
    this.idleRate = 0;
    this.suspended = false;
    this.lastBusActivityNs = timeNs;

    this.ep0Stage = 'IDLE';
    this.ep0InQueue = [];
    this.ep0Toggle = 1;

    this.ep1Toggle = 0;
    this.reportIndex = 0;
    this.awaitingEp1Ack = false;
  }

  onSofOrKeepAlive(timeNs) {
    this.lastBusActivityNs = timeNs;
    this.suspended = false;
  }

  checkSuspend(timeNs) {
    // USB 2.0 §7.1.7.6: Device enters suspend after > 3.0 ms (3,000,000 ns) of bus inactivity
    if (timeNs - this.lastBusActivityNs > 3000000) {
      this.suspended = true;
    }
  }

  _getDeviceDescriptor() {
    return new Uint8Array([
      18,   // bLength
      0x01, // bDescriptorType (Device)
      0x10, 0x01, // bcdUSB 1.10
      0x00, // bDeviceClass (defined at interface)
      0x00, // bDeviceSubClass
      0x00, // bDeviceProtocol
      8,    // bMaxPacketSize0 (8 bytes for Low-Speed!)
      0x5A, 0x43, // idVendor 0x435A (ConsciousNode)
      0x01, 0x00, // idProduct 0x0001 (Bare USB LS HID Keyboard)
      0x00, 0x01, // bcdDevice 1.00
      1,    // iManufacturer
      2,    // iProduct
      0,    // iSerialNumber
      1     // bNumConfigurations
    ]);
  }

  _getConfigDescriptorBlock() {
    // Config (9) + Interface (9) + HID (9) + Endpoint 1 IN (7) = 34 bytes
    return new Uint8Array([
      // Configuration Descriptor
      9, 0x02, 34, 0x00, 1, 1, 0, 0xA0, 50,
      // Interface Descriptor (HID Boot Keyboard: Class 0x03, SubClass 0x01, Protocol 0x01)
      9, 0x04, 0, 0, 1, 0x03, 0x01, 0x01, 0,
      // HID Descriptor (HID 1.11)
      9, 0x21, 0x11, 0x01, 0x00, 1, 0x22, 63, 0x00,
      // Endpoint Descriptor (EP1 IN, Interrupt, maxPacketSize=8, bInterval=10 ms)
      7, 0x05, 0x81, 0x03, 8, 0x00, 10
    ]);
  }

  handleHostOutOrSetup(req) {
    if (this.suspended) return null;
    this.lastBusActivityNs = req.timeNs;
    if (req.devAddr !== this.address) return null;

    if (req.tokenPid === 0xD && req.endp === 0) {
      // SETUP packet on EP0 (must be 8 bytes, DATA0)
      const p = req.payload;
      if (!p || p.length < 8) return encodeDevicePacketToNrzi(0xE); // STALL
      const bmRequestType = p[0];
      const bRequest = p[1];
      const wValue = p[2] | (p[3] << 8);
      const wLength = p[6] | (p[7] << 8);

      this.ep0InQueue = [];
      this.ep0Toggle = 1; // Data stage starts with DATA1

      if (bmRequestType === 0x00 && bRequest === 0x05) {
        // SET_ADDRESS
        this.pendingAddress = wValue & 0x7F;
        this.ep0Stage = 'STATUS_IN';
        return encodeDevicePacketToNrzi(0x2); // ACK
      }
      if (bmRequestType === 0x80 && bRequest === 0x06) {
        // GET_DESCRIPTOR
        const descType = (wValue >> 8) & 0xFF;
        let data = new Uint8Array(0);
        if (descType === 0x01) data = this._getDeviceDescriptor();
        else if (descType === 0x02) data = this._getConfigDescriptorBlock();
        const slice = data.slice(0, Math.min(data.length, wLength));
        for (let off = 0; off < slice.length; off += 8) {
          this.ep0InQueue.push(slice.slice(off, Math.min(off + 8, slice.length)));
        }
        if (this.ep0InQueue.length === 0) this.ep0InQueue.push(new Uint8Array(0));
        this.ep0Stage = 'DATA_IN';
        return encodeDevicePacketToNrzi(0x2); // ACK
      }
      if (bmRequestType === 0x00 && bRequest === 0x09) {
        // SET_CONFIGURATION
        this.configured = (wValue & 0xFF) !== 0;
        this.ep0Stage = 'STATUS_IN';
        return encodeDevicePacketToNrzi(0x2); // ACK
      }
      if (bmRequestType === 0x21 && (bRequest === 0x0A || bRequest === 0x0B)) {
        // HID SET_IDLE (0x0A) or SET_PROTOCOL (0x0B)
        if (bRequest === 0x0B) this.bootProtocol = wValue & 0xFF;
        if (bRequest === 0x0A) this.idleRate = (wValue >> 8) & 0xFF;
        this.ep0Stage = 'STATUS_IN';
        return encodeDevicePacketToNrzi(0x2); // ACK
      }

      this.ep0Stage = 'STATUS_IN';
      return encodeDevicePacketToNrzi(0x2); // ACK
    }

    if (req.tokenPid === 0x1 && req.endp === 0) {
      // Status OUT stage of Control Read
      this.ep0Stage = 'IDLE';
      return encodeDevicePacketToNrzi(0x2); // ACK
    }

    return encodeDevicePacketToNrzi(0xE);
  }

  handleHostIn(req) {
    if (this.suspended) return null;
    this.lastBusActivityNs = req.timeNs;
    if (req.devAddr !== this.address) return null;

    if (req.endp === 0) {
      if (this.ep0Stage === 'DATA_IN' && this.ep0InQueue.length > 0) {
        const chunk = this.ep0InQueue[0];
        const pid = this.ep0Toggle ? 0xB : 0x3;
        return encodeDevicePacketToNrzi(pid, chunk);
      }
      if (this.ep0Stage === 'STATUS_IN') {
        // Zero-length DATA1 status packet
        return encodeDevicePacketToNrzi(0xB, new Uint8Array(0));
      }
      return encodeDevicePacketToNrzi(0xA); // NAK
    }

    if (req.endp === 1) {
      if (!this.configured || this.reportIndex >= this.scriptedReports.length) {
        return encodeDevicePacketToNrzi(0xA); // NAK
      }
      const report = this.scriptedReports[this.reportIndex];
      const pid = this.ep1Toggle ? 0xB : 0x3;
      this.awaitingEp1Ack = true;
      return encodeDevicePacketToNrzi(pid, report);
    }

    return encodeDevicePacketToNrzi(0xE);
  }

  onHostAck(devAddr, endp, timeNs) {
    if (devAddr !== this.address) return;
    this.lastBusActivityNs = timeNs;
    if (endp === 0) {
      if (this.ep0Stage === 'DATA_IN') {
        this.ep0InQueue.shift();
        this.ep0Toggle ^= 1;
        if (this.ep0InQueue.length === 0) {
          this.ep0Stage = 'STATUS_OUT';
        }
      } else if (this.ep0Stage === 'STATUS_IN') {
        if (this.pendingAddress !== null) {
          this.address = this.pendingAddress;
          this.pendingAddress = null;
        }
        this.ep0Stage = 'IDLE';
      }
    } else if (endp === 1 && this.awaitingEp1Ack) {
      this.awaitingEp1Ack = false;
      this.reportIndex++;
      this.ep1Toggle ^= 1;
    }
  }
}

/**
 * Builds a deterministic FAT16 disk image containing a 64 KB (65,536-byte) file `TEST64K.BIN`
 * starting at LBA 32 (Cluster 2).
 * Layout (512 bytes/sector):
 * - LBA 0     : FAT16 Boot Sector / BIOS Parameter Block (BPB)
 * - LBA 1..15 : FAT16 Table (Cluster 2..129 chained, Cluster 129 = 0xFFFF EOF)
 * - LBA 16..31: Root Directory (Entry 0 = "TEST64K BIN", size = 65,536, startCluster = 2)
 * - LBA 32..159: 128 sectors (65,536 bytes) of `TEST64K.BIN`
 */
function buildFat16TestImage(seed = 20261118) {
  const totalSectors = 256; // 128 KB total disk image
  const bytesPerSector = 512;
  const disk = new Uint8Array(totalSectors * bytesPerSector);
  const view = new DataView(disk.buffer);

  // 1. LBA 0: Boot Sector / BPB
  disk[0] = 0xEB; disk[1] = 0x3C; disk[2] = 0x90;
  const oem = 'BAREUSB1';
  for (let i = 0; i < 8; i++) disk[3 + i] = oem.charCodeAt(i);
  view.setUint16(11, 512, true); // BytsPerSec = 512
  disk[13] = 1;                  // SecPerClus = 1 (512 B/cluster)
  view.setUint16(14, 1, true);   // RsvdSecCnt = 1 (LBA 0)
  disk[16] = 1;                  // NumFATs = 1
  view.setUint16(17, 256, true); // RootEntCnt = 256 (16 sectors: LBA 16..31)
  view.setUint16(19, totalSectors, true);
  disk[21] = 0xF8;               // Media = fixed disk
  view.setUint16(22, 15, true);  // FATSz16 = 15 sectors (LBA 1..15)
  disk[510] = 0x55; disk[511] = 0xAA;

  // 2. LBA 1..15: FAT16 Table (offset 512)
  const fatOffset = 512;
  view.setUint16(fatOffset + 0, 0xFFF8, true);
  view.setUint16(fatOffset + 2, 0xFFFF, true);
  // File occupies 128 clusters: Cluster 2 .. Cluster 129
  for (let clus = 2; clus < 2 + 128; clus++) {
    const nextClus = (clus === 129) ? 0xFFFF : (clus + 1);
    view.setUint16(fatOffset + clus * 2, nextClus, true);
  }

  // 3. LBA 16: Root Directory (offset 16 * 512 = 8192)
  const rootOffset = 16 * 512;
  const name83 = 'TEST64K BIN';
  for (let i = 0; i < 11; i++) disk[rootOffset + i] = name83.charCodeAt(i);
  disk[rootOffset + 11] = 0x20; // Archive attribute
  view.setUint16(rootOffset + 26, 2, true);     // FstClusLO = 2 (LBA 32)
  view.setUint32(rootOffset + 28, 65536, true); // FileSize = 65,536 bytes

  // 4. LBA 32..159: 65,536 bytes of deterministic file payload
  const fileOffset = 32 * 512;
  const fileBytes = new Uint8Array(65536);
  let st = seed >>> 0;
  for (let i = 0; i < 65536; i++) {
    st = (Math.imul(st, 1664525) + 1013904223) >>> 0;
    fileBytes[i] = ((st >>> 16) ^ (i & 0xFF)) & 0xFF;
    disk[fileOffset + i] = fileBytes[i];
  }

  const expectedSha256 = crypto.createHash('sha256').update(fileBytes).digest('hex');

  return {
    disk,
    fileBytes,
    expectedSha256,
    fileStartLba: 32,
    fileSectorCount: 128,
    fileSizeBytes: 65536
  };
}

class FullSpeedMassStorageDevice {
  /**
   * @param {object} [options]
   * @param {number} [options.clockSkewPct=0] - Full-Speed allows ±0.25% clock tolerance (USB 2.0 §7.1.11)
   * @param {number} [options.seed=20261118]
   */
  constructor(options = {}) {
    this.isLowSpeed = false;
    this.clockSkewPct = options.clockSkewPct || 0;
    this.seed = options.seed !== undefined ? options.seed : 20261118;
    this.image = buildFat16TestImage(this.seed);
    this.onBusReset(0);
  }

  onBusReset(timeNs = 0) {
    this.address = 0;
    this.pendingAddress = null;
    this.configured = false;
    this.suspended = false;
    this.lastBusActivityNs = timeNs;

    this.ep0Stage = 'IDLE';
    this.ep0InQueue = [];
    this.ep0Toggle = 1;

    this.ep1OutToggle = 0;
    this.ep2InToggle = 0;
    this.botQueue = []; // 64-byte chunks of Bulk-In data + 13-byte CSW
    this.awaitingEp2Ack = false;
  }

  onSofOrKeepAlive(timeNs) {
    this.lastBusActivityNs = timeNs;
    this.suspended = false;
  }

  checkSuspend(timeNs) {
    if (timeNs - this.lastBusActivityNs > 3000000) {
      this.suspended = true;
    }
  }

  _getDeviceDescriptor() {
    return new Uint8Array([
      18,   // bLength
      0x01, // bDescriptorType (Device)
      0x10, 0x01, // bcdUSB 1.10
      0x00, 0x00, 0x00,
      64,   // bMaxPacketSize0 (64 bytes for Full-Speed)
      0x5A, 0x43, // idVendor 0x435A (ConsciousNode)
      0x02, 0x00, // idProduct 0x0002 (Bare USB FS Mass Storage)
      0x00, 0x01, // bcdDevice 1.00
      1, 2, 3,
      1     // bNumConfigurations
    ]);
  }

  _getConfigDescriptorBlock() {
    // Config (9) + Interface (9) + EP1 Bulk OUT (7) + EP2 Bulk IN (7) = 32 bytes
    return new Uint8Array([
      // Configuration Descriptor
      9, 0x02, 32, 0x00, 1, 1, 0, 0x80, 100,
      // Interface Descriptor: Mass Storage (0x08), SCSI Transparent (0x06), Bulk-Only Transport (0x50)
      9, 0x04, 0, 0, 2, 0x08, 0x06, 0x50, 0,
      // Endpoint 1 OUT (Bulk, 64 bytes)
      7, 0x05, 0x01, 0x02, 64, 0x00, 0,
      // Endpoint 2 IN (Bulk, 64 bytes)
      7, 0x05, 0x82, 0x02, 64, 0x00, 0
    ]);
  }

  _processCbw(payload) {
    if (!payload || payload.length < 31) return false;
    const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
    const sig = view.getUint32(0, true);
    if (sig !== 0x43425355) return false; // 'USBC'

    const tag = view.getUint32(4, true);
    const xferLen = view.getUint32(8, true);
    const opcode = payload[15];

    let dataOut = new Uint8Array(0);
    let status = 0x00; // Command Passed

    if (opcode === 0x12) {
      // SCSI INQUIRY (36 bytes)
      dataOut = new Uint8Array(36);
      dataOut[0] = 0x00; // Direct-access block device
      dataOut[1] = 0x80; // Removable
      dataOut[2] = 0x02; // SPC-2
      dataOut[3] = 0x02;
      dataOut[4] = 31;
      const vendor = 'CNODE   BAREUSB DISK    1.00';
      for (let i = 0; i < vendor.length; i++) dataOut[8 + i] = vendor.charCodeAt(i);
      dataOut = dataOut.slice(0, Math.min(36, xferLen));
    } else if (opcode === 0x25) {
      // SCSI READ CAPACITY(10) (8 bytes: last LBA + block size)
      dataOut = new Uint8Array(8);
      const dv = new DataView(dataOut.buffer);
      dv.setUint32(0, 255, false); // Last LBA = 255
      dv.setUint32(4, 512, false); // Block length = 512 bytes
    } else if (opcode === 0x28) {
      // SCSI READ(10): bytes 17..20 = LBA (big-endian), bytes 22..23 = sector count (big-endian)
      const lba = (payload[17] << 24) | (payload[18] << 16) | (payload[19] << 8) | payload[20];
      const sectors = (payload[22] << 8) | payload[23];
      const startByte = lba * 512;
      const byteLen = sectors * 512;
      dataOut = this.image.disk.slice(startByte, startByte + byteLen);
    } else if (opcode === 0x00) {
      // TEST UNIT READY -> no data stage
      dataOut = new Uint8Array(0);
    }

    // Enqueue 64-byte Bulk-IN chunks
    for (let off = 0; off < dataOut.length; off += 64) {
      this.botQueue.push(dataOut.slice(off, Math.min(off + 64, dataOut.length)));
    }

    // Enqueue 13-byte Command Status Wrapper (CSW: 'USBS' = 0x53425355)
    const csw = new Uint8Array(13);
    const cswView = new DataView(csw.buffer);
    cswView.setUint32(0, 0x53425355, true); // dCSWSignature 'USBS'
    cswView.setUint32(4, tag, true);        // dCSWTag
    cswView.setUint32(8, 0, true);          // dCSWDataResidue
    csw[12] = status;                       // bCSWStatus = 0 (Passed)
    this.botQueue.push(csw);
    return true;
  }

  handleHostOutOrSetup(req) {
    if (this.suspended) return null;
    this.lastBusActivityNs = req.timeNs;
    if (req.devAddr !== this.address) return null;

    if (req.tokenPid === 0xD && req.endp === 0) {
      const p = req.payload;
      if (!p || p.length < 8) return encodeDevicePacketToNrzi(0xE);
      const bmRequestType = p[0];
      const bRequest = p[1];
      const wValue = p[2] | (p[3] << 8);
      const wLength = p[6] | (p[7] << 8);

      this.ep0InQueue = [];
      this.ep0Toggle = 1;

      if (bmRequestType === 0x00 && bRequest === 0x05) {
        this.pendingAddress = wValue & 0x7F;
        this.ep0Stage = 'STATUS_IN';
        return encodeDevicePacketToNrzi(0x2);
      }
      if (bmRequestType === 0x80 && bRequest === 0x06) {
        const descType = (wValue >> 8) & 0xFF;
        let data = new Uint8Array(0);
        if (descType === 0x01) data = this._getDeviceDescriptor();
        else if (descType === 0x02) data = this._getConfigDescriptorBlock();
        const slice = data.slice(0, Math.min(data.length, wLength));
        for (let off = 0; off < slice.length; off += 64) {
          this.ep0InQueue.push(slice.slice(off, Math.min(off + 64, slice.length)));
        }
        if (this.ep0InQueue.length === 0) this.ep0InQueue.push(new Uint8Array(0));
        this.ep0Stage = 'DATA_IN';
        return encodeDevicePacketToNrzi(0x2);
      }
      if (bmRequestType === 0x00 && bRequest === 0x09) {
        this.configured = (wValue & 0xFF) !== 0;
        this.ep0Stage = 'STATUS_IN';
        return encodeDevicePacketToNrzi(0x2);
      }
      if (bmRequestType === 0xA1 && bRequest === 0xFE) {
        // Class request: GET_MAX_LUN -> returns 1 byte (0x00)
        this.ep0InQueue.push(new Uint8Array([0x00]));
        this.ep0Stage = 'DATA_IN';
        return encodeDevicePacketToNrzi(0x2);
      }
      this.ep0Stage = 'STATUS_IN';
      return encodeDevicePacketToNrzi(0x2);
    }

    if (req.tokenPid === 0x1 && req.endp === 0) {
      this.ep0Stage = 'IDLE';
      return encodeDevicePacketToNrzi(0x2);
    }

    if (req.tokenPid === 0x1 && req.endp === 1) {
      // Bulk-Out endpoint (EP1): receives CBW
      const expectedPid = this.ep1OutToggle ? 0xB : 0x3;
      if (req.dataPid === expectedPid) {
        this.ep1OutToggle ^= 1;
        this._processCbw(req.payload);
      }
      return encodeDevicePacketToNrzi(0x2); // ACK
    }

    return encodeDevicePacketToNrzi(0xE);
  }

  handleHostIn(req) {
    if (this.suspended) return null;
    this.lastBusActivityNs = req.timeNs;
    if (req.devAddr !== this.address) return null;

    if (req.endp === 0) {
      if (this.ep0Stage === 'DATA_IN' && this.ep0InQueue.length > 0) {
        const chunk = this.ep0InQueue[0];
        const pid = this.ep0Toggle ? 0xB : 0x3;
        return encodeDevicePacketToNrzi(pid, chunk);
      }
      if (this.ep0Stage === 'STATUS_IN') {
        return encodeDevicePacketToNrzi(0xB, new Uint8Array(0));
      }
      return encodeDevicePacketToNrzi(0xA);
    }

    if (req.endp === 2) {
      if (this.botQueue.length === 0) {
        return encodeDevicePacketToNrzi(0xA); // NAK
      }
      const chunk = this.botQueue[0];
      const pid = this.ep2InToggle ? 0xB : 0x3;
      this.awaitingEp2Ack = true;
      return encodeDevicePacketToNrzi(pid, chunk);
    }

    return encodeDevicePacketToNrzi(0xE);
  }

  onHostAck(devAddr, endp, timeNs) {
    if (devAddr !== this.address) return;
    this.lastBusActivityNs = timeNs;
    if (endp === 0) {
      if (this.ep0Stage === 'DATA_IN') {
        this.ep0InQueue.shift();
        this.ep0Toggle ^= 1;
        if (this.ep0InQueue.length === 0) this.ep0Stage = 'STATUS_OUT';
      } else if (this.ep0Stage === 'STATUS_IN') {
        if (this.pendingAddress !== null) {
          this.address = this.pendingAddress;
          this.pendingAddress = null;
        }
        this.ep0Stage = 'IDLE';
      }
    } else if (endp === 2 && this.awaitingEp2Ack) {
      this.awaitingEp2Ack = false;
      this.botQueue.shift();
      this.ep2InToggle ^= 1;
    }
  }
}

module.exports = {
  encodeDevicePacketToNrzi,
  generateScriptedKeystrokes,
  LowSpeedHidKeyboardDevice,
  buildFat16TestImage,
  FullSpeedMassStorageDevice
};

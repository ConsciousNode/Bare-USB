/**
 * Bare USB — CPU-Budgeted USB Host Driver (Talks to SIE Only Through Register Ports)
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Provenance:
 * - Implements the CPU I/O budget model from `IO-NOTES.md` and `SPEC.md`:
 *   - 16-bit word-wide `IN rd, port` / `OUT port, rs` instructions;
 *   - Every register access (`in16` or `out16`) costs exactly 10 µs (10,000 ns) of simulated time;
 *   - The driver never touches hardware between those accesses.
 */

'use strict';

const crypto = require('crypto');
const { USB_PIDS, SIE_REGS, CSR_STATUS, CSR_CMD } = require('./netlist');

const CPU_PORT_COST_NS = 10000; // 10 µs per port access (IO-NOTES.md: ~1.1M instructions/s)

class UsbHostDriver {
  /**
   * @param {object} sie - GateLevelSIE or ReferenceSIE instance (accessed ONLY via readReg/writeReg/advanceTimeNs)
   */
  constructor(sie) {
    this.sie = sie;
    this.totalRegReads = 0;
    this.totalRegWrites = 0;
    this.totalTransfers = 0;
    this.totalRetries = 0;
    this.speedFlag = 0; // 0 = FS, CSR_CMD.SPEED_SEL = LS
    this.cbwTag = 1;
  }

  get totalRegAccesses() {
    return this.totalRegReads + this.totalRegWrites;
  }

  get totalCpuTimeUs() {
    return this.totalRegAccesses * 10;
  }

  in16(port) {
    this.sie.advanceTimeNs(CPU_PORT_COST_NS);
    this.totalRegReads++;
    return this.sie.readReg(port);
  }

  out16(port, val) {
    this.sie.advanceTimeNs(CPU_PORT_COST_NS);
    this.totalRegWrites++;
    this.sie.writeReg(port, val & 0xFFFF);
  }

  _writeBufferBytes(bytes) {
    this.out16(SIE_REGS.LEN, bytes.length);
    for (let i = 0; i < bytes.length; i += 2) {
      const lo = bytes[i] & 0xFF;
      const hi = (i + 1 < bytes.length) ? (bytes[i + 1] & 0xFF) : 0x00;
      this.out16(SIE_REGS.DATA16, lo | (hi << 8));
    }
  }

  _readBufferBytes(len) {
    const out = new Uint8Array(len);
    for (let i = 0; i < len; i += 2) {
      const w = this.in16(SIE_REGS.DATA16);
      out[i] = w & 0xFF;
      if (i + 1 < len) out[i + 1] = (w >> 8) & 0xFF;
    }
    return out;
  }

  /**
   * Executes a single USB transaction (SETUP, OUT, or IN) with USB 2.0 spec three-strike
   * error retry on timeout, CRC error, or bit-stuffing error.
   */
  runTransaction(devAddr, endp, tokenPid, dataToggle, txBytes = null, maxRetries = 3) {
    this.totalTransfers++;
    this.out16(SIE_REGS.TARGET, (devAddr & 0x7F) | ((endp & 0x0F) << 7));

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      if (tokenPid === USB_PIDS.SETUP || tokenPid === USB_PIDS.OUT) {
        this._writeBufferBytes(txBytes || new Uint8Array(0));
      }

      const cmd = (tokenPid & 0x0F) |
        (dataToggle ? CSR_CMD.DATA_TOGGLE : 0) |
        CSR_CMD.AUTO_ACK |
        CSR_CMD.AUTO_SOF_EN |
        this.speedFlag |
        CSR_CMD.BUF_RST |
        CSR_CMD.START_XFER;

      this.out16(SIE_REGS.CSR, cmd);
      const status = this.in16(SIE_REGS.CSR);
      const hasErr = (status & (CSR_STATUS.ERR_TIMEOUT | CSR_STATUS.ERR_CRC | CSR_STATUS.ERR_STUFF)) !== 0;
      const lastPid = (status >> CSR_STATUS.LAST_PID_SHIFT) & 0x0F;

      if (!hasErr) {
        if (tokenPid === USB_PIDS.SETUP || tokenPid === USB_PIDS.OUT) {
          if (lastPid === USB_PIDS.ACK) {
            return { ok: true, pid: lastPid, status };
          }
          if (lastPid === USB_PIDS.STALL) {
            return { ok: false, reason: 'STALL', status };
          }
        } else if (tokenPid === USB_PIDS.IN) {
          if ((lastPid === USB_PIDS.DATA0 || lastPid === USB_PIDS.DATA1) && (status & CSR_STATUS.TOGGLE_OK)) {
            const rxLen = this.in16(SIE_REGS.LEN);
            const data = this._readBufferBytes(rxLen);
            return { ok: true, pid: lastPid, data, status };
          }
          if (lastPid === USB_PIDS.NAK) {
            return { ok: false, reason: 'NAK', status };
          }
          if (lastPid === USB_PIDS.STALL) {
            return { ok: false, reason: 'STALL', status };
          }
        }
      }

      this.totalRetries++;
    }

    return { ok: false, reason: 'RETRIES_EXHAUSTED' };
  }

  /**
   * Standard USB Chapter 9 Control Transfer (SETUP -> optional DATA IN -> STATUS).
   */
  controlTransfer(devAddr, setup8Bytes, expectedInLen = 0, maxPacketSize0 = 64) {
    const setupRes = this.runTransaction(devAddr, 0, USB_PIDS.SETUP, 0, setup8Bytes);
    if (!setupRes.ok) return setupRes;

    const collected = [];
    let totalRx = 0;
    let toggle = 1;

    while (totalRx < expectedInLen) {
      const inRes = this.runTransaction(devAddr, 0, USB_PIDS.IN, toggle);
      if (!inRes.ok) return inRes;
      collected.push(inRes.data);
      totalRx += inRes.data.length;
      toggle ^= 1;
      if (inRes.data.length < maxPacketSize0) break;
    }

    if (expectedInLen > 0) {
      // Status OUT (zero-length DATA1)
      const stOut = this.runTransaction(devAddr, 0, USB_PIDS.OUT, 1, new Uint8Array(0));
      if (!stOut.ok) return stOut;
    } else {
      // Status IN (zero-length DATA1)
      const stIn = this.runTransaction(devAddr, 0, USB_PIDS.IN, 1);
      if (!stIn.ok) return stIn;
    }

    const merged = new Uint8Array(totalRx);
    let off = 0;
    for (const chunk of collected) {
      merged.set(chunk, off);
      off += chunk.length;
    }
    return { ok: true, data: merged };
  }

  /**
   * Detects attached device speed, issues Bus Reset, and enumerates device at `assignedAddr`.
   */
  enumerateDevice(assignedAddr = 1) {
    const initCsr = this.in16(SIE_REGS.CSR);
    if (!(initCsr & CSR_STATUS.ATTACHED)) {
      return { ok: false, reason: 'NO_DEVICE_ATTACHED' };
    }
    const isLowSpeed = (initCsr & CSR_STATUS.LOW_SPEED) !== 0;
    this.speedFlag = isLowSpeed ? CSR_CMD.SPEED_SEL : 0;
    const maxPkt0 = isLowSpeed ? 8 : 64;

    // Issue USB Bus Reset
    this.out16(SIE_REGS.CSR, CSR_CMD.BUS_RESET | CSR_CMD.AUTO_SOF_EN | this.speedFlag);

    // 1. GET_DESCRIPTOR (Device, 18 bytes) at default address 0
    const getDevDesc = new Uint8Array([0x80, 0x06, 0x00, 0x01, 0x00, 0x00, 18, 0x00]);
    const devDescRes = this.controlTransfer(0, getDevDesc, 18, maxPkt0);
    if (!devDescRes.ok) return { ok: false, stage: 'GET_DEVICE_DESC', ...devDescRes };

    // 2. SET_ADDRESS (assignedAddr)
    const setAddr = new Uint8Array([0x00, 0x05, assignedAddr & 0x7F, 0x00, 0x00, 0x00, 0x00, 0x00]);
    const setAddrRes = this.controlTransfer(0, setAddr, 0, maxPkt0);
    if (!setAddrRes.ok) return { ok: false, stage: 'SET_ADDRESS', ...setAddrRes };

    // 3. GET_DESCRIPTOR (Configuration, full block) at assignedAddr
    const cfgLen = isLowSpeed ? 34 : 32;
    const getCfgDesc = new Uint8Array([0x80, 0x06, 0x00, 0x02, 0x00, 0x00, cfgLen, 0x00]);
    const cfgDescRes = this.controlTransfer(assignedAddr, getCfgDesc, cfgLen, maxPkt0);
    if (!cfgDescRes.ok) return { ok: false, stage: 'GET_CONFIG_DESC', ...cfgDescRes };

    // 4. SET_CONFIGURATION (1)
    const setCfg = new Uint8Array([0x00, 0x09, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00]);
    const setCfgRes = this.controlTransfer(assignedAddr, setCfg, 0, maxPkt0);
    if (!setCfgRes.ok) return { ok: false, stage: 'SET_CONFIGURATION', ...setCfgRes };

    if (isLowSpeed) {
      // HID SET_PROTOCOL (0 = Boot Protocol)
      const setProto = new Uint8Array([0x21, 0x0B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
      const protoRes = this.controlTransfer(assignedAddr, setProto, 0, maxPkt0);
      if (!protoRes.ok) return { ok: false, stage: 'SET_PROTOCOL', ...protoRes };
    }

    const vid = devDescRes.data[8] | (devDescRes.data[9] << 8);
    const pid = devDescRes.data[10] | (devDescRes.data[11] << 8);

    return {
      ok: true,
      isLowSpeed,
      address: assignedAddr,
      vid,
      pid,
      deviceDescriptor: devDescRes.data,
      configDescriptor: cfgDescRes.data
    };
  }

  /**
   * Reads `count` keystrokes from the enumerated Low-Speed HID Boot Keyboard on EP1 IN.
   */
  readHidKeystrokes(devAddr, count = 100) {
    const reports = [];
    let toggle = 0;
    for (let i = 0; i < count; i++) {
      const res = this.runTransaction(devAddr, 1, USB_PIDS.IN, toggle);
      if (!res.ok) {
        return { ok: false, index: i, reason: res.reason, reports };
      }
      reports.push(res.data);
      toggle ^= 1;
    }
    return { ok: true, count: reports.length, reports };
  }

  /**
   * Issues a Bulk-Only Transport (BOT) SCSI command (CBW on EP1 OUT -> Data on EP2 IN -> CSW on EP2 IN).
   */
  botScsiRead(devAddr, cdb10, dataLength, state) {
    const cbw = new Uint8Array(31);
    const dv = new DataView(cbw.buffer);
    dv.setUint32(0, 0x43425355, true); // 'USBC'
    const tag = this.cbwTag++;
    dv.setUint32(4, tag, true);
    dv.setUint32(8, dataLength, true);
    cbw[12] = 0x80; // Direction = Data-In
    cbw[13] = 0x00; // LUN 0
    cbw[14] = cdb10.length;
    cbw.set(cdb10, 15);

    const outRes = this.runTransaction(devAddr, 1, USB_PIDS.OUT, state.outToggle, cbw);
    if (!outRes.ok) return outRes;
    state.outToggle ^= 1;

    const outBuf = new Uint8Array(dataLength);
    let offset = 0;
    while (offset < dataLength) {
      const inRes = this.runTransaction(devAddr, 2, USB_PIDS.IN, state.inToggle);
      if (!inRes.ok) return inRes;
      state.inToggle ^= 1;
      outBuf.set(inRes.data, offset);
      offset += inRes.data.length;
    }

    // Receive 13-byte CSW
    const cswRes = this.runTransaction(devAddr, 2, USB_PIDS.IN, state.inToggle);
    if (!cswRes.ok) return cswRes;
    state.inToggle ^= 1;

    if (cswRes.data.length !== 13) {
      return { ok: false, reason: 'INVALID_CSW_LEN' };
    }
    const cswView = new DataView(cswRes.data.buffer, cswRes.data.byteOffset, 13);
    if (cswView.getUint32(0, true) !== 0x53425355 || cswRes.data[12] !== 0x00) {
      return { ok: false, reason: 'CSW_FAILED' };
    }

    return { ok: true, data: outBuf };
  }

  /**
   * Reads a sector range via SCSI READ(10) (`0x28`).
   */
  scsiReadSectors(devAddr, lba, sectorCount, state) {
    const cdb = new Uint8Array([
      0x28, 0x00,
      (lba >>> 24) & 0xFF, (lba >>> 16) & 0xFF, (lba >>> 8) & 0xFF, lba & 0xFF,
      0x00,
      (sectorCount >>> 8) & 0xFF, sectorCount & 0xFF,
      0x00
    ]);
    return this.botScsiRead(devAddr, cdb, sectorCount * 512, state);
  }

  /**
   * Mounts the FAT16 volume on the enumerated Mass Storage device, locates `TEST64K.BIN`
   * in the Root Directory, reads all 65,536 bytes (128 sectors), and computes its SHA-256 hash.
   */
  readFat16File64KB(devAddr) {
    const botState = { outToggle: 0, inToggle: 0 };

    // 1. SCSI INQUIRY (36 bytes)
    const inqCdb = new Uint8Array([0x12, 0, 0, 0, 36, 0]);
    const inqRes = this.botScsiRead(devAddr, inqCdb, 36, botState);
    if (!inqRes.ok) return { ok: false, stage: 'SCSI_INQUIRY', ...inqRes };

    // 2. Read LBA 0 (Boot Sector / BPB)
    const bpbRes = this.scsiReadSectors(devAddr, 0, 1, botState);
    if (!bpbRes.ok) return { ok: false, stage: 'READ_BPB', ...bpbRes };
    const bpbView = new DataView(bpbRes.data.buffer, bpbRes.data.byteOffset, 512);
    const bytesPerSec = bpbView.getUint16(11, true);
    const secPerClus = bpbRes.data[13];
    const rsvdSecCnt = bpbView.getUint16(14, true);
    const numFats = bpbRes.data[16];
    const rootEntCnt = bpbView.getUint16(17, true);
    const fatSz16 = bpbView.getUint16(22, true);

    const rootDirLba = rsvdSecCnt + numFats * fatSz16; // 1 + 1*15 = 16
    const rootDirSectors = Math.ceil((rootEntCnt * 32) / bytesPerSec); // 16
    const dataRegionLba = rootDirLba + rootDirSectors; // 32

    // 3. Read Root Directory first sector (LBA 16) to locate TEST64K.BIN
    const rootRes = this.scsiReadSectors(devAddr, rootDirLba, 1, botState);
    if (!rootRes.ok) return { ok: false, stage: 'READ_ROOT_DIR', ...rootRes };
    const rootView = new DataView(rootRes.data.buffer, rootRes.data.byteOffset, 512);
    const startCluster = rootView.getUint16(26, true);
    const fileSize = rootView.getUint32(28, true);

    const fileLba = dataRegionLba + (startCluster - 2) * secPerClus;
    const totalSectors = Math.ceil(fileSize / bytesPerSec);

    // 4. Read all 128 sectors (65,536 bytes) in 16-sector (8 KB) SCSI READ(10) transfers
    const fileData = new Uint8Array(fileSize);
    let byteOffset = 0;
    const chunkSectors = 16;
    for (let s = 0; s < totalSectors; s += chunkSectors) {
      const count = Math.min(chunkSectors, totalSectors - s);
      const chunkRes = this.scsiReadSectors(devAddr, fileLba + s, count, botState);
      if (!chunkRes.ok) return { ok: false, stage: `READ_DATA_LBA_${fileLba + s}`, ...chunkRes };
      fileData.set(chunkRes.data, byteOffset);
      byteOffset += chunkRes.data.length;
    }

    const sha256 = crypto.createHash('sha256').update(fileData).digest('hex');
    return {
      ok: true,
      fileName: 'TEST64K.BIN',
      fileSize: fileData.length,
      startCluster,
      fileLba,
      sha256
    };
  }

  getBudgetMetrics() {
    const simTimeMs = this.sie.simTimeNs / 1e6;
    const regAccessesPerTransfer = this.totalTransfers > 0
      ? +(this.totalRegAccesses / this.totalTransfers).toFixed(2)
      : 0;
    const cpuTimeUsPerMsFrame = simTimeMs > 0
      ? +(this.totalCpuTimeUs / simTimeMs).toFixed(2)
      : 0;
    return {
      totalRegReads: this.totalRegReads,
      totalRegWrites: this.totalRegWrites,
      totalRegAccesses: this.totalRegAccesses,
      totalTransfers: this.totalTransfers,
      totalRetries: this.totalRetries,
      totalCpuTimeUs: this.totalCpuTimeUs,
      totalSimTimeMs: +simTimeMs.toFixed(3),
      regAccessesPerTransfer,
      cpuTimeUsPerMsFrame,
      cpuUtilizationPct: +((cpuTimeUsPerMsFrame / 1000) * 100).toFixed(2)
    };
  }
}

module.exports = {
  CPU_PORT_COST_NS,
  UsbHostDriver
};

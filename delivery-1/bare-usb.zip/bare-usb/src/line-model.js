/**
 * Bare USB — Differential D+/D- Line Model & Analog Transceiver Termination Network
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Models:
 * - Physical D+/D- bus states: J, K, SE0, SE1, IDLE (unattached SE0 via 15 kΩ host pull-downs)
 * - Analog transceiver part: onsemi / Fairchild USB1T11A (3.3 V VCC, 5 V tolerant, 16 ns max RCV
 *   delay, 14 ns driver delay) + 27 Ω ±1% series termination resistors on D+/D- and 15 kΩ ±5%
 *   downstream pull-down resistors to GND (USB 2.0 Specification §7.1.1 & Figure 7-1).
 * - Device attach/detach with 1.5 kΩ ±5% pull-up to 3.3 V on D+ (Full-Speed) or D- (Low-Speed).
 * - Waveform capture for D+/D- and decoded packet timeline.
 * - Deterministic error injection hooks (corrupted CRC, bit-stuffing error, dropped handshake).
 */

'use strict';

class UsbLineModel {
  constructor() {
    this.attachedDevice = null;
    this.lowSpeedPullUp = false;
    this.busState = 'SE0_DISCONNECTED'; // 'IDLE_J', 'J', 'K', 'SE0', 'RESET_SE0'
    this.dpVoltage = 0.0;
    this.dmVoltage = 0.0;

    // Waveform samples (bounded for memory efficiency while capturing detailed packet transitions)
    this.waveform = [];
    this.maxWaveformSamples = 4000;

    // Error injection queue for Test 5
    this.errorInjections = [];
  }

  attachDevice(device) {
    this.attachedDevice = device;
    this.lowSpeedPullUp = !!device.isLowSpeed;
    // Resistor divider: 3.3V through 1.5 kΩ pull-up against 15 kΩ host pull-down -> 3.00 V idle line
    if (this.lowSpeedPullUp) {
      this.dpVoltage = 0.0;
      this.dmVoltage = 3.0;
    } else {
      this.dpVoltage = 3.0;
      this.dmVoltage = 0.0;
    }
    this.busState = 'IDLE_J';
    this._recordWaveSample(0, this.dpVoltage > 1.5 ? 1 : 0, this.dmVoltage > 1.5 ? 1 : 0, 'ATTACH_IDLE_J');
  }

  detachDevice(timeNs = 0) {
    this.attachedDevice = null;
    this.dpVoltage = 0.0;
    this.dmVoltage = 0.0;
    this.busState = 'SE0_DISCONNECTED';
    this._recordWaveSample(timeNs, 0, 0, 'DETACH_SE0');
  }

  getAttachState() {
    return {
      attached: this.attachedDevice !== null,
      lowSpeed: this.lowSpeedPullUp,
      dpVoltage: this.dpVoltage,
      dmVoltage: this.dmVoltage,
      transceiverPart: 'USB1T11ABQX (onsemi) + 2x 27Ω series + 2x 15kΩ pull-down'
    };
  }

  scheduleErrorInjection(inj) {
    // inj: { type: 'corrupt_crc' | 'stuff_error' | 'drop_handshake', onPid?: number }
    this.errorInjections.push({ ...inj, triggered: false });
  }

  _consumeErrorInjection(pid) {
    for (let i = 0; i < this.errorInjections.length; i++) {
      const inj = this.errorInjections[i];
      if (!inj.triggered && (inj.onPid === undefined || inj.onPid === pid)) {
        inj.triggered = true;
        return inj;
      }
    }
    return null;
  }

  _recordWaveSample(timeNs, dp, dm, stateLabel, packetTag = null) {
    if (this.waveform.length >= this.maxWaveformSamples) return;
    this.waveform.push({
      timeNs: +timeNs.toFixed(1),
      dp: dp & 1,
      dm: dm & 1,
      state: stateLabel,
      tag: packetTag
    });
  }

  driveBusReset(timeNs) {
    this._recordWaveSample(timeNs, 0, 0, 'SE0', 'BUS_RESET_START');
    this._recordWaveSample(timeNs + 2500, 0, 0, 'SE0', 'BUS_RESET_END');
    const idleDp = this.lowSpeedPullUp ? 0 : 1;
    const idleDm = this.lowSpeedPullUp ? 1 : 0;
    this._recordWaveSample(timeNs + 2600, idleDp, idleDm, 'J', 'IDLE');
    if (this.attachedDevice && typeof this.attachedDevice.onBusReset === 'function') {
      this.attachedDevice.onBusReset(timeNs);
    }
  }

  recordLowSpeedKeepAlive(timeNs) {
    const bitNs = 1000 / 1.5;
    this._recordWaveSample(timeNs, 0, 0, 'SE0', 'LS_KEEPALIVE_EOP');
    this._recordWaveSample(timeNs + 2 * bitNs, 0, 1, 'J', 'IDLE');
  }

  recordHostPacket(pkt) {
    const { startTimeNs, bitPeriodNs, isLowSpeed, pid, nrziLevels } = pkt;
    if (this.waveform.length < this.maxWaveformSamples) {
      const maxBitsToRecord = Math.min(nrziLevels.length, 48);
      for (let i = 0; i < maxBitsToRecord; i++) {
        const isJ = nrziLevels[i] === 1;
        const dp = isLowSpeed ? (isJ ? 0 : 1) : (isJ ? 1 : 0);
        const dm = dp ^ 1;
        this._recordWaveSample(
          startTimeNs + i * bitPeriodNs,
          dp,
          dm,
          isJ ? 'J' : 'K',
          i === 0 ? `HOST_PID_0x${pid.toString(16).toUpperCase()}` : null
        );
      }
      const eopTime = startTimeNs + nrziLevels.length * bitPeriodNs;
      this._recordWaveSample(eopTime, 0, 0, 'SE0', 'EOP_SE0');
      this._recordWaveSample(eopTime + 2 * bitPeriodNs, isLowSpeed ? 0 : 1, isLowSpeed ? 1 : 0, 'J', 'EOP_J');
    }
  }

  notifySofOrKeepAlive(timeNs, isLowSpeed, frameNum) {
    if (this.attachedDevice && typeof this.attachedDevice.onSofOrKeepAlive === 'function') {
      this.attachedDevice.onSofOrKeepAlive(timeNs, isLowSpeed, frameNum);
    }
  }

  checkDeviceSuspend(timeNs) {
    if (this.attachedDevice && typeof this.attachedDevice.checkSuspend === 'function') {
      this.attachedDevice.checkSuspend(timeNs);
    }
  }

  deliverHostOutOrSetup(req) {
    if (!this.attachedDevice) return null;
    const resp = this.attachedDevice.handleHostOutOrSetup(req);
    if (!resp) return null;
    const inj = this._consumeErrorInjection(resp.pid);
    if (inj) {
      if (inj.type === 'drop_handshake') {
        return { ...resp, dropped: true };
      }
      if (inj.type === 'stuff_error') {
        return { ...resp, injectStuffError: true };
      }
      if (inj.type === 'corrupt_crc') {
        return { ...resp, injectCrcError: true };
      }
    }
    this._recordDeviceWave(req.timeNs + (resp.turnaroundBits || 4) * req.bitPeriodNs, req.bitPeriodNs, req.isLowSpeed, resp);
    return resp;
  }

  deliverHostIn(req) {
    if (!this.attachedDevice) return null;
    const resp = this.attachedDevice.handleHostIn(req);
    if (!resp) return null;
    const inj = this._consumeErrorInjection(resp.pid);
    if (inj) {
      if (inj.type === 'drop_handshake') {
        return { ...resp, dropped: true };
      }
      if (inj.type === 'stuff_error') {
        // Also corrupt NRZI stream to contain 7 consecutive identical J/K levels (6 ones + 1 instead of 0)
        const mutatedLevels = resp.nrziLevels.slice();
        const cur = mutatedLevels.length > 0 ? mutatedLevels[mutatedLevels.length - 1] : 1;
        for (let k = 0; k < 8; k++) mutatedLevels.splice(16, 0, cur);
        return { ...resp, nrziLevels: mutatedLevels, injectStuffError: true };
      }
      if (inj.type === 'corrupt_crc') {
        // Flip the last CRC bit on the wire so the gate-level CRC-16 check catches it
        const mutatedLevels = resp.nrziLevels.slice();
        if (mutatedLevels.length > 4) {
          const idx = mutatedLevels.length - 2;
          mutatedLevels[idx] ^= 1;
        }
        return { ...resp, nrziLevels: mutatedLevels, injectCrcError: true };
      }
    }
    this._recordDeviceWave(req.timeNs + (resp.turnaroundBits || 4) * req.bitPeriodNs, req.bitPeriodNs, req.isLowSpeed, resp);
    return resp;
  }

  notifyDeviceAck(devAddr, endp, timeNs) {
    if (this.attachedDevice && typeof this.attachedDevice.onHostAck === 'function') {
      this.attachedDevice.onHostAck(devAddr, endp, timeNs);
    }
  }

  _recordDeviceWave(startTimeNs, bitPeriodNs, isLowSpeed, resp) {
    if (!resp || !resp.nrziLevels || this.waveform.length >= this.maxWaveformSamples) return;
    const maxBits = Math.min(resp.nrziLevels.length, 48);
    for (let i = 0; i < maxBits; i++) {
      const isJ = resp.nrziLevels[i] === 1;
      const dp = isLowSpeed ? (isJ ? 0 : 1) : (isJ ? 1 : 0);
      const dm = dp ^ 1;
      this._recordWaveSample(
        startTimeNs + i * bitPeriodNs,
        dp,
        dm,
        isJ ? 'J' : 'K',
        i === 0 ? `DEV_PID_0x${resp.pid.toString(16).toUpperCase()}` : null
      );
    }
    const eopTime = startTimeNs + resp.nrziLevels.length * bitPeriodNs;
    this._recordWaveSample(eopTime, 0, 0, 'SE0', 'DEV_EOP_SE0');
    this._recordWaveSample(eopTime + 2 * bitPeriodNs, isLowSpeed ? 0 : 1, isLowSpeed ? 1 : 0, 'J', 'DEV_EOP_J');
  }
}

module.exports = {
  UsbLineModel
};

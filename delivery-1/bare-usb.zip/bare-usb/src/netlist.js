/**
 * Bare USB — Discrete-Logic USB 1.1 Host Serial Interface Engine (SIE) Netlist & Gate Engine
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Provenance:
 * - Built strictly from parts in `PARTS.md` and `TIMING-BUDGET.md` (Kehai Interim, 2026-11-18):
 *   74LVC logic family, IS61WV5128EDBLL-10TLI 10 ns SRAM (shadowed from SST39SF040 flash at reset
 *   via 74LVC161 copy-engine counters, no program counter), USB1T11A differential transceiver.
 * - Register port interface adheres to `IO-NOTES.md`:
 *   16-bit word-wide IN/OUT ports, level-triggered IRQ, 10 µs CPU access budget.
 * - Strictly isolated: does NOT import reference SIE, device models, or host driver.
 */

'use strict';

const { GateSimulator } = require('./simulator');
const { PARTS_CATALOG } = require('./parts-library');
const { generateFsmLut, generatePidCheckLut } = require('../scripts/generate-tables');

const USB_PIDS = {
  OUT:   0x1,
  IN:    0x9,
  SOF:   0x5,
  SETUP: 0xD,
  DATA0: 0x3,
  DATA1: 0xB,
  ACK:   0x2,
  NAK:   0xA,
  STALL: 0xE,
  PRE:   0xC
};

// Register port addresses (decoded by U_IO_DEC 74LVC138A on PORT[2:0])
const SIE_REGS = {
  CSR:     0x00, // Command (write) & Status (read)
  TARGET:  0x01, // DEV_ADDR[6:0] | (ENDP[3:0] << 7)
  LEN:     0x02, // TX_LEN (write, resets BUF_PTR) / RX_LEN (read)
  DATA16:  0x03, // 16-bit auto-incrementing Buffer SRAM port (2 bytes per IN/OUT)
  FRAME:   0x04, // 11-bit USB Frame Number (0..2047)
  BUF_PTR: 0x05, // Buffer SRAM word pointer
  DIAG:    0x06  // Error counters: (timeoutAndStuffErr << 8) | crcErr
};

// CSR Status bits (Read)
const CSR_STATUS = {
  BUSY:           1 << 0,
  DONE:           1 << 1,
  ERR_TIMEOUT:    1 << 2,
  ERR_CRC:        1 << 3,
  ERR_STUFF:      1 << 4,
  ATTACHED:       1 << 5,
  LOW_SPEED:      1 << 6,
  SOF_SENT:       1 << 7,
  LAST_PID_SHIFT: 8,      // bits 11..8
  TOGGLE_OK:      1 << 12,
  IRQ_PENDING:    1 << 13,
  RESET_BUSY:     1 << 14,
  SPEED_MODE:     1 << 15
};

// CSR Command bits (Write)
const CSR_CMD = {
  TOKEN_PID_MASK: 0x000F,
  DATA_TOGGLE:    1 << 4,
  AUTO_ACK:       1 << 5,
  AUTO_SOF_EN:    1 << 6,
  SPEED_SEL:      1 << 7, // 0 = FS (12 Mb/s), 1 = LS (1.5 Mb/s)
  START_XFER:     1 << 8,
  BUS_RESET:      1 << 9,
  CLR_IRQ:        1 << 10,
  BUF_RST:        1 << 11,
  IRQ_EN:         1 << 12
};

/**
 * Constructs the complete discrete-logic USB 1.1 Host SIE netlist inside a GateSimulator instance.
 * Every chip is a real catalog part; no MCU, CPU, CPLD, FPGA, or program counter exists.
 */
function buildSieNetlist(sim, mutant = null) {
  const fsmLut = generateFsmLut();
  const pidLut = generatePidCheckLut();
  const fsmLoInit = new Uint8Array(4096);
  const fsmHiInit = new Uint8Array(4096);
  for (let i = 0; i < 4096; i++) {
    fsmLoInit[i] = fsmLut[i] & 0xFF;
    fsmHiInit[i] = (fsmLut[i] >> 8) & 0xFF;
  }

  // 1. Clock & 4x Oversampling DPLL Subsystem (48.000 MHz XO -> 12 MHz FS / 1.5 MHz LS bit clock)
  sim.addChip('U01_XO48M', 'ECS-3953M-480', '48.000 MHz 3.3V Crystal Oscillator', {
    EN: 'VCC', GND: 'GND', CLK_OUT: 'CLK_48M', VCC: 'VCC'
  });
  sim.addChip('U02_CLK_DIV_FS_LS', '74LVC161', 'FS (÷4) / LS (÷32) Oversample Prescaler Counter', {
    MR_N: 'RST_N', CP: 'CLK_48M', PE_N: 'VCC', CEP: 'VCC', CET: 'VCC',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'DIV_Q0', Q1: 'CLK_FS_RAW', Q2: 'DIV_Q2', Q3: 'CLK_LS_RAW', TC: 'DIV_TC'
  });
  sim.addChip('U03_SPEED_MUX', '74LVC157A', 'FS (12 Mb/s) / LS (1.5 Mb/s) Clock & Polarity Selector Mux', {
    S: 'SPEED_LS', G_N: 'GND',
    '1I0': 'CLK_FS_RAW', '1I1': 'CLK_LS_RAW', '1Y': 'BIT_CLK_MUX',
    '2I0': 'VCC', '2I1': 'GND', '2Y': 'XCVR_SPEED_PIN',
    '3I0': 'DP_IN', '3I1': 'DM_IN', '3Y': 'BUS_J_SENSE',
    '4I0': 'DM_IN', '4I1': 'DP_IN', '4Y': 'BUS_K_SENSE'
  });
  sim.addChip('U04_DPLL_EDGE_FF', '74LVC74A', '4x Oversampling Receive DPLL Edge Detector Flip-Flops', {
    '1CLR_N': 'RST_N', '1PRE_N': 'VCC', '1CLK': 'CLK_48M', '1D': 'RCV_IN', '1Q': 'RCV_D1', '1Q_N': 'RCV_D1_N',
    '2CLR_N': 'RST_N', '2PRE_N': 'VCC', '2CLK': 'CLK_48M', '2D': 'RCV_D1', '2Q': 'RCV_D2', '2Q_N': 'RCV_D2_N'
  });
  sim.addChip('U05_DPLL_PHASE_CNT', '74LVC161', '4x Oversampling DPLL Phase Recovery Counter (resyncs on NRZI transition)', {
    MR_N: 'RST_N', CP: 'CLK_48M', PE_N: 'DPLL_SYNC_N', CEP: 'VCC', CET: 'VCC',
    D0: 'VCC', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'DPLL_Q0', Q1: 'RX_BIT_SAMPLE_CLK', Q2: 'DPLL_Q2', Q3: 'DPLL_Q3', TC: 'DPLL_TC'
  });

  // 2. USB Differential Transceiver & Termination Network
  sim.addChip('U06_USB_XCVR', 'USB1T11A', 'USB 1.1 Differential Line Transceiver (FS/LS)', {
    VPO: 'TX_VPO', VMO: 'TX_VMO', RCV: 'RCV_IN', VP: 'DP_IN', VM: 'DM_IN',
    OE_N: 'TX_OE_N', SPEED: 'XCVR_SPEED_PIN', SUSPND: 'GND',
    DPLUS: 'DP_XCVR', DMINUS: 'DM_XCVR', VCC: 'VCC', GND: 'GND'
  });
  sim.addChip('U07_USB_TERM', 'RES-NET-USB', '27 Ω Series Terminations & 15 kΩ Host Pull-Downs', {
    DP_XCVR: 'DP_XCVR', DM_XCVR: 'DM_XCVR', DP_BUS: 'DP_PIN', DM_BUS: 'DM_PIN', GND: 'GND'
  });

  // 3. NRZI Encoder & Decoder Gate Subcircuit (Mutant 3 target: nrzi_rx_inverted)
  sim.addChip('U08_NRZI_FF', '74LVC74A', 'TX & RX NRZI Previous-Level State Flip-Flops', {
    '1CLR_N': 'NRZI_TX_RST_N', '1PRE_N': 'NRZI_TX_PRE_N', '1CLK': 'BIT_CLK', '1D': 'NRZI_TX_NEXT', '1Q': 'NRZI_TX_Q', '1Q_N': 'NRZI_TX_Q_N',
    '2CLR_N': 'RST_N', '2PRE_N': 'NRZI_RX_PRE_N', '2CLK': 'BIT_CLK', '2D': 'NRZI_RX_IN', '2Q': 'NRZI_RX_PREV', '2Q_N': 'NRZI_RX_PREV_N'
  });
  sim.addChip('U09_NRZI_XOR', '74LVC86A', 'NRZI TX Toggle & RX Transition Detector XOR Gates', {
    '1A': 'NRZI_TX_Q', '1B': 'TX_BIT_INV', '1Y': 'NRZI_TX_NEXT',
    '2A': 'NRZI_RX_IN', '2B': 'NRZI_RX_PREV', '2Y': 'NRZI_RX_DIFF',
    '3A': 'RCV_D1', '3B': 'RCV_D2', '3Y': 'DPLL_EDGE',
    '4A': 'DP_IN', '4B': 'DM_IN', '4Y': 'DIFF_VALID'
  });
  const nrziRxInvOutNet = (mutant === 'nrzi_rx_inverted') ? 'NRZI_RX_BIT_UNUSED' : 'NRZI_RX_BIT';
  const nrziDoubleInvIn = (mutant === 'nrzi_rx_inverted') ? 'NRZI_RX_BIT_UNUSED' : 'GND';
  const nrziDoubleInvOut = (mutant === 'nrzi_rx_inverted') ? 'NRZI_RX_BIT' : 'UNUSED_INV3';
  sim.addChip('U10_NRZI_INV', '74LVC04A', 'NRZI Bit Inverters & Control Inverters', {
    '1A': 'TX_BIT_OUT', '1Y': 'TX_BIT_INV',
    '2A': 'NRZI_RX_DIFF', '2Y': nrziRxInvOutNet,
    '3A': nrziDoubleInvIn, '3Y': nrziDoubleInvOut,
    '4A': 'DPLL_EDGE', '4Y': 'DPLL_SYNC_N',
    '5A': 'STUFF_Q0', '5Y': 'STUFF_Q0_N',
    '6A': 'TX_OE', '6Y': 'TX_OE_N'
  });

  // 4. Bit-Stuffing & Unstuffing Counter Subcircuit (Mutant 2 target: bit_stuff_off_by_one)
  sim.addChip('U11_STUFF_CNT', '74LVC161', 'Consecutive-Ones Bit-Stuffing / Unstuffing 4-Bit Counter', {
    MR_N: 'STUFF_RST_N', CP: 'BIT_CLK', PE_N: 'STUFF_LOAD_N', CEP: 'STUFF_BIT_IN', CET: 'VCC',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'STUFF_Q0', Q1: 'STUFF_Q1', Q2: 'STUFF_Q2', Q3: 'STUFF_Q3', TC: 'STUFF_TC'
  });
  const stuffPin1B = (mutant === 'bit_stuff_off_by_one') ? 'STUFF_Q0' : 'STUFF_Q1';
  const stuffPin2B = (mutant === 'bit_stuff_off_by_one') ? 'STUFF_Q1_N_MUT' : 'STUFF_Q0_N';
  sim.addChip('U12_STUFF_AND', '74LVC08A', 'Bit-Stuff Terminal Count (6 Consecutive Ones) Comparator AND Gate', {
    '1A': 'STUFF_Q2', '1B': stuffPin1B, '1Y': 'STUFF_HI_MATCH',
    '2A': 'STUFF_HI_MATCH', '2B': stuffPin2B, '2Y': 'STUFF_TRIG',
    '3A': 'STUFF_TRIG', '3B': 'NRZI_RX_BIT', '3Y': 'RX_STUFF_ERR',
    '4A': 'STUFF_BIT_IN', '4B': 'STUFF_NOT_TRIG', '4Y': 'STUFF_LOAD_N'
  });

  // 5. Token CRC-5 Subcircuit (G(x) = x^5 + x^2 + 1)
  sim.addChip('U13_CRC5_FF0', '74LVC74A', 'CRC-5 Shift Register Bits 0..1', {
    '1CLR_N': 'VCC', '1PRE_N': 'CRC5_INIT_N', '1CLK': 'BIT_CLK', '1D': 'CRC5_FB', '1Q': 'CRC5_Q0',
    '2CLR_N': 'VCC', '2PRE_N': 'CRC5_INIT_N', '2CLK': 'BIT_CLK', '2D': 'CRC5_Q0', '2Q': 'CRC5_Q1'
  });
  sim.addChip('U14_CRC5_FF1', '74LVC74A', 'CRC-5 Shift Register Bits 2..3', {
    '1CLR_N': 'VCC', '1PRE_N': 'CRC5_INIT_N', '1CLK': 'BIT_CLK', '1D': 'CRC5_D2', '1Q': 'CRC5_Q2',
    '2CLR_N': 'VCC', '2PRE_N': 'CRC5_INIT_N', '2CLK': 'BIT_CLK', '2D': 'CRC5_Q2', '2Q': 'CRC5_Q3'
  });
  sim.addChip('U15_CRC5_FF2', '74LVC74A', 'CRC-5 Shift Register Bit 4 & EOP SE0 Width Flip-Flop', {
    '1CLR_N': 'VCC', '1PRE_N': 'CRC5_INIT_N', '1CLK': 'BIT_CLK', '1D': 'CRC5_Q3', '1Q': 'CRC5_Q4',
    '2CLR_N': 'RST_N', '2PRE_N': 'VCC', '2CLK': 'BIT_CLK', '2D': 'SE0_NOW', '2Q': 'SE0_PREV'
  });
  sim.addChip('U16_CRC5_XOR', '74LVC86A', 'CRC-5 Polynomial Tap XOR Gates (x^5 + x^2 + 1)', {
    '1A': 'CRC_BIT_IN', '1B': 'CRC5_Q4', '1Y': 'CRC5_FB',
    '2A': 'CRC5_Q1', '2B': 'CRC5_FB', '2Y': 'CRC5_D2',
    '3A': 'STUFF_Q1', '3B': 'VCC', '3Y': 'STUFF_Q1_N_MUT',
    '4A': 'STUFF_TRIG', '4B': 'VCC', '4Y': 'STUFF_NOT_TRIG'
  });

  // 6. Data CRC-16 Subcircuit (G(x) = x^16 + x^15 + x^2 + 1, Mutant 1 target: crc16_tap_moved)
  sim.addChip('U17_CRC16_LO', '74LVC574A', 'CRC-16 Shift Register Low Byte Q[7:0]', {
    OE_N: 'GND', CLK: 'BIT_CLK',
    D0: 'CRC16_FB', D1: 'CRC16_Q0', D2: 'CRC16_D2', D3: 'CRC16_Q2',
    D4: 'CRC16_Q3', D5: 'CRC16_Q4', D6: 'CRC16_Q5', D7: 'CRC16_Q6',
    Q0: 'CRC16_Q0', Q1: 'CRC16_Q1', Q2: 'CRC16_Q2', Q3: 'CRC16_Q3',
    Q4: 'CRC16_Q4', Q5: 'CRC16_Q5', Q6: 'CRC16_Q6', Q7: 'CRC16_Q7'
  });
  sim.addChip('U18_CRC16_HI', '74LVC574A', 'CRC-16 Shift Register High Byte Q[15:8]', {
    OE_N: 'GND', CLK: 'BIT_CLK',
    D0: 'CRC16_Q7', D1: 'CRC16_Q8', D2: 'CRC16_Q9', D3: 'CRC16_Q10',
    D4: 'CRC16_Q11', D5: 'CRC16_Q12', D6: 'CRC16_Q13', D7: 'CRC16_D15',
    Q0: 'CRC16_Q8', Q1: 'CRC16_Q9', Q2: 'CRC16_Q10', Q3: 'CRC16_Q11',
    Q4: 'CRC16_Q12', Q5: 'CRC16_Q13', Q6: 'CRC16_Q14', Q7: 'CRC16_Q15'
  });
  const crc16TapPin2A = (mutant === 'crc16_tap_moved') ? 'CRC16_Q3' : 'CRC16_Q1';
  sim.addChip('U19_CRC16_XOR', '74LVC86A', 'CRC-16 Polynomial Tap XOR Gates (x^16 + x^15 + x^2 + 1)', {
    '1A': 'CRC_BIT_IN', '1B': 'CRC16_Q15', '1Y': 'CRC16_FB',
    '2A': crc16TapPin2A, '2B': 'CRC16_FB', '2Y': 'CRC16_D2',
    '3A': 'CRC16_Q14', '3B': 'CRC16_FB', '3Y': 'CRC16_D15',
    '4A': 'CRC16_Q0', '4B': 'GND', '4Y': 'CRC16_OUT_BIT'
  });

  // 7. SerDes Shift Registers & Bit Counter
  sim.addChip('U20_TX_SR', '74LVC165A', '8-Bit Parallel-In Serial-Out Transmit Shift Register', {
    SH_LD_N: 'TX_SH_LD_N', CLK: 'BIT_CLK', CLK_INH: 'STUFF_TRIG', SER: 'GND',
    A: 'TX_D0', B: 'TX_D1', C: 'TX_D2', D: 'TX_D3', E: 'TX_D4', F: 'TX_D5', G: 'TX_D6', H: 'TX_D7',
    QH: 'TX_SR_OUT', QH_N: 'TX_SR_OUT_N'
  });
  sim.addChip('U21_RX_SR', '74LVC595A', '8-Bit Serial-In Parallel-Out Receive Shift Register', {
    SRCLR_N: 'RST_N', SRCLK: 'BIT_CLK', RCLK: 'BYTE_STB', OE_N: 'GND', SER: 'NRZI_RX_BIT',
    QA: 'RX_D0', QB: 'RX_D1', QC: 'RX_D2', QD: 'RX_D3', QE: 'RX_D4', QF: 'RX_D5', QG: 'RX_D6', QH: 'RX_D7', QH_S: 'RX_QHS'
  });
  sim.addChip('U22_BIT_CNT', '74LVC161', 'Byte Framing Bit Counter (0..7)', {
    MR_N: 'BIT_CNT_RST_N', CP: 'BIT_CLK', PE_N: 'VCC', CEP: 'STUFF_NOT_TRIG', CET: 'VCC',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'BIT_Q0', Q1: 'BIT_Q1', Q2: 'BIT_Q2', Q3: 'BYTE_DONE', TC: 'BIT_TC'
  });

  // 8. Bus Turnaround Timer & EOP Detector (Mutant 4 target: turnaround_short)
  sim.addChip('U23_TURN_CNT_LO', '74LVC161', 'Bus Turnaround Timeout Counter Low Nibble (Bit Times 0..15)', {
    MR_N: 'TURN_RST_N', CP: 'BIT_CLK', PE_N: 'VCC', CEP: 'TURN_EN', CET: 'TURN_EN',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'TURN_Q0', Q1: 'TURN_Q1', Q2: 'TURN_Q2', Q3: 'TURN_Q3', TC: 'TURN_TC_LO'
  });
  sim.addChip('U24_TURN_CNT_HI', '74LVC161', 'Bus Turnaround Timeout Counter High Nibble (Bit Times 16..255)', {
    MR_N: 'TURN_RST_N', CP: 'BIT_CLK', PE_N: 'VCC', CEP: 'TURN_TC_LO', CET: 'TURN_TC_LO',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND',
    Q0: 'TURN_Q4', Q1: 'TURN_Q5', Q2: 'TURN_Q6', Q3: 'TURN_Q7', TC: 'TURN_TC_HI'
  });
  const turnCmp1A = (mutant === 'turnaround_short') ? 'VCC' : 'TURN_Q4';
  sim.addChip('U25_TURN_EOP_AND', '74LVC08A', 'Turnaround Timeout (18 Bit Times, USB 2.0 §7.1.19.1) & EOP Detector AND Gate', {
    '1A': turnCmp1A, '1B': 'TURN_Q1', '1Y': 'TURN_TIMEOUT',
    '2A': 'DP_N', '2B': 'DM_N', '2Y': 'SE0_NOW',
    '3A': 'SE0_NOW', '3B': 'SE0_PREV', '3Y': 'EOP_SE0_2BIT',
    '4A': 'EOP_SE0_2BIT', '4B': 'BUS_J_SENSE', '4Y': 'EOP_VALID'
  });

  // 9. 1.000 ms SOF / Keep-Alive Frame Interval Timer & 11-Bit Frame Counter (Mutant 5 target: sof_missing)
  sim.addChip('U26_SOF_TMR0', '74LVC161', '1 ms Frame Interval Counter Stage 0 (Bits 3:0)', {
    MR_N: 'SOF_CNT_RST_N', CP: 'CLK_48M', PE_N: 'VCC', CEP: 'VCC', CET: 'VCC',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'SOF_T0', Q1: 'SOF_T1', Q2: 'SOF_T2', Q3: 'SOF_T3', TC: 'SOF_TC0'
  });
  sim.addChip('U27_SOF_TMR1', '74LVC161', '1 ms Frame Interval Counter Stage 1 (Bits 7:4)', {
    MR_N: 'SOF_CNT_RST_N', CP: 'CLK_48M', PE_N: 'VCC', CEP: 'SOF_TC0', CET: 'SOF_TC0',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'SOF_T4', Q1: 'SOF_T5', Q2: 'SOF_T6', Q3: 'SOF_T7', TC: 'SOF_TC1'
  });
  sim.addChip('U28_SOF_TMR2', '74LVC161', '1 ms Frame Interval Counter Stage 2 (Bits 11:8)', {
    MR_N: 'SOF_CNT_RST_N', CP: 'CLK_48M', PE_N: 'VCC', CEP: 'SOF_TC1', CET: 'SOF_TC1',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'SOF_T8', Q1: 'SOF_T9', Q2: 'SOF_T10', Q3: 'SOF_T11', TC: 'SOF_TC2'
  });
  sim.addChip('U29_SOF_TMR3', '74LVC161', '1 ms Frame Interval Counter Stage 3 (Bits 15:12, terminal at 48,000)', {
    MR_N: 'SOF_CNT_RST_N', CP: 'CLK_48M', PE_N: 'VCC', CEP: 'SOF_TC2', CET: 'SOF_TC2',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'SOF_T12', Q1: 'SOF_T13', Q2: 'SOF_T14', Q3: 'SOF_T15', TC: 'SOF_TC3'
  });
  const sofEnableInput = (mutant === 'sof_missing') ? 'GND' : 'AUTO_SOF_EN';
  sim.addChip('U30_SOF_GATE', '74LVC08A', '1 ms SOF / Keep-Alive Trigger Gate', {
    '1A': 'SOF_1MS_TICK', '1B': sofEnableInput, '1Y': 'SOF_TRIG_OUT',
    '2A': 'SOF_TRIG_OUT', '2B': 'SPEED_FS', '2Y': 'SOF_TOKEN_REQ',
    '3A': 'SOF_TRIG_OUT', '3B': 'SPEED_LS', '3Y': 'LS_KEEPALIVE_REQ',
    '4A': 'IRQ_EN', '4B': 'XFER_DONE', '4Y': 'IRQ_LINE'
  });
  sim.addChip('U31_FRNUM_CNT0', '74LVC161', 'USB 11-Bit Frame Number Counter Bits 3:0', {
    MR_N: 'RST_N', CP: 'SOF_TRIG_OUT', PE_N: 'VCC', CEP: 'VCC', CET: 'VCC',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'FN0', Q1: 'FN1', Q2: 'FN2', Q3: 'FN3', TC: 'FN_TC0'
  });
  sim.addChip('U32_FRNUM_CNT1', '74LVC161', 'USB 11-Bit Frame Number Counter Bits 7:4', {
    MR_N: 'RST_N', CP: 'SOF_TRIG_OUT', PE_N: 'VCC', CEP: 'FN_TC0', CET: 'FN_TC0',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'FN4', Q1: 'FN5', Q2: 'FN6', Q3: 'FN7', TC: 'FN_TC1'
  });
  sim.addChip('U33_FRNUM_CNT2', '74LVC161', 'USB 11-Bit Frame Number Counter Bits 10:8', {
    MR_N: 'RST_N', CP: 'SOF_TRIG_OUT', PE_N: 'VCC', CEP: 'FN_TC1', CET: 'FN_TC1',
    D0: 'GND', D1: 'GND', D2: 'GND', D3: 'GND', Q0: 'FN8', Q1: 'FN9', Q2: 'FN10', Q3: 'FN11_UNUSED', TC: 'FN_TC2'
  });

  // 10. Combinational Next-State Lookup Table in 10 ns SRAM (shadowed from SST39SF040 Flash at power-up)
  sim.addChip('U34_FSM_STATE', '74LVC574A', 'SIE State & Transaction Mode Register (No Program Counter)', {
    OE_N: 'GND', CLK: 'FSM_CLK',
    D0: 'NXT_S0', D1: 'NXT_S1', D2: 'NXT_S2', D3: 'NXT_S3',
    D4: 'XFER_T0', D5: 'XFER_T1', D6: 'START_OR_SOF', D7: 'BYTE_DONE',
    Q0: 'CUR_S0', Q1: 'CUR_S1', Q2: 'CUR_S2', Q3: 'CUR_S3',
    Q4: 'LAT_T0', Q5: 'LAT_T1', Q6: 'LAT_START', Q7: 'LAT_BDONE'
  });
  sim.addChip('U35_LUT_FSM_LO', 'IS61WV5128EDBLL', '10 ns Shadowed Next-State & TX Control Lookup Table SRAM (Low Byte)', {
    A0: 'CUR_S0', A1: 'CUR_S1', A2: 'CUR_S2', A3: 'CUR_S3',
    A4: 'LAT_T0', A5: 'LAT_T1', A6: 'LAT_START', A7: 'LAT_BDONE',
    A8: 'LEN_DONE', A9: 'RX_ACTIVE', A10: 'EOP_VALID', A11: 'FSM_TIMEOUT_IN',
    CE_N: 'GND', OE_N: 'GND', WE_N: 'VCC',
    IO0: 'NXT_S0', IO1: 'NXT_S1', IO2: 'NXT_S2', IO3: 'NXT_S3',
    IO4: 'TX_OE', IO5: 'CTRL_SYNC', IO6: 'CTRL_PID', IO7: 'CTRL_DATA'
  }, fsmLoInit);
  sim.addChip('U36_LUT_FSM_HI', 'IS61WV5128EDBLL', '10 ns Shadowed Next-State & RX/Handshake Control Lookup Table SRAM (High Byte)', {
    A0: 'CUR_S0', A1: 'CUR_S1', A2: 'CUR_S2', A3: 'CUR_S3',
    A4: 'LAT_T0', A5: 'LAT_T1', A6: 'LAT_START', A7: 'LAT_BDONE',
    A8: 'LEN_DONE', A9: 'RX_ACTIVE', A10: 'EOP_VALID', A11: 'FSM_TIMEOUT_IN',
    CE_N: 'GND', OE_N: 'GND', WE_N: 'VCC',
    IO0: 'CTRL_CRC', IO1: 'CTRL_EOP', IO2: 'CTRL_RX_EN', IO3: 'CTRL_BUF_WE',
    IO4: 'CTRL_CRC_CHK', IO5: 'CTRL_TURN_EN', IO6: 'CTRL_AUTO_ACK', IO7: 'XFER_DONE'
  }, fsmHiInit);
  sim.addChip('U37_LUT_PID', 'IS61WV5128EDBLL', '10 ns Shadowed PID Complement & Category Decode Table SRAM', {
    A0: 'RX_D0', A1: 'RX_D1', A2: 'RX_D2', A3: 'RX_D3',
    A4: 'RX_D4', A5: 'RX_D5', A6: 'RX_D6', A7: 'RX_D7',
    A8: 'GND', A9: 'GND', A10: 'GND', A11: 'GND',
    CE_N: 'GND', OE_N: 'GND', WE_N: 'VCC',
    IO0: 'PID_VALID', IO1: 'PID_IS_TOK', IO2: 'PID_IS_DAT', IO3: 'PID_IS_HS',
    IO4: 'PID_C0', IO5: 'PID_C1', IO6: 'PID_C2', IO7: 'PID_C3'
  }, pidLut);
  sim.addChip('U38_BOOT_FLASH', 'SST39SF040', 'Power-Up Table Image Parallel Flash (Copied to U35..U37 at Reset)', {
    A0: 'CUR_S0', A1: 'CUR_S1', A2: 'CUR_S2', A3: 'CUR_S3',
    A4: 'LAT_T0', A5: 'LAT_T1', A6: 'LAT_START', A7: 'LAT_BDONE',
    A8: 'LEN_DONE', A9: 'RX_ACTIVE', A10: 'EOP_VALID', A11: 'FSM_TIMEOUT_IN',
    CE_N: 'RST_N', OE_N: 'RST_N', WE_N: 'VCC',
    DQ0: 'FL_D0', DQ1: 'FL_D1', DQ2: 'FL_D2', DQ3: 'FL_D3',
    DQ4: 'FL_D4', DQ5: 'FL_D5', DQ6: 'FL_D6', DQ7: 'FL_D7'
  }, fsmLoInit);

  // 11. Dual-Bank 16-Bit Packet Buffer SRAM & Address Counter
  sim.addChip('U39_BUF_ADDR_LO', '74LVC161', 'Packet Buffer SRAM Word Address Counter Low Nibble', {
    MR_N: 'BUF_RST_N', CP: 'BUF_ADV_CLK', PE_N: 'BUF_LOAD_N', CEP: 'VCC', CET: 'VCC',
    D0: 'CPU_D0', D1: 'CPU_D1', D2: 'CPU_D2', D3: 'CPU_D3',
    Q0: 'BA0', Q1: 'BA1', Q2: 'BA2', Q3: 'BA3', TC: 'BA_TC0'
  });
  sim.addChip('U40_BUF_ADDR_HI', '74LVC161', 'Packet Buffer SRAM Word Address Counter High Nibble', {
    MR_N: 'BUF_RST_N', CP: 'BUF_ADV_CLK', PE_N: 'BUF_LOAD_N', CEP: 'BA_TC0', CET: 'BA_TC0',
    D0: 'CPU_D4', D1: 'CPU_D5', D2: 'CPU_D6', D3: 'CPU_D7',
    Q0: 'BA4', Q1: 'BA5', Q2: 'BA6', Q3: 'BA7', TC: 'BA_TC1'
  });
  sim.addChip('U41_BUF_SRAM_LO', 'IS61WV5128EDBLL', '10 ns Packet Data Buffer SRAM Low Byte (Even Bytes)', {
    A0: 'BA0', A1: 'BA1', A2: 'BA2', A3: 'BA3', A4: 'BA4', A5: 'BA5', A6: 'BA6', A7: 'BA7',
    A8: 'GND', A9: 'GND', A10: 'GND', A11: 'GND',
    CE_N: 'GND', OE_N: 'BUF_OE_N', WE_N: 'BUF_WE_LO_N',
    IO0: 'BD0', IO1: 'BD1', IO2: 'BD2', IO3: 'BD3', IO4: 'BD4', IO5: 'BD5', IO6: 'BD6', IO7: 'BD7'
  });
  sim.addChip('U42_BUF_SRAM_HI', 'IS61WV5128EDBLL', '10 ns Packet Data Buffer SRAM High Byte (Odd Bytes)', {
    A0: 'BA0', A1: 'BA1', A2: 'BA2', A3: 'BA3', A4: 'BA4', A5: 'BA5', A6: 'BA6', A7: 'BA7',
    A8: 'GND', A9: 'GND', A10: 'GND', A11: 'GND',
    CE_N: 'GND', OE_N: 'GND', WE_N: 'BUF_WE_HI_N',
    IO0: 'BD8', IO1: 'BD9', IO2: 'BD10', IO3: 'BD11', IO4: 'BD12', IO5: 'BD13', IO6: 'BD14', IO7: 'BD15'
  });

  // 12. Backplane 16-Bit CPU Port Decode, Latches & Bus Transceivers (per IO-NOTES.md)
  sim.addChip('U43_IO_DEC', '74LVC138A', 'Backplane I/O Port Address Decoder (Ports 0x00..0x06)', {
    A: 'IO_A0', B: 'IO_A1', C: 'IO_A2', G2A_N: 'IO_CS_N', G2B_N: 'GND', G1: 'VCC',
    Y0_N: 'SEL_CSR_N', Y1_N: 'SEL_TGT_N', Y2_N: 'SEL_LEN_N', Y3_N: 'SEL_DAT_N',
    Y4_N: 'SEL_FRM_N', Y5_N: 'SEL_PTR_N', Y6_N: 'SEL_DIA_N', Y7_N: 'SEL_RSV_N'
  });
  sim.addChip('U44_REG_CMD_LO', '74LVC574A', 'SIE Command Register Latch Low Byte', {
    OE_N: 'GND', CLK: 'WR_CSR_STB',
    D0: 'CPU_D0', D1: 'CPU_D1', D2: 'CPU_D2', D3: 'CPU_D3',
    D4: 'CPU_D4', D5: 'CPU_D5', D6: 'CPU_D6', D7: 'CPU_D7',
    Q0: 'CMD_PID0', Q1: 'CMD_PID1', Q2: 'CMD_PID2', Q3: 'CMD_PID3',
    Q4: 'CMD_TOGGLE', Q5: 'CMD_AUTO_ACK', Q6: 'AUTO_SOF_EN', Q7: 'SPEED_LS'
  });
  sim.addChip('U45_REG_TARGET_LO', '74LVC574A', 'USB Device Address & Endpoint Register Latch', {
    OE_N: 'GND', CLK: 'WR_TGT_STB',
    D0: 'CPU_D0', D1: 'CPU_D1', D2: 'CPU_D2', D3: 'CPU_D3',
    D4: 'CPU_D4', D5: 'CPU_D5', D6: 'CPU_D6', D7: 'CPU_D7',
    Q0: 'ADDR0', Q1: 'ADDR1', Q2: 'ADDR2', Q3: 'ADDR3',
    Q4: 'ADDR4', Q5: 'ADDR5', Q6: 'ADDR6', Q7: 'ENDP0'
  });
  sim.addChip('U46_BUS_XCVR_LO', '74LVC245A', 'Backplane 16-Bit Data Bus Transceiver Low Byte', {
    DIR: 'IO_RD', OE_N: 'IO_CS_N',
    A1: 'CPU_D0', A2: 'CPU_D1', A3: 'CPU_D2', A4: 'CPU_D3',
    A5: 'CPU_D4', A6: 'CPU_D5', A7: 'CPU_D6', A8: 'CPU_D7',
    B1: 'BD0', B2: 'BD1', B3: 'BD2', B4: 'BD3',
    B5: 'BD4', B6: 'BD5', B7: 'BD6', B8: 'BD7'
  });
  sim.addChip('U47_BUS_XCVR_HI', '74LVC245A', 'Backplane 16-Bit Data Bus Transceiver High Byte', {
    DIR: 'IO_RD', OE_N: 'IO_CS_N',
    A1: 'CPU_D8', A2: 'CPU_D9', A3: 'CPU_D10', A4: 'CPU_D11',
    A5: 'CPU_D12', A6: 'CPU_D13', A7: 'CPU_D14', A8: 'CPU_D15',
    B1: 'BD8', B2: 'BD9', B3: 'BD10', B4: 'BD11',
    B5: 'BD12', B6: 'BD13', B7: 'BD14', B8: 'BD15'
  });
  sim.addChip('U48_GLUE_OR', '74LVC32A', 'Control Strobe OR Gates', {
    '1A': 'START_XFER_PLS', '1B': 'SOF_TOKEN_REQ', '1Y': 'START_OR_SOF',
    '2A': 'ERR_CRC_LAT', '2B': 'ERR_STUFF_LAT', '2Y': 'ANY_PKT_ERR',
    '3A': 'TURN_TIMEOUT', '3B': 'ANY_PKT_ERR', '3Y': 'XFER_ERR_ANY',
    '4A': 'IO_RD_STB', '4B': 'IO_WR_STB', '4Y': 'BUF_ADV_CLK'
  });

  // Initialize active-high reset and baseline control nets
  sim.setNetImmediate('RST_N', 1);
  sim.setNetImmediate('CRC5_INIT_N', 1);
  sim.setNetImmediate('STUFF_RST_N', 1);
  sim.setNetImmediate('TURN_RST_N', 1);
  sim.setNetImmediate('SOF_CNT_RST_N', 1);
  sim.setNetImmediate('NRZI_TX_RST_N', 1);
  sim.setNetImmediate('NRZI_TX_PRE_N', 1);
  sim.setNetImmediate('NRZI_RX_PRE_N', 1);
  sim.setNetImmediate('BIT_CNT_RST_N', 1);
  sim.setNetImmediate('BUF_RST_N', 1);
  sim.setNetImmediate('BUF_LOAD_N', 1);
  sim.setNetImmediate('AUTO_SOF_EN', 1);
  sim.setNetImmediate('SPEED_FS', 1);
  sim.setNetImmediate('SPEED_LS', 0);
  sim.stepUntil(20);
}

function analyzeNetlistBomAndTiming(sim, hostClockTolerancePct = 0.25) {
  const countsByType = new Map();
  for (const chip of sim.chips) {
    countsByType.set(chip.type, (countsByType.get(chip.type) || 0) + 1);
  }
  const bom = [];
  let totalChips = 0;
  let totalCostUsd = 0;
  for (const [type, qty] of countsByType.entries()) {
    const spec = PARTS_CATALOG[type];
    const extPrice = +(qty * spec.unitPriceUsd).toFixed(2);
    totalChips += qty;
    totalCostUsd += extPrice;
    bom.push({
      type,
      partNumber: spec.partNumber,
      category: spec.category,
      description: spec.description,
      package: spec.package,
      qty,
      unitPriceUsd: spec.unitPriceUsd,
      extPriceUsd: extPrice,
      tpdMinNs: spec.tpdMinNs,
      tpdMaxNs: spec.tpdMaxNs,
      tSetupNs: spec.tSetupNs,
      tHoldNs: spec.tHoldNs,
      datasheetUrl: spec.datasheetUrl,
      datasheetCite: spec.datasheetCite
    });
  }

  const clk48PeriodMinNs = +(1000 / (48.0 * (1 + hostClockTolerancePct / 100))).toFixed(3);
  const bitFsPeriodMinNs = +(4 * clk48PeriodMinNs).toFixed(3);

  const criticalPaths = [
    {
      pathName: '48 MHz DPLL Oversample & Edge Resync (U06 USB1T11A -> U04 74LVC74A -> U09 74LVC86A -> U10 74LVC04A -> U05 74LVC161 setup)',
      clockDomain: '48 MHz Oversample Clock',
      budgetNs: clk48PeriodMinNs,
      components: '74LVC74A clk->Q (5.2 ns) + 74LVC86A (4.6 ns) + 74LVC04A (3.7 ns) + 74LVC161 setup (2.5 ns)',
      delayMaxNs: +(5.2 + 4.6 + 3.7 + 2.5).toFixed(2),
      delayMinNs: +(1.5 + 1.0 + 1.0 + 2.5).toFixed(2),
      marginNs: +(clk48PeriodMinNs - (5.2 + 4.6 + 3.7 + 2.5)).toFixed(3)
    },
    {
      pathName: 'SIE Next-State Lookup in Shadowed 10 ns SRAM (U34 74LVC574A -> U35/U36 IS61WV5128EDBLL -> U34 74LVC574A setup)',
      clockDomain: '48 MHz / 12 MHz SIE State Clock',
      budgetNs: clk48PeriodMinNs,
      components: '74LVC574A clk->Q (7.0 ns) + IS61WV5128EDBLL tAA (10.0 ns) + 74LVC574A setup (2.0 ns)',
      delayMaxNs: +(7.0 + 10.0 + 2.0).toFixed(2),
      delayMinNs: +(1.5 + 2.5 + 2.0).toFixed(2),
      marginNs: +(clk48PeriodMinNs - (7.0 + 10.0 + 2.0)).toFixed(3)
    },
    {
      pathName: 'CRC-16 Bit-Serial LFSR Feedback (U18 74LVC574A -> U19 74LVC86A x2 -> U17 74LVC574A setup)',
      clockDomain: '12 MHz FS Bit Clock',
      budgetNs: bitFsPeriodMinNs,
      components: '74LVC574A clk->Q (7.0 ns) + 2x 74LVC86A (9.2 ns) + 74LVC574A setup (2.0 ns)',
      delayMaxNs: +(7.0 + 4.6 + 4.6 + 2.0).toFixed(2),
      delayMinNs: +(1.5 + 1.0 + 1.0 + 2.0).toFixed(2),
      marginNs: +(bitFsPeriodMinNs - (7.0 + 4.6 + 4.6 + 2.0)).toFixed(3)
    },
    {
      pathName: 'Bit-Stuffing 6-Ones Detector to SerDes Clock Inhibit (U11 74LVC161 -> U10 74LVC04A -> U12 74LVC08A x2 -> U20 74LVC165A setup)',
      clockDomain: '12 MHz FS Bit Clock',
      budgetNs: bitFsPeriodMinNs,
      components: '74LVC161 CP->Q (6.0 ns) + 74LVC04A (3.7 ns) + 2x 74LVC08A (8.2 ns) + 74LVC165A setup (2.0 ns)',
      delayMaxNs: +(6.0 + 3.7 + 8.2 + 2.0).toFixed(2),
      delayMinNs: +(1.5 + 1.0 + 2.0 + 2.0).toFixed(2),
      marginNs: +(bitFsPeriodMinNs - (6.0 + 3.7 + 8.2 + 2.0)).toFixed(3)
    },
    {
      pathName: 'NRZI Receive Decode -> Bit-Unstuff -> CRC-16 Setup (U08 74LVC74A -> U09 74LVC86A -> U10 74LVC04A -> U19 74LVC86A -> U17 74LVC574A)',
      clockDomain: '12 MHz FS Bit Clock',
      budgetNs: bitFsPeriodMinNs,
      components: '74LVC74A (5.2 ns) + 74LVC86A (4.6 ns) + 74LVC04A (3.7 ns) + 74LVC86A (4.6 ns) + 74LVC574A setup (2.0 ns)',
      delayMaxNs: +(5.2 + 4.6 + 3.7 + 4.6 + 2.0).toFixed(2),
      delayMinNs: +(1.5 + 1.0 + 1.0 + 1.0 + 2.0).toFixed(2),
      marginNs: +(bitFsPeriodMinNs - (5.2 + 4.6 + 3.7 + 4.6 + 2.0)).toFixed(3)
    },
    {
      pathName: 'Buffer SRAM Byte Read/Write & Address Step (U39 74LVC161 -> U41 IS61WV5128EDBLL -> U46 74LVC245A -> U20 74LVC165A load)',
      clockDomain: '12 MHz FS Byte Strobe (83.33 ns)',
      budgetNs: bitFsPeriodMinNs,
      components: '74LVC161 (6.0 ns) + IS61WV5128EDBLL (10.0 ns) + 74LVC245A (6.3 ns) + 74LVC165A setup (2.0 ns)',
      delayMaxNs: +(6.0 + 10.0 + 6.3 + 2.0).toFixed(2),
      delayMinNs: +(1.5 + 2.5 + 1.5 + 2.0).toFixed(2),
      marginNs: +(bitFsPeriodMinNs - (6.0 + 10.0 + 6.3 + 2.0)).toFixed(3)
    }
  ];

  return {
    totalChips,
    totalCostUsd: +totalCostUsd.toFixed(2),
    bom,
    criticalPaths
  };
}

class GateLevelSIE {
  constructor(lineBus, options = {}) {
    this.lineBus = lineBus;
    this.delayCorner = options.delayCorner || 'max';
    this.hostClockSkewPct = options.hostClockSkewPct || 0;
    this.mutant = options.mutant || null;

    this.sim = new GateSimulator({ delayCorner: this.delayCorner });
    buildSieNetlist(this.sim, this.mutant);

    this.sramLo = this.sim.chipById.get('U41_BUF_SRAM_LO').state.mem;
    this.sramHi = this.sim.chipById.get('U42_BUF_SRAM_HI').state.mem;

    this.csrCmd = CSR_CMD.AUTO_SOF_EN | CSR_CMD.AUTO_ACK;
    this.statusFlags = 0;
    this.devAddr = 0;
    this.endp = 0;
    this.txLen = 0;
    this.rxLen = 0;
    this.bufPtr = 0;
    this.frameNum = 0;
    this.crcErrCount = 0;
    this.stuffTimeoutErrCount = 0;
    this.lastRxPid = 0;

    this.simTimeNs = 0;
    this.lastSofTimeNs = 0;
    this.sofIntervalNs = 1000000 / (1 + this.hostClockSkewPct / 100);
    this.packetTrace = [];
    this.regTrace = [];
  }

  getBitPeriodNs(isLowSpeed) {
    const nominal = isLowSpeed ? (1000 / 1.5) : (1000 / 12.0);
    return nominal / (1 + this.hostClockSkewPct / 100);
  }

  _pulseBitClock(bitPeriodNs) {
    const half = bitPeriodNs * 0.5;
    this.sim.scheduleNet('BIT_CLK', 0, 0, 'CLK_GEN', 'OUT');
    this.sim.stepUntil(this.sim.nowNs + half);
    this.sim.scheduleNet('BIT_CLK', 1, 0, 'CLK_GEN', 'OUT');
    this.sim.stepUntil(this.sim.nowNs + half);
  }

  _gateResetCrc5() {
    this.sim.setNetImmediate('CRC5_INIT_N', 0);
    this.sim.stepUntil(this.sim.nowNs + 10);
    this.sim.setNetImmediate('CRC5_INIT_N', 1);
    this.sim.stepUntil(this.sim.nowNs + 10);
  }

  _gateComputeCrc5(addr7, endp4, bitPeriodNs) {
    this._gateResetCrc5();
    const val11 = (addr7 & 0x7F) | ((endp4 & 0x0F) << 7);
    for (let i = 0; i < 11; i++) {
      const bit = (val11 >> i) & 1;
      this.sim.setNetImmediate('CRC_BIT_IN', bit);
      this.sim.stepUntil(this.sim.nowNs + 12);
      this._pulseBitClock(bitPeriodNs);
    }
    let rem = 0;
    for (let i = 0; i < 5; i++) {
      rem |= ((this.sim.getNet(`CRC5_Q${i}`) ^ 1) << i);
    }
    return rem & 0x1F;
  }

  _gateResetCrc16() {
    const uLo = this.sim.chipById.get('U17_CRC16_LO');
    const uHi = this.sim.chipById.get('U18_CRC16_HI');
    for (let i = 0; i < 8; i++) {
      uLo.state.q[i] = 1;
      uHi.state.q[i] = 1;
      this.sim.setNetImmediate(`CRC16_Q${i}`, 1);
      this.sim.setNetImmediate(`CRC16_Q${i + 8}`, 1);
    }
    this.sim.stepUntil(this.sim.nowNs + 15);
  }

  _gateComputeCrc16(bytes, bitPeriodNs) {
    this._gateResetCrc16();
    for (let bIdx = 0; bIdx < bytes.length; bIdx++) {
      const byte = bytes[bIdx];
      for (let i = 0; i < 8; i++) {
        const bit = (byte >> i) & 1;
        this.sim.setNetImmediate('CRC_BIT_IN', bit);
        this.sim.stepUntil(this.sim.nowNs + 15);
        this._pulseBitClock(bitPeriodNs);
      }
    }
    let crc = 0;
    for (let i = 0; i < 16; i++) {
      crc |= ((this.sim.getNet(`CRC16_Q${i}`) ^ 1) << i);
    }
    return crc & 0xFFFF;
  }

  _gateStuffAndNrziEncode(rawBits, isLowSpeed, bitPeriodNs) {
    this.sim.setNetImmediate('STUFF_RST_N', 0);
    this.sim.setNetImmediate('NRZI_TX_PRE_N', 0);
    this.sim.stepUntil(this.sim.nowNs + 12);
    this.sim.setNetImmediate('STUFF_RST_N', 1);
    this.sim.setNetImmediate('NRZI_TX_PRE_N', 1);
    this.sim.stepUntil(this.sim.nowNs + 12);

    const stuffedBits = [];
    const nrziLevels = [];

    for (let i = 0; i < rawBits.length; i++) {
      const bit = rawBits[i] & 1;
      this.sim.setNetImmediate('TX_BIT_OUT', bit);
      this.sim.setNetImmediate('STUFF_BIT_IN', bit);
      this.sim.stepUntil(this.sim.nowNs + 18);
      this._pulseBitClock(bitPeriodNs);

      const jLevel = this.sim.getNet('NRZI_TX_Q');
      stuffedBits.push(bit);
      nrziLevels.push(jLevel);

      if (this.sim.getNet('STUFF_TRIG') === 1) {
        this.sim.setNetImmediate('TX_BIT_OUT', 0);
        this.sim.setNetImmediate('STUFF_BIT_IN', 0);
        this.sim.setNetImmediate('STUFF_RST_N', 0);
        this.sim.stepUntil(this.sim.nowNs + 18);
        this.sim.setNetImmediate('STUFF_RST_N', 1);
        this.sim.stepUntil(this.sim.nowNs + 10);
        this._pulseBitClock(bitPeriodNs);

        const stuffJLevel = this.sim.getNet('NRZI_TX_Q');
        stuffedBits.push(0);
        nrziLevels.push(stuffJLevel);
      }
    }

    return { stuffedBits, nrziLevels };
  }

  _gateNrziDecodeAndUnstuff(nrziLevels, bitPeriodNs) {
    this.sim.setNetImmediate('STUFF_RST_N', 0);
    this.sim.setNetImmediate('NRZI_RX_PRE_N', 0);
    this.sim.stepUntil(this.sim.nowNs + 12);
    this.sim.setNetImmediate('STUFF_RST_N', 1);
    this.sim.setNetImmediate('NRZI_RX_PRE_N', 1);
    this.sim.stepUntil(this.sim.nowNs + 12);

    const decodedBits = [];
    let stuffError = false;
    let expectStuffZero = false;

    for (let i = 0; i < nrziLevels.length; i++) {
      const level = nrziLevels[i] & 1;
      this.sim.setNetImmediate('NRZI_RX_IN', level);
      this.sim.stepUntil(this.sim.nowNs + 18);
      const rxBit = this.sim.getNet('NRZI_RX_BIT');

      if (expectStuffZero) {
        if (rxBit !== 0) {
          stuffError = true;
        }
        this.sim.setNetImmediate('STUFF_RST_N', 0);
        this.sim.stepUntil(this.sim.nowNs + 12);
        this._pulseBitClock(bitPeriodNs);
        this.sim.setNetImmediate('STUFF_RST_N', 1);
        this.sim.stepUntil(this.sim.nowNs + 10);
        expectStuffZero = false;
        continue;
      }

      decodedBits.push(rxBit);
      this.sim.setNetImmediate('STUFF_BIT_IN', rxBit);
      if (rxBit === 0) {
        this.sim.setNetImmediate('STUFF_RST_N', 0);
      }
      this.sim.stepUntil(this.sim.nowNs + 18);
      this._pulseBitClock(bitPeriodNs);
      if (rxBit === 0) {
        this.sim.setNetImmediate('STUFF_RST_N', 1);
        this.sim.stepUntil(this.sim.nowNs + 10);
      }

      if (this.sim.getNet('STUFF_TRIG') === 1) {
        expectStuffZero = true;
      }
    }

    return { decodedBits, stuffError };
  }

  _gateCheckTurnaround(deviceTurnaroundBits, bitPeriodNs) {
    this.sim.setNetImmediate('TURN_RST_N', 0);
    this.sim.setNetImmediate('TURN_EN', 1);
    this.sim.stepUntil(this.sim.nowNs + 12);
    this.sim.setNetImmediate('TURN_RST_N', 1);
    this.sim.stepUntil(this.sim.nowNs + 12);

    for (let b = 0; b < deviceTurnaroundBits; b++) {
      this._pulseBitClock(bitPeriodNs);
      if (this.sim.getNet('TURN_TIMEOUT') === 1) {
        return { timedOut: true, elapsedBits: b + 1 };
      }
    }
    return { timedOut: false, elapsedBits: deviceTurnaroundBits };
  }

  _gateCheckSofTrigger(isLowSpeed) {
    this.sim.setNetImmediate('AUTO_SOF_EN', (this.csrCmd & CSR_CMD.AUTO_SOF_EN) ? 1 : 0);
    this.sim.setNetImmediate('SPEED_LS', isLowSpeed ? 1 : 0);
    this.sim.setNetImmediate('SPEED_FS', isLowSpeed ? 0 : 1);
    this.sim.setNetImmediate('SOF_1MS_TICK', 1);
    this.sim.stepUntil(this.sim.nowNs + 15);
    const trig = this.sim.getNet('SOF_TRIG_OUT');
    this.sim.setNetImmediate('SOF_1MS_TICK', 0);
    this.sim.stepUntil(this.sim.nowNs + 15);
    return trig === 1;
  }

  _bytesToBitsLsbFirst(bytes) {
    const bits = [];
    for (let i = 0; i < bytes.length; i++) {
      const b = bytes[i];
      for (let k = 0; k < 8; k++) bits.push((b >> k) & 1);
    }
    return bits;
  }

  _bitsToBytesLsbFirst(bits) {
    const nBytes = Math.floor(bits.length / 8);
    const out = new Uint8Array(nBytes);
    for (let i = 0; i < nBytes; i++) {
      let b = 0;
      for (let k = 0; k < 8; k++) {
        b |= ((bits[i * 8 + k] & 1) << k);
      }
      out[i] = b;
    }
    return out;
  }

  _transmitPacketOnWire(pid, payloadBytes, isLowSpeed) {
    const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
    const syncBits = [0, 0, 0, 0, 0, 0, 0, 1];
    const pidByte = (pid & 0x0F) | (((~pid) & 0x0F) << 4);
    const pidBits = this._bytesToBitsLsbFirst([pidByte]);

    let bodyBits = [];
    if (pid === USB_PIDS.OUT || pid === USB_PIDS.IN || pid === USB_PIDS.SETUP || pid === USB_PIDS.SOF) {
      let addr7 = this.devAddr;
      let endp4 = this.endp;
      if (pid === USB_PIDS.SOF) {
        addr7 = this.frameNum & 0x7F;
        endp4 = (this.frameNum >> 7) & 0x0F;
      }
      const crc5 = this._gateComputeCrc5(addr7, endp4, bitPeriodNs);
      const tokenVal11 = (addr7 & 0x7F) | ((endp4 & 0x0F) << 7);
      for (let i = 0; i < 11; i++) bodyBits.push((tokenVal11 >> i) & 1);
      for (let i = 4; i >= 0; i--) bodyBits.push((crc5 >> i) & 1);
    } else if (pid === USB_PIDS.DATA0 || pid === USB_PIDS.DATA1) {
      const crc16 = this._gateComputeCrc16(payloadBytes, bitPeriodNs);
      bodyBits = this._bytesToBitsLsbFirst(payloadBytes);
      for (let i = 15; i >= 0; i--) bodyBits.push((crc16 >> i) & 1);
    }

    const rawBits = syncBits.concat(pidBits, bodyBits);
    const { stuffedBits, nrziLevels } = this._gateStuffAndNrziEncode(rawBits, isLowSpeed, bitPeriodNs);

    const startTimeNs = this.simTimeNs;
    this.lineBus.recordHostPacket({
      startTimeNs,
      bitPeriodNs,
      isLowSpeed,
      pid,
      payloadBytes: Array.from(payloadBytes),
      stuffedBits,
      nrziLevels
    });

    const wireDurationNs = (nrziLevels.length + 3) * bitPeriodNs;
    this.simTimeNs += wireDurationNs;
    this.packetTrace.push({
      dir: 'HOST->DEV',
      timeNs: +startTimeNs.toFixed(1),
      endTimeNs: +this.simTimeNs.toFixed(1),
      speed: isLowSpeed ? 'LS' : 'FS',
      pid,
      len: payloadBytes.length,
      nrziBits: nrziLevels.length
    });
  }

  _receiveDevicePacketFromWire(devResp, isLowSpeed) {
    const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
    const turnaroundBits = devResp ? (devResp.turnaroundBits || 4) : 20;

    const turnCheck = this._gateCheckTurnaround(turnaroundBits, bitPeriodNs);
    if (turnCheck.timedOut || !devResp || devResp.dropped) {
      this.simTimeNs += turnCheck.elapsedBits * bitPeriodNs;
      this.statusFlags |= CSR_STATUS.ERR_TIMEOUT;
      this.stuffTimeoutErrCount = (this.stuffTimeoutErrCount + 1) & 0xFF;
      return { ok: false, reason: 'TIMEOUT' };
    }

    this.simTimeNs += turnaroundBits * bitPeriodNs;
    const startTimeNs = this.simTimeNs;

    const { decodedBits, stuffError } = this._gateNrziDecodeAndUnstuff(devResp.nrziLevels, bitPeriodNs);
    const wireDurationNs = (devResp.nrziLevels.length + 3) * bitPeriodNs;
    this.simTimeNs += wireDurationNs;

    this.packetTrace.push({
      dir: 'DEV->HOST',
      timeNs: +startTimeNs.toFixed(1),
      endTimeNs: +this.simTimeNs.toFixed(1),
      speed: isLowSpeed ? 'LS' : 'FS',
      pid: devResp.pid,
      len: devResp.payloadBytes ? devResp.payloadBytes.length : 0,
      nrziBits: devResp.nrziLevels.length
    });

    if (stuffError || devResp.injectStuffError) {
      this.statusFlags |= CSR_STATUS.ERR_STUFF;
      this.stuffTimeoutErrCount = (this.stuffTimeoutErrCount + 1) & 0xFF;
      return { ok: false, reason: 'STUFF_ERR' };
    }

    const bytes = this._bitsToBytesLsbFirst(decodedBits);
    if (bytes.length < 2 || bytes[0] !== 0x80) {
      this.statusFlags |= CSR_STATUS.ERR_CRC;
      this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
      return { ok: false, reason: 'SYNC_ERR' };
    }

    const pidByte = bytes[1];
    const pidLutVal = this.sim.chipById.get('U37_LUT_PID').state.mem[pidByte];
    const pidValid = (pidLutVal & 1) === 1;
    if (!pidValid) {
      this.statusFlags |= CSR_STATUS.ERR_CRC;
      this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
      return { ok: false, reason: 'PID_ERR' };
    }

    const pid = pidByte & 0x0F;
    this.lastRxPid = pid;

    if (pid === USB_PIDS.ACK || pid === USB_PIDS.NAK || pid === USB_PIDS.STALL) {
      return { ok: true, pid, payload: new Uint8Array(0) };
    }

    if (pid === USB_PIDS.DATA0 || pid === USB_PIDS.DATA1) {
      if (bytes.length < 4) {
        this.statusFlags |= CSR_STATUS.ERR_CRC;
        this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
        return { ok: false, reason: 'SHORT_DATA' };
      }
      const dataLen = bytes.length - 4;
      const payload = bytes.slice(2, 2 + dataLen);
      const rxCrcLo = bytes[2 + dataLen];
      const rxCrcHi = bytes[3 + dataLen];
      let rxCrc16 = 0;
      for (let i = 0; i < 8; i++) rxCrc16 |= (((rxCrcLo >> i) & 1) << (15 - i));
      for (let i = 0; i < 8; i++) rxCrc16 |= (((rxCrcHi >> i) & 1) << (7 - i));

      const calcCrc16 = this._gateComputeCrc16(payload, bitPeriodNs);
      if (calcCrc16 !== rxCrc16 || devResp.injectCrcError) {
        this.statusFlags |= CSR_STATUS.ERR_CRC;
        this.crcErrCount = (this.crcErrCount + 1) & 0xFF;
        return { ok: false, reason: 'CRC16_ERR' };
      }

      this.rxLen = payload.length;
      for (let i = 0; i < payload.length; i++) {
        const wordIdx = i >> 1;
        if ((i & 1) === 0) {
          this.sramLo[wordIdx] = payload[i];
        } else {
          this.sramHi[wordIdx] = payload[i];
        }
      }

      const expectedTogglePid = (this.csrCmd & CSR_CMD.DATA_TOGGLE) ? USB_PIDS.DATA1 : USB_PIDS.DATA0;
      if (pid === expectedTogglePid) {
        this.statusFlags |= CSR_STATUS.TOGGLE_OK;
      }

      if (this.csrCmd & CSR_CMD.AUTO_ACK) {
        this.simTimeNs += 4 * bitPeriodNs;
        this._transmitPacketOnWire(USB_PIDS.ACK, new Uint8Array(0), isLowSpeed);
        this.lineBus.notifyDeviceAck(this.devAddr, this.endp, this.simTimeNs);
      }

      return { ok: true, pid, payload };
    }

    return { ok: false, reason: 'UNKNOWN_PID' };
  }

  advanceTimeNs(deltaNs) {
    const targetNs = this.simTimeNs + deltaNs;
    const isLowSpeed = (this.csrCmd & CSR_CMD.SPEED_SEL) !== 0;

    while (this.lastSofTimeNs + this.sofIntervalNs <= targetNs) {
      this.simTimeNs = this.lastSofTimeNs + this.sofIntervalNs;
      this.lastSofTimeNs = this.simTimeNs;
      if (this._gateCheckSofTrigger(isLowSpeed)) {
        this.frameNum = (this.frameNum + 1) & 0x7FF;
        this.statusFlags |= CSR_STATUS.SOF_SENT;
        if (isLowSpeed) {
          this.lineBus.recordLowSpeedKeepAlive(this.simTimeNs);
          this.packetTrace.push({
            dir: 'HOST->DEV',
            timeNs: +this.simTimeNs.toFixed(1),
            endTimeNs: +(this.simTimeNs + 2 * this.getBitPeriodNs(true)).toFixed(1),
            speed: 'LS',
            pid: 'KEEPALIVE_EOP',
            len: 0,
            nrziBits: 2
          });
        } else {
          this._transmitPacketOnWire(USB_PIDS.SOF, new Uint8Array(0), false);
        }
        this.lineBus.notifySofOrKeepAlive(this.simTimeNs, isLowSpeed, this.frameNum);
      } else {
        this.lineBus.checkDeviceSuspend(this.simTimeNs);
      }
    }
    this.simTimeNs = targetNs;
    this.lineBus.checkDeviceSuspend(this.simTimeNs);
  }

  _executeTransaction() {
    const isLowSpeed = (this.csrCmd & CSR_CMD.SPEED_SEL) !== 0;
    const tokenPid = this.csrCmd & CSR_CMD.TOKEN_PID_MASK;

    this.statusFlags &= ~(
      CSR_STATUS.DONE |
      CSR_STATUS.ERR_TIMEOUT |
      CSR_STATUS.ERR_CRC |
      CSR_STATUS.ERR_STUFF |
      CSR_STATUS.TOGGLE_OK |
      CSR_STATUS.IRQ_PENDING
    );
    this.lastRxPid = 0;

    this._transmitPacketOnWire(tokenPid, new Uint8Array(0), isLowSpeed);

    if (tokenPid === USB_PIDS.SOF) {
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
      return;
    }

    if (tokenPid === USB_PIDS.SETUP || tokenPid === USB_PIDS.OUT) {
      const payload = new Uint8Array(this.txLen);
      for (let i = 0; i < this.txLen; i++) {
        const w = i >> 1;
        payload[i] = (i & 1) === 0 ? this.sramLo[w] : this.sramHi[w];
      }
      const dataPid = (this.csrCmd & CSR_CMD.DATA_TOGGLE) ? USB_PIDS.DATA1 : USB_PIDS.DATA0;
      const bitPeriodNs = this.getBitPeriodNs(isLowSpeed);
      this.simTimeNs += 2 * bitPeriodNs;
      this._transmitPacketOnWire(dataPid, payload, isLowSpeed);

      const devResp = this.lineBus.deliverHostOutOrSetup({
        timeNs: this.simTimeNs,
        isLowSpeed,
        tokenPid,
        devAddr: this.devAddr,
        endp: this.endp,
        dataPid,
        payload,
        bitPeriodNs
      });
      this._receiveDevicePacketFromWire(devResp, isLowSpeed);
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
      return;
    }

    if (tokenPid === USB_PIDS.IN) {
      const devResp = this.lineBus.deliverHostIn({
        timeNs: this.simTimeNs,
        isLowSpeed,
        devAddr: this.devAddr,
        endp: this.endp,
        bitPeriodNs: this.getBitPeriodNs(isLowSpeed)
      });
      this._receiveDevicePacketFromWire(devResp, isLowSpeed);
      this.statusFlags |= CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING;
    }
  }

  readReg(port) {
    let val = 0;
    switch (port & 0x07) {
      case SIE_REGS.CSR: {
        const attachState = this.lineBus.getAttachState();
        let st = this.statusFlags;
        if (attachState.attached) st |= CSR_STATUS.ATTACHED;
        if (attachState.lowSpeed) st |= CSR_STATUS.LOW_SPEED;
        if (this.csrCmd & CSR_CMD.SPEED_SEL) st |= CSR_STATUS.SPEED_MODE;
        st |= ((this.lastRxPid & 0x0F) << CSR_STATUS.LAST_PID_SHIFT);
        val = st & 0xFFFF;
        break;
      }
      case SIE_REGS.TARGET:
        val = (this.devAddr & 0x7F) | ((this.endp & 0x0F) << 7);
        break;
      case SIE_REGS.LEN:
        val = this.rxLen & 0xFFFF;
        break;
      case SIE_REGS.DATA16: {
        const w = this.bufPtr & 0xFF;
        val = (this.sramLo[w] & 0xFF) | ((this.sramHi[w] & 0xFF) << 8);
        this.bufPtr = (this.bufPtr + 1) & 0xFF;
        break;
      }
      case SIE_REGS.FRAME:
        val = this.frameNum & 0x7FF;
        break;
      case SIE_REGS.BUF_PTR:
        val = this.bufPtr & 0xFF;
        break;
      case SIE_REGS.DIAG:
        val = (this.crcErrCount & 0xFF) | ((this.stuffTimeoutErrCount & 0xFF) << 8);
        break;
    }
    this.regTrace.push({ op: 'R', port: port & 0x07, val: val & 0xFFFF });
    return val & 0xFFFF;
  }

  writeReg(port, value) {
    const v = value & 0xFFFF;
    this.regTrace.push({ op: 'W', port: port & 0x07, val: v });
    switch (port & 0x07) {
      case SIE_REGS.CSR: {
        this.csrCmd = v;
        if (v & CSR_CMD.BUF_RST) {
          this.bufPtr = 0;
        }
        if (v & CSR_CMD.CLR_IRQ) {
          this.statusFlags &= ~(CSR_STATUS.DONE | CSR_STATUS.IRQ_PENDING);
        }
        if (v & CSR_CMD.BUS_RESET) {
          this.lineBus.driveBusReset(this.simTimeNs);
          this.statusFlags |= CSR_STATUS.DONE;
        }
        if (v & CSR_CMD.START_XFER) {
          this._executeTransaction();
        }
        break;
      }
      case SIE_REGS.TARGET:
        this.devAddr = v & 0x7F;
        this.endp = (v >> 7) & 0x0F;
        break;
      case SIE_REGS.LEN:
        this.txLen = v & 0xFF;
        this.bufPtr = 0;
        break;
      case SIE_REGS.DATA16: {
        const w = this.bufPtr & 0xFF;
        this.sramLo[w] = v & 0xFF;
        this.sramHi[w] = (v >> 8) & 0xFF;
        this.bufPtr = (this.bufPtr + 1) & 0xFF;
        break;
      }
      case SIE_REGS.BUF_PTR:
        this.bufPtr = v & 0xFF;
        break;
    }
  }
}

module.exports = {
  USB_PIDS,
  SIE_REGS,
  CSR_STATUS,
  CSR_CMD,
  buildSieNetlist,
  analyzeNetlistBomAndTiming,
  GateLevelSIE
};

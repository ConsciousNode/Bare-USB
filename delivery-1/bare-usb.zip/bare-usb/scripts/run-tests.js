#!/usr/bin/env node
/**
 * Bare USB — Automated Verification Suite (Tests 1..8) & `results.jsonl` Generator
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Exercises all 8 tests specified in `SPEC.md`:
 *  1. Differential (Gate-Level SIE vs Behavioral Reference SIE)
 *  2. Corners (min/max gate delays, ±0.25% FS host/device clocks, ±1.5% LS device clocks)
 *  3. Enumeration (FS Mass-Storage + 64 KB FAT16 file SHA-256; LS HID Keyboard + 100 keystrokes)
 *  4. Positive controls that must fail (5 netlist mutants: crc16_tap_moved, bit_stuff_off_by_one,
 *     nrzi_rx_inverted, turnaround_short, sof_missing)
 *  5. Error injection (corrupted CRC16, bit-stuffing error, dropped handshake -> detected & retried)
 *  6. CPU budget (register accesses per transfer, CPU µs per 1 ms frame at 10 µs/access)
 *  7. Static scan (no forbidden part types, no PC/sequencer, strict simulator module isolation)
 *  8. Determinism (two fixed-seed runs produce byte-identical wire and register traces)
 */

'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { PARTS_CATALOG, FORBIDDEN_PART_PATTERNS } = require('../src/parts-library');
const { GateSimulator } = require('../src/simulator');
const {
  USB_PIDS,
  SIE_REGS,
  CSR_STATUS,
  CSR_CMD,
  buildSieNetlist,
  analyzeNetlistBomAndTiming,
  GateLevelSIE
} = require('../src/netlist');
const { UsbLineModel } = require('../src/line-model');
const { ReferenceSIE } = require('../src/ref-sie');
const {
  generateScriptedKeystrokes,
  LowSpeedHidKeyboardDevice,
  buildFat16TestImage,
  FullSpeedMassStorageDevice
} = require('../src/devices');
const { UsbHostDriver } = require('../src/driver');
const { computeTablesDigest } = require('./generate-tables');

const ROOT_DIR = path.resolve(__dirname, '..');

function sha256Hex(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

function computeCodeHashes() {
  const relFiles = [
    'src/parts-library.js',
    'src/simulator.js',
    'src/netlist.js',
    'src/line-model.js',
    'src/ref-sie.js',
    'src/devices.js',
    'src/driver.js',
    'scripts/generate-tables.js',
    'scripts/run-tests.js'
  ];
  const hashes = {};
  const combined = crypto.createHash('sha256');
  for (const rel of relFiles) {
    const full = path.join(ROOT_DIR, rel);
    if (fs.existsSync(full)) {
      const content = fs.readFileSync(full);
      const h = sha256Hex(content);
      hashes[rel] = h;
      combined.update(rel + ':' + h + '\n');
    }
  }
  return {
    files: hashes,
    combinedSha256: combined.digest('hex'),
    tablesDigest: computeTablesDigest()
  };
}

/**
 * Helper: runs a workload on either GateLevelSIE or ReferenceSIE.
 */
function executeWorkload({
  useReference = false,
  delayCorner = 'max',
  hostClockSkewPct = 0,
  devClockSkewPct = 0,
  mutant = null,
  deviceType = 'msc', // 'msc' | 'hid'
  fileSectorsToRead = 128, // 128 sectors = 64 KB
  hidKeystrokesToRead = 100,
  errorInjections = []
}) {
  const line = new UsbLineModel();
  for (const inj of errorInjections) {
    line.scheduleErrorInjection(inj);
  }

  const device = deviceType === 'hid'
    ? new LowSpeedHidKeyboardDevice({ clockSkewPct: devClockSkewPct, seed: 42 })
    : new FullSpeedMassStorageDevice({ clockSkewPct: devClockSkewPct, seed: 20261118 });

  line.attachDevice(device);

  const sie = useReference
    ? new ReferenceSIE(line, { hostClockSkewPct })
    : new GateLevelSIE(line, { delayCorner, hostClockSkewPct, mutant });

  const driver = new UsbHostDriver(sie);

  const enumRes = driver.enumerateDevice(1);
  if (!enumRes.ok) {
    return {
      ok: false,
      stage: 'ENUMERATION',
      reason: enumRes.reason || enumRes.stage,
      sie,
      driver,
      line,
      device
    };
  }

  if (deviceType === 'hid') {
    // Advance across multiple 1 ms frames so keep-alive / SOF is also exercised across > 5 ms
    for (let f = 0; f < 5; f++) {
      driver.in16(SIE_REGS.FRAME);
      sie.advanceTimeNs(900000);
    }
    const frameAfterWait = driver.in16(SIE_REGS.FRAME);
    const keyRes = driver.readHidKeystrokes(1, hidKeystrokesToRead);
    if (!keyRes.ok) {
      return {
        ok: false,
        stage: 'HID_KEYSTROKES',
        reason: keyRes.reason,
        frameAfterWait,
        sie,
        driver,
        line,
        device
      };
    }
    // Verify all keystrokes match expected sequence
    const expected = generateScriptedKeystrokes(hidKeystrokesToRead, 42);
    let exactMatches = 0;
    for (let i = 0; i < hidKeystrokesToRead; i++) {
      const a = keyRes.reports[i];
      const b = expected[i];
      if (a && a.length === 8 && Buffer.from(a).equals(Buffer.from(b))) {
        exactMatches++;
      }
    }
    return {
      ok: exactMatches === hidKeystrokesToRead && frameAfterWait > 0,
      stage: 'COMPLETE',
      exactMatches,
      frameAfterWait,
      sie,
      driver,
      line,
      device
    };
  } else {
    // Mass Storage
    if (fileSectorsToRead === 128) {
      const fileRes = driver.readFat16File64KB(1);
      if (!fileRes.ok) {
        return {
          ok: false,
          stage: fileRes.stage || 'READ_FAT16_64KB',
          reason: fileRes.reason,
          sie,
          driver,
          line,
          device
        };
      }
      const hashMatch = fileRes.sha256 === device.image.expectedSha256;
      const frameEnd = driver.in16(SIE_REGS.FRAME);
      return {
        ok: hashMatch && frameEnd > 0,
        stage: 'COMPLETE',
        fileSize: fileRes.fileSize,
        fileSha256: fileRes.sha256,
        expectedSha256: device.image.expectedSha256,
        hashMatch,
        frameEnd,
        sie,
        driver,
        line,
        device
      };
    } else {
      // Short sector read for rapid corner/differential checks
      const botState = { outToggle: 0, inToggle: 0 };
      const secRes = driver.scsiReadSectors(1, 32, fileSectorsToRead, botState);
      if (!secRes.ok) {
        return {
          ok: false,
          stage: 'SCSI_READ_SHORT',
          reason: secRes.reason,
          sie,
          driver,
          line,
          device
        };
      }
      const expectedSlice = device.image.fileBytes.slice(0, fileSectorsToRead * 512);
      const actualHash = sha256Hex(secRes.data);
      const expectedHash = sha256Hex(expectedSlice);
      const frameEnd = driver.in16(SIE_REGS.FRAME);
      return {
        ok: actualHash === expectedHash && frameEnd > 0,
        stage: 'COMPLETE',
        bytesRead: secRes.data.length,
        actualHash,
        expectedHash,
        frameEnd,
        sie,
        driver,
        line,
        device
      };
    }
  }
}

// ============================================================================
// TEST 1: Differential (Gate-Level SIE vs Reference SIE)
// ============================================================================
function runTest1Differential() {
  // Run both FS Mass Storage and LS HID Keyboard on Gate-Level SIE vs Reference SIE
  const gateMsc = executeWorkload({ useReference: false, deviceType: 'msc', fileSectorsToRead: 8 });
  const refMsc  = executeWorkload({ useReference: true,  deviceType: 'msc', fileSectorsToRead: 8 });

  const gateHid = executeWorkload({ useReference: false, deviceType: 'hid', hidKeystrokesToRead: 25 });
  const refHid  = executeWorkload({ useReference: true,  deviceType: 'hid', hidKeystrokesToRead: 25 });

  const gateMscPktHash = sha256Hex(JSON.stringify(gateMsc.sie.packetTrace));
  const refMscPktHash  = sha256Hex(JSON.stringify(refMsc.sie.packetTrace));
  const gateMscRegHash = sha256Hex(JSON.stringify(gateMsc.sie.regTrace));
  const refMscRegHash  = sha256Hex(JSON.stringify(refMsc.sie.regTrace));

  const gateHidPktHash = sha256Hex(JSON.stringify(gateHid.sie.packetTrace));
  const refHidPktHash  = sha256Hex(JSON.stringify(refHid.sie.packetTrace));
  const gateHidRegHash = sha256Hex(JSON.stringify(gateHid.sie.regTrace));
  const refHidRegHash  = sha256Hex(JSON.stringify(refHid.sie.regTrace));

  const passed =
    gateMsc.ok && refMsc.ok &&
    gateHid.ok && refHid.ok &&
    gateMscPktHash === refMscPktHash &&
    gateMscRegHash === refMscRegHash &&
    gateHidPktHash === refHidPktHash &&
    gateHidRegHash === refHidRegHash;

  return {
    testId: 1,
    name: 'Differential (Gate-Level SIE vs Reference SIE)',
    passed,
    fsMscPackets: gateMsc.sie.packetTrace.length,
    fsMscRegOps: gateMsc.sie.regTrace.length,
    fsMscPacketTraceSha256: gateMscPktHash,
    refMscPacketTraceSha256: refMscPktHash,
    fsMscRegTraceSha256: gateMscRegHash,
    refMscRegTraceSha256: refMscRegHash,
    lsHidPackets: gateHid.sie.packetTrace.length,
    lsHidRegOps: gateHid.sie.regTrace.length,
    lsHidPacketTraceSha256: gateHidPktHash,
    refHidPacketTraceSha256: refHidPktHash,
    lsHidRegTraceSha256: gateHidRegHash,
    refHidRegTraceSha256: refHidRegHash
  };
}

// ============================================================================
// TEST 2: Corners (min/max gate delays, ±0.25% FS clock, ±1.5% LS clock)
// ============================================================================
function runTest2Corners() {
  const cornerConfigs = [
    { label: 'FS_MIN_DELAY_FAST_CLK', delayCorner: 'min', hostClockSkewPct: +0.25, devClockSkewPct: -0.25, deviceType: 'msc' },
    { label: 'FS_MAX_DELAY_SLOW_CLK', delayCorner: 'max', hostClockSkewPct: -0.25, devClockSkewPct: +0.25, deviceType: 'msc' },
    { label: 'FS_MAX_DELAY_FAST_CLK', delayCorner: 'max', hostClockSkewPct: +0.25, devClockSkewPct: -0.25, deviceType: 'msc' },
    { label: 'LS_MIN_DELAY_FAST_CLK', delayCorner: 'min', hostClockSkewPct: +0.25, devClockSkewPct: -1.50, deviceType: 'hid' },
    { label: 'LS_MAX_DELAY_SLOW_CLK', delayCorner: 'max', hostClockSkewPct: -0.25, devClockSkewPct: +1.50, deviceType: 'hid' }
  ];

  const corners = [];
  let allPassed = true;
  let totalViolations = 0;

  for (const cfg of cornerConfigs) {
    const res = executeWorkload({
      useReference: false,
      delayCorner: cfg.delayCorner,
      hostClockSkewPct: cfg.hostClockSkewPct,
      devClockSkewPct: cfg.devClockSkewPct,
      deviceType: cfg.deviceType,
      fileSectorsToRead: 4,
      hidKeystrokesToRead: 20
    });
    const violations = res.sie.sim.timingViolations.length;
    totalViolations += violations;
    const cornerOk = res.ok && violations === 0;
    if (!cornerOk) allPassed = false;
    corners.push({
      label: cfg.label,
      delayCorner: cfg.delayCorner,
      hostClockSkewPct: cfg.hostClockSkewPct,
      devClockSkewPct: cfg.devClockSkewPct,
      passed: cornerOk,
      setupHoldViolations: violations,
      minSetupSlackNs: +res.sie.sim.minSetupSlackNs.toFixed(2),
      worstSetupPath: res.sie.sim.worstSetupPath,
      gateEvaluations: res.sie.sim.totalGateEvaluations,
      pinEvents: res.sie.sim.totalPinEvents
    });
  }

  return {
    testId: 2,
    name: 'Corners (Min/Max Gate Delays & USB Spec Clock Tolerance Limits)',
    passed: allPassed,
    totalSetupHoldViolations: totalViolations,
    corners
  };
}

// ============================================================================
// TEST 3: Full Enumeration, 64 KB File Read & 100 Scripted Keystrokes
// ============================================================================
function runTest3Enumeration() {
  const mscRes = executeWorkload({
    useReference: false,
    delayCorner: 'max',
    deviceType: 'msc',
    fileSectorsToRead: 128 // Full 64 KB (65,536 bytes)
  });

  const hidRes = executeWorkload({
    useReference: false,
    delayCorner: 'max',
    deviceType: 'hid',
    hidKeystrokesToRead: 100 // Full 100 keystrokes
  });

  const passed =
    mscRes.ok &&
    mscRes.fileSize === 65536 &&
    mscRes.hashMatch &&
    hidRes.ok &&
    hidRes.exactMatches === 100 &&
    mscRes.sie.sim.timingViolations.length === 0 &&
    hidRes.sie.sim.timingViolations.length === 0;

  return {
    testId: 3,
    name: 'Enumeration (FS Mass-Storage 64 KB File & LS HID Keyboard 100 Keystrokes)',
    passed,
    fsMassStorage: {
      enumerated: mscRes.ok,
      vid: '0x435A',
      pid: '0x0002',
      fileName: 'TEST64K.BIN',
      fileSizeBytes: mscRes.fileSize,
      expectedSha256: mscRes.expectedSha256,
      measuredSha256: mscRes.fileSha256,
      hashVerified: mscRes.hashMatch,
      packetsExchanged: mscRes.sie.packetTrace.length,
      gateEvaluations: mscRes.sie.sim.totalGateEvaluations,
      pinEvents: mscRes.sie.sim.totalPinEvents,
      setupHoldViolations: mscRes.sie.sim.timingViolations.length,
      cpuBudget: mscRes.driver.getBudgetMetrics()
    },
    lsHidKeyboard: {
      enumerated: hidRes.ok,
      vid: '0x435A',
      pid: '0x0001',
      scriptedKeystrokesSent: 100,
      keystrokesReceivedInOrder: hidRes.exactMatches,
      packetsExchanged: hidRes.sie.packetTrace.length,
      gateEvaluations: hidRes.sie.sim.totalGateEvaluations,
      pinEvents: hidRes.sie.sim.totalPinEvents,
      setupHoldViolations: hidRes.sie.sim.timingViolations.length,
      cpuBudget: hidRes.driver.getBudgetMetrics()
    },
    sampleWaveform: mscRes.line.waveform.slice(0, 140),
    samplePacketTrace: mscRes.sie.packetTrace.slice(0, 40)
  };
}

// ============================================================================
// TEST 4: Positive Controls That Must Fail (5 Netlist Mutants)
// ============================================================================
function runTest4Mutants() {
  const mutantDefs = [
    {
      id: 'crc16_tap_moved',
      description: 'U19_CRC16_XOR pin 2A rewired from CRC16_Q1 (x^2 tap) to CRC16_Q3 (x^4 tap)',
      deviceType: 'msc'
    },
    {
      id: 'bit_stuff_off_by_one',
      description: 'U12_STUFF_AND comparator rewired to trigger after 5 consecutive ones (0101) instead of 6 (0110)',
      deviceType: 'msc'
    },
    {
      id: 'nrzi_rx_inverted',
      description: 'U10_NRZI_INV receive inverter output bypassed/inverted so decoded NRZI bits are inverted',
      deviceType: 'msc'
    },
    {
      id: 'turnaround_short',
      description: 'U25_TURN_EOP_AND timeout comparator wired to TURN_Q1 (2 bit times) instead of 18 bit times',
      deviceType: 'msc'
    },
    {
      id: 'sof_missing',
      description: 'U30_SOF_GATE pin 1B tied to GND so 1 ms SOF / keep-alive frames are never transmitted',
      deviceType: 'hid'
    }
  ];

  const mutantResults = [];
  const survivingMutants = [];

  for (const m of mutantDefs) {
    const res = executeWorkload({
      useReference: false,
      delayCorner: 'max',
      mutant: m.id,
      deviceType: m.deviceType,
      fileSectorsToRead: 2,
      hidKeystrokesToRead: 10
    });
    const failedAsExpected = !res.ok;
    if (!failedAsExpected) {
      survivingMutants.push(m.id);
    }
    mutantResults.push({
      mutantId: m.id,
      description: m.description,
      workloadSucceeded: res.ok,
      killed: failedAsExpected,
      failureStage: res.stage,
      failureReason: res.reason || (res.frameAfterWait === 0 ? 'SOF_MISSING_DEVICE_SUSPENDED' : 'HASH_MISMATCH')
    });
  }

  return {
    testId: 4,
    name: 'Positive Controls That Must Fail (5 Netlist Mutants)',
    passed: survivingMutants.length === 0,
    totalMutants: mutantDefs.length,
    killedMutants: mutantDefs.length - survivingMutants.length,
    survivingMutants,
    mutants: mutantResults
  };
}

// ============================================================================
// TEST 5: Error Injection (Corrupted CRC, Stuffing Error, Dropped Handshake)
// ============================================================================
function runTest5ErrorInjection() {
  const res = executeWorkload({
    useReference: false,
    delayCorner: 'max',
    deviceType: 'msc',
    fileSectorsToRead: 4,
    errorInjections: [
      { type: 'corrupt_crc', onPid: USB_PIDS.DATA1 },
      { type: 'stuff_error', onPid: USB_PIDS.DATA0 },
      { type: 'drop_handshake', onPid: USB_PIDS.ACK }
    ]
  });

  const diagReg = res.sie.readReg(SIE_REGS.DIAG);
  const crcErrsDetected = diagReg & 0xFF;
  const stuffAndTimeoutDetected = (diagReg >> 8) & 0xFF;
  const retriesPerformed = res.driver.totalRetries;

  const passed =
    res.ok &&
    crcErrsDetected >= 1 &&
    stuffAndTimeoutDetected >= 2 &&
    retriesPerformed >= 3;

  return {
    testId: 5,
    name: 'Error Injection (Corrupted CRC16, Bit-Stuff Error, Dropped Handshake -> Retry & Recover)',
    passed,
    transferCompletedCleanlyAfterRetries: res.ok,
    injectedErrors: ['corrupt_crc (DATA1)', 'stuff_error (DATA0)', 'drop_handshake (ACK)'],
    hardwareCrcErrorsDetected: crcErrsDetected,
    hardwareStuffAndTimeoutErrorsDetected: stuffAndTimeoutDetected,
    driverRetriesExecuted: retriesPerformed,
    verifiedPayloadHash: res.actualHash
  };
}

// ============================================================================
// TEST 6: CPU Budget Analysis (10 µs per Register Access)
// ============================================================================
function runTest6CpuBudget(test3Result) {
  const mscBudget = test3Result.fsMassStorage.cpuBudget;
  const hidBudget = test3Result.lsHidKeyboard.cpuBudget;

  // Compute exact breakdown per 64-byte Bulk-IN packet:
  // 1x OUT TARGET (shared per endpoint or 1 per xfer) + 1x OUT CSR (START) + 1x IN CSR (STATUS)
  // + 1x IN LEN + 32x IN DATA16 (64 bytes across 16-bit port) = 36 accesses = 360 µs
  const bulkIn64ByteAccesses = 36;
  const bulkIn64ByteCpuUs = bulkIn64ByteAccesses * 10;

  // For 8-byte LS HID Interrupt IN report:
  // 1x OUT TARGET + 1x OUT CSR + 1x IN CSR + 1x IN LEN + 4x IN DATA16 = 8 accesses = 80 µs
  const hidReport8ByteAccesses = 8;
  const hidReport8ByteCpuUs = hidReport8ByteAccesses * 10;

  const passed =
    mscBudget.cpuTimeUsPerMsFrame > 0 &&
    mscBudget.cpuTimeUsPerMsFrame <= 1000 &&
    hidBudget.cpuTimeUsPerMsFrame > 0 &&
    hidBudget.cpuTimeUsPerMsFrame <= 1000;

  return {
    testId: 6,
    name: 'CPU Budget (Register Accesses per Transfer & CPU Time per 1 ms Frame at 10 µs/access)',
    passed,
    portAccessCostUs: 10,
    fsMassStorage64KBRun: mscBudget,
    lsHidKeyboard100KeysRun: hidBudget,
    single64ByteBulkInPacket: {
      regAccesses: bulkIn64ByteAccesses,
      cpuTimeUs: bulkIn64ByteCpuUs,
      wireTimeUs: 46.5
    },
    single8ByteLsHidReport: {
      regAccesses: hidReport8ByteAccesses,
      cpuTimeUs: hidReport8ByteCpuUs,
      wireTimeUs: 64.0
    }
  };
}

// ============================================================================
// TEST 7: Static Scan (No Forbidden Parts, No PC/Sequencer, Module Isolation)
// ============================================================================
function runTest7StaticScan() {
  const sim = new GateSimulator({ delayCorner: 'max' });
  buildSieNetlist(sim, null);

  const forbiddenPartsFound = [];
  for (const chip of sim.chips) {
    for (const pat of FORBIDDEN_PART_PATTERNS) {
      if (pat.test(chip.type) || pat.test(chip.id) || pat.test(chip.spec.partNumber)) {
        forbiddenPartsFound.push(`${chip.id}:${chip.type}`);
      }
    }
    if (!PARTS_CATALOG[chip.type]) {
      forbiddenPartsFound.push(`UNCATALOGED:${chip.type}`);
    }
  }

  // Scan simulator and netlist source files for forbidden imports (ref-sie, devices, driver)
  const isolatedFiles = ['src/parts-library.js', 'src/simulator.js', 'src/netlist.js'];
  const forbiddenImportPatterns = [
    /require\s*\(\s*['"][^'"]*(?:ref-sie|devices|driver)['"]\s*\)/g,
    /import\s+.*from\s+['"][^'"]*(?:ref-sie|devices|driver)['"]/g
  ];
  const forbiddenImportsFound = [];
  for (const rel of isolatedFiles) {
    const src = fs.readFileSync(path.join(ROOT_DIR, rel), 'utf8');
    for (const pat of forbiddenImportPatterns) {
      const m = src.match(pat);
      if (m) {
        forbiddenImportsFound.push({ file: rel, matches: m });
      }
    }
  }

  const passed = forbiddenPartsFound.length === 0 && forbiddenImportsFound.length === 0;

  return {
    testId: 7,
    name: 'Static Scan (No Forbidden Parts & Simulator Module Isolation)',
    passed,
    totalNetlistChipsScanned: sim.chips.length,
    forbiddenPartsFound,
    isolatedModulesScanned: isolatedFiles,
    forbiddenImportsFound
  };
}

// ============================================================================
// TEST 8: Determinism (Fixed Seeds -> Byte-Identical Traces)
// ============================================================================
function runTest8Determinism() {
  const run1 = executeWorkload({ useReference: false, delayCorner: 'max', deviceType: 'msc', fileSectorsToRead: 8 });
  const run2 = executeWorkload({ useReference: false, delayCorner: 'max', deviceType: 'msc', fileSectorsToRead: 8 });

  const trace1Json = JSON.stringify({
    packets: run1.sie.packetTrace,
    regs: run1.sie.regTrace,
    wave: run1.line.waveform
  });
  const trace2Json = JSON.stringify({
    packets: run2.sie.packetTrace,
    regs: run2.sie.regTrace,
    wave: run2.line.waveform
  });

  const sha1 = sha256Hex(trace1Json);
  const sha2 = sha256Hex(trace2Json);
  const passed = run1.ok && run2.ok && sha1 === sha2 && trace1Json === trace2Json;

  return {
    testId: 8,
    name: 'Determinism (Fixed Seeds Produce Byte-Identical Wire & Register Traces)',
    passed,
    seedMsc: 20261118,
    seedHid: 42,
    traceBytes: Buffer.byteLength(trace1Json, 'utf8'),
    run1Sha256: sha1,
    run2Sha256: sha2,
    byteIdentical: sha1 === sha2
  };
}

function runAllTestsAndWriteJsonl(outputJsonlPath) {
  const startWallMs = Date.now();
  const codeHashes = computeCodeHashes();

  const simForBom = new GateSimulator({ delayCorner: 'max' });
  buildSieNetlist(simForBom, null);
  const hwAnalysis = analyzeNetlistBomAndTiming(simForBom, 0.25);

  const t1 = runTest1Differential();
  const t2 = runTest2Corners();
  const t3 = runTest3Enumeration();
  const t4 = runTest4Mutants();
  const t5 = runTest5ErrorInjection();
  const t6 = runTest6CpuBudget(t3);
  const t7 = runTest7StaticScan();
  const t8 = runTest8Determinism();

  const tests = [t1, t2, t3, t4, t5, t6, t7, t8];
  const allPassed = tests.every(t => t.passed);
  const elapsedMs = Date.now() - startWallMs;

  const records = [
    {
      recordType: 'meta',
      timestamp: '2026-11-18T09:01:58-05:00',
      project: 'Bare USB: Discrete-Logic USB 1.1 Host SIE Gate-Level Simulator',
      allTestsPassed: allPassed,
      elapsedWallTimeMs: elapsedMs,
      codeHashes
    },
    {
      recordType: 'hardware_bom_and_timing',
      totalChips: hwAnalysis.totalChips,
      totalCostUsd: hwAnalysis.totalCostUsd,
      bom: hwAnalysis.bom,
      criticalPaths: hwAnalysis.criticalPaths
    },
    ...tests.map(t => ({
      recordType: 'test_result',
      ...t
    }))
  ];

  const lines = records.map(r => JSON.stringify(r)).join('\n') + '\n';
  fs.writeFileSync(outputJsonlPath, lines, 'utf8');
  return { records, allPassed, elapsedMs, hwAnalysis, tests, codeHashes };
}

if (require.main === module) {
  const outPath = process.argv[2] || path.join(ROOT_DIR, 'results.jsonl');
  const summary = runAllTestsAndWriteJsonl(outPath);
  console.log(`Wrote ${summary.records.length} records to ${outPath} in ${summary.elapsedMs} ms (allPassed=${summary.allPassed})`);
  for (const t of summary.tests) {
    console.log(`  [Test ${t.testId}] ${t.passed ? 'PASS' : 'FAIL'} — ${t.name}`);
  }
  if (!summary.allPassed) process.exit(1);
}

module.exports = {
  runAllTestsAndWriteJsonl
};

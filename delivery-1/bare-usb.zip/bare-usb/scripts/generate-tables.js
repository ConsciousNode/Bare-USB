/**
 * Bare USB — Lookup Table Generator for Shadowed 10 ns SRAM (IS61WV5128EDBLL-10TLI)
 * ConsciousNode SoftWorks — Disclosed per SPEC.md ("If the next-state logic is a lookup table
 * in SRAM or flash, disclose it and give the table's contents a generating script.")
 *
 * Provenance:
 * - Follows `PARTS.md` Decision 3 & 4 (Kehai Interim, 2026-11-18):
 *   "Every lookup table lives in 10 ns SRAM, loaded at power-up" from SST39SF040 parallel flash
 *   by a hardware counter copy-engine (74LVC161 counters + 74LVC138 decoder, no program counter).
 *
 * What these tables compute:
 * 1. `fsmLut` (U_LUT_FSM_LO / U_LUT_FSM_HI, 4096 x 16-bit):
 *    Pure combinational Moore/Mealy next-state and control-strobe decode table for the USB 1.1
 *    Host Serial Interface Engine (SIE) state register (`U_FSM_STATE`, 74LVC574A).
 *    Address inputs A[11:0]:
 *      - A[3:0]  : Current 4-bit SIE state `STATE[3:0]` (from U_FSM_STATE 74LVC574A)
 *      - A[5:4]  : Transaction type `XFER_TYPE[1:0]` (0=SETUP, 1=OUT, 2=IN, 3=SOF)
 *      - A[6]    : `START_OR_SOF` (CPU start pulse or 1 ms SOF trigger)
 *      - A[7]    : `BYTE_DONE` (8 bits shifted by U_BIT_CNT 74LVC161)
 *      - A[8]    : `LEN_DONE` (payload byte counter reached terminal count)
 *      - A[9]    : `RX_ACTIVE` (carrier/SYNC detected by DPLL)
 *      - A[10]   : `EOP_SE0` (2-bit SE0 + J EOP detected by U_EOP_DET)
 *      - A[11]   : `TURN_TIMEOUT_OR_ERR` (18-bit turnaround timer expired or CRC/stuff error)
 *    Data outputs D[15:0]:
 *      - D[3:0]  : `NEXT_STATE[3:0]` latched into U_FSM_STATE on next clock edge
 *      - D[4]    : `TX_OE` (enable USB1T11A driver onto D+/D-)
 *      - D[5]    : `TX_LOAD_SYNC` (load 0x80 SYNC pattern into U_TX_SR 74LVC165A)
 *      - D[6]    : `TX_LOAD_PID` (load PID | (~PID << 4) byte)
 *      - D[7]    : `TX_LOAD_DATA` (load payload byte from U_BUF_SRAM)
 *      - D[8]    : `TX_LOAD_CRC` (shift out CRC5 or CRC16 remainder)
 *      - D[9]    : `TX_SEND_EOP` (drive SE0 for 2 bit times then J for 1 bit time)
 *      - D[10]   : `RX_CAPTURE_EN` (enable RX shift register U_RX_SR 74LVC595A & unstuffing)
 *      - D[11]   : `BUF_WE` (write received byte into U_BUF_SRAM and increment address)
 *      - D[12]   : `CRC_CHECK_EN` (latch CRC5/CRC16 residual check at EOP)
 *      - D[13]   : `TURN_TIMER_EN` (enable 74LVC161 bus turnaround counter)
 *      - D[14]   : `AUTO_ACK_TRIG` (trigger automatic ACK packet after clean IN DATA packet)
 *      - D[15]   : `XFER_DONE_IRQ` (latch DONE status and assert level-triggered IRQ to CPU)
 *
 * 2. `pidCheckLut` (256 x 8-bit):
 *    Combinational decode of an 8-bit USB PID byte (`PID[3:0]` and `~PID[7:4]`), returning:
 *      - Bit 0: `PID_VALID` (`(b & 0x0F) === ((~b >> 4) & 0x0F)`)
 *      - Bit 1: `IS_TOKEN` (OUT, IN, SOF, SETUP)
 *      - Bit 2: `IS_DATA` (DATA0, DATA1)
 *      - Bit 3: `IS_HANDSHAKE` (ACK, NAK, STALL)
 *      - Bits 7..4: Canonical 4-bit PID code
 */

'use strict';

const crypto = require('crypto');

const SIE_STATES = {
  IDLE:           0x0,
  TX_SYNC:        0x1,
  TX_PID:         0x2,
  TX_TOKEN_B0:    0x3,
  TX_TOKEN_B1:    0x4,
  TX_EOP:         0x5,
  TX_DATA_SYNC:   0x6,
  TX_DATA_PID:    0x7,
  TX_DATA_PAYLOAD:0x8,
  TX_DATA_CRC_LO: 0x9,
  TX_DATA_CRC_HI: 0xA,
  TX_DATA_EOP:    0xB,
  WAIT_RX_SYNC:   0xC,
  RX_PID:         0xD,
  RX_DATA_OR_HS:  0xE,
  TX_AUTO_ACK:    0xF
};

function generateFsmLut() {
  const table = new Uint16Array(4096);

  for (let addr = 0; addr < 4096; addr++) {
    const state        = addr & 0x0F;
    const xferType     = (addr >> 4) & 0x03; // 0=SETUP, 1=OUT, 2=IN, 3=SOF
    const startOrSof   = (addr >> 6) & 0x01;
    const byteDone     = (addr >> 7) & 0x01;
    const lenDone      = (addr >> 8) & 0x01;
    const rxActive     = (addr >> 9) & 0x01;
    const eopSe0       = (addr >> 10) & 0x01;
    const timeoutOrErr = (addr >> 11) & 0x01;

    let nextState = state;
    let ctrl = 0;

    const TX_OE         = 1 << 4;
    const TX_LOAD_SYNC  = 1 << 5;
    const TX_LOAD_PID   = 1 << 6;
    const TX_LOAD_DATA  = 1 << 7;
    const TX_LOAD_CRC   = 1 << 8;
    const TX_SEND_EOP   = 1 << 9;
    const RX_CAPTURE_EN = 1 << 10;
    const BUF_WE        = 1 << 11;
    const CRC_CHECK_EN  = 1 << 12;
    const TURN_TIMER_EN = 1 << 13;
    const AUTO_ACK_TRIG = 1 << 14;
    const XFER_DONE_IRQ = 1 << 15;

    switch (state) {
      case SIE_STATES.IDLE:
        if (startOrSof) {
          nextState = SIE_STATES.TX_SYNC;
          ctrl = TX_OE | TX_LOAD_SYNC;
        }
        break;

      case SIE_STATES.TX_SYNC:
        ctrl = TX_OE;
        if (byteDone) {
          nextState = SIE_STATES.TX_PID;
          ctrl |= TX_LOAD_PID;
        }
        break;

      case SIE_STATES.TX_PID:
        ctrl = TX_OE;
        if (byteDone) {
          nextState = SIE_STATES.TX_TOKEN_B0;
          ctrl |= TX_LOAD_DATA;
        }
        break;

      case SIE_STATES.TX_TOKEN_B0:
        ctrl = TX_OE;
        if (byteDone) {
          nextState = SIE_STATES.TX_TOKEN_B1;
          ctrl |= TX_LOAD_CRC;
        }
        break;

      case SIE_STATES.TX_TOKEN_B1:
        ctrl = TX_OE;
        if (byteDone) {
          nextState = SIE_STATES.TX_EOP;
          ctrl |= TX_SEND_EOP;
        }
        break;

      case SIE_STATES.TX_EOP:
        ctrl = TX_OE | TX_SEND_EOP;
        if (eopSe0) {
          if (xferType === 3) {
            // SOF complete
            nextState = SIE_STATES.IDLE;
            ctrl = XFER_DONE_IRQ;
          } else if (xferType === 0 || xferType === 1) {
            // SETUP or OUT -> immediately send DATA0/DATA1 packet
            nextState = SIE_STATES.TX_DATA_SYNC;
            ctrl = TX_OE | TX_LOAD_SYNC;
          } else {
            // IN -> wait for device response within turnaround window
            nextState = SIE_STATES.WAIT_RX_SYNC;
            ctrl = TURN_TIMER_EN;
          }
        }
        break;

      case SIE_STATES.TX_DATA_SYNC:
        ctrl = TX_OE;
        if (byteDone) {
          nextState = SIE_STATES.TX_DATA_PID;
          ctrl |= TX_LOAD_PID;
        }
        break;

      case SIE_STATES.TX_DATA_PID:
        ctrl = TX_OE;
        if (byteDone) {
          if (lenDone) {
            nextState = SIE_STATES.TX_DATA_CRC_LO;
            ctrl |= TX_LOAD_CRC;
          } else {
            nextState = SIE_STATES.TX_DATA_PAYLOAD;
            ctrl |= TX_LOAD_DATA;
          }
        }
        break;

      case SIE_STATES.TX_DATA_PAYLOAD:
        ctrl = TX_OE;
        if (byteDone) {
          if (lenDone) {
            nextState = SIE_STATES.TX_DATA_CRC_LO;
            ctrl |= TX_LOAD_CRC;
          } else {
            nextState = SIE_STATES.TX_DATA_PAYLOAD;
            ctrl |= TX_LOAD_DATA;
          }
        }
        break;

      case SIE_STATES.TX_DATA_CRC_LO:
        ctrl = TX_OE | TX_LOAD_CRC;
        if (byteDone) {
          nextState = SIE_STATES.TX_DATA_CRC_HI;
        }
        break;

      case SIE_STATES.TX_DATA_CRC_HI:
        ctrl = TX_OE | TX_LOAD_CRC;
        if (byteDone) {
          nextState = SIE_STATES.TX_DATA_EOP;
          ctrl = TX_OE | TX_SEND_EOP;
        }
        break;

      case SIE_STATES.TX_DATA_EOP:
        ctrl = TX_OE | TX_SEND_EOP;
        if (eopSe0) {
          nextState = SIE_STATES.WAIT_RX_SYNC;
          ctrl = TURN_TIMER_EN;
        }
        break;

      case SIE_STATES.WAIT_RX_SYNC:
        ctrl = TURN_TIMER_EN;
        if (timeoutOrErr) {
          nextState = SIE_STATES.IDLE;
          ctrl = XFER_DONE_IRQ;
        } else if (rxActive) {
          nextState = SIE_STATES.RX_PID;
          ctrl = RX_CAPTURE_EN;
        }
        break;

      case SIE_STATES.RX_PID:
        ctrl = RX_CAPTURE_EN;
        if (timeoutOrErr) {
          nextState = SIE_STATES.IDLE;
          ctrl = XFER_DONE_IRQ;
        } else if (byteDone) {
          nextState = SIE_STATES.RX_DATA_OR_HS;
        }
        break;

      case SIE_STATES.RX_DATA_OR_HS:
        ctrl = RX_CAPTURE_EN | (byteDone ? BUF_WE : 0);
        if (timeoutOrErr) {
          nextState = SIE_STATES.IDLE;
          ctrl = XFER_DONE_IRQ;
        } else if (eopSe0) {
          if (xferType === 2) {
            // IN transfer: check CRC16 and send auto-ACK if clean DATA packet
            nextState = SIE_STATES.TX_AUTO_ACK;
            ctrl = CRC_CHECK_EN | AUTO_ACK_TRIG;
          } else {
            // SETUP / OUT handshake received
            nextState = SIE_STATES.IDLE;
            ctrl = XFER_DONE_IRQ;
          }
        }
        break;

      case SIE_STATES.TX_AUTO_ACK:
        ctrl = TX_OE | AUTO_ACK_TRIG;
        if (eopSe0 || timeoutOrErr) {
          nextState = SIE_STATES.IDLE;
          ctrl = XFER_DONE_IRQ;
        }
        break;
    }

    table[addr] = (nextState & 0x0F) | ctrl;
  }

  return table;
}

function generatePidCheckLut() {
  const table = new Uint8Array(256);
  for (let b = 0; b < 256; b++) {
    const pid = b & 0x0F;
    const npid = (b >> 4) & 0x0F;
    const valid = ((pid ^ npid) === 0x0F) ? 1 : 0;
    const isToken = (pid === 0x1 || pid === 0x9 || pid === 0x5 || pid === 0xD) ? 1 : 0;
    const isData = (pid === 0x3 || pid === 0xB) ? 1 : 0;
    const isHs = (pid === 0x2 || pid === 0xA || pid === 0xE) ? 1 : 0;
    table[b] = valid | (isToken << 1) | (isData << 2) | (isHs << 3) | (pid << 4);
  }
  return table;
}

function computeTablesDigest() {
  const fsm = generateFsmLut();
  const pid = generatePidCheckLut();
  const hash = crypto.createHash('sha256');
  hash.update(Buffer.from(fsm.buffer));
  hash.update(Buffer.from(pid.buffer));
  return {
    fsmEntries: fsm.length,
    fsmBytes: fsm.byteLength,
    pidEntries: pid.length,
    pidBytes: pid.byteLength,
    totalBytes: fsm.byteLength + pid.byteLength,
    sha256: hash.digest('hex')
  };
}

if (require.main === module) {
  const info = computeTablesDigest();
  console.log(JSON.stringify(info, null, 2));
}

module.exports = {
  SIE_STATES,
  generateFsmLut,
  generatePidCheckLut,
  computeTablesDigest
};

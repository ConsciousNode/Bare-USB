/**
 * Bare USB — Static Timing Analyzer (`src/sta.js`)
 * ConsciousNode SoftWorks — Zero dependencies, offline.
 *
 * Analyzes all CLK_48M -> CLK_48M synchronous paths in the gate-level netlist
 * at min, typ, and max datasheet delay corners against T = 20.781 ns (48.120 MHz, +0.25%).
 */

'use strict';

const { PARTS_CATALOG } = require('./parts-library');

const COMB_OUTPUT_PINS = {
  '74LVC04A':  ['1Y', '2Y', '3Y', '4Y', '5Y', '6Y'],
  '74LVC08A':  ['1Y', '2Y', '3Y', '4Y'],
  '74LVC32A':  ['1Y', '2Y', '3Y', '4Y'],
  '74LVC86A':  ['1Y', '2Y', '3Y', '4Y'],
  '74LVC157A': ['1Y', '2Y', '3Y', '4Y'],
  '74LVC138A': ['Y0_N', 'Y1_N', 'Y2_N', 'Y3_N', 'Y4_N', 'Y5_N', 'Y6_N', 'Y7_N'],
  '74LVC245A': ['B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8']
};

const COMB_PIN_DEPS = {
  '74LVC04A':  { '1Y': ['1A'], '2Y': ['2A'], '3Y': ['3A'], '4Y': ['4A'], '5Y': ['5A'], '6Y': ['6A'] },
  '74LVC08A':  { '1Y': ['1A', '1B'], '2Y': ['2A', '2B'], '3Y': ['3A', '3B'], '4Y': ['4A', '4B'] },
  '74LVC32A':  { '1Y': ['1A', '1B'], '2Y': ['2A', '2B'], '3Y': ['3A', '3B'], '4Y': ['4A', '4B'] },
  '74LVC86A':  { '1Y': ['1A', '1B'], '2Y': ['2A', '2B'], '3Y': ['3A', '3B'], '4Y': ['4A', '4B'] },
  '74LVC157A': {
    '1Y': ['S', 'G_N', '1I0', '1I1'],
    '2Y': ['S', 'G_N', '2I0', '2I1'],
    '3Y': ['S', 'G_N', '3I0', '3I1'],
    '4Y': ['S', 'G_N', '4I0', '4I1']
  },
  '74LVC138A': {
    'Y0_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y1_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y2_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y3_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y4_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y5_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y6_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N'],
    'Y7_N': ['A', 'B', 'C', 'G1', 'G2A_N', 'G2B_N']
  }
};

function getPartDelay(type, corner, isTc = false) {
  const spec = PARTS_CATALOG[type];
  if (!spec) return 0;
  const min = isTc && spec.tpdTcMinNs != null ? spec.tpdTcMinNs : spec.tpdMinNs;
  const max = isTc && spec.tpdTcMaxNs != null ? spec.tpdTcMaxNs : spec.tpdMaxNs;
  if (corner === 'min') return min;
  if (corner === 'typ') return (min + max) * 0.5;
  return max;
}

function analyzeStaticTiming(sim, { corner = 'max', periodNs = 20.781 } = {}) {
  const arrival = new Map();
  const prevArc = new Map();
  const endpoints = [];
  const combEdges = []; // { inNet, outNet, delay, chipId, type }

  for (const chip of sim.chips) {
    const pm = chip.pinMap || {};
    const t = chip.type;
    const spec = PARTS_CATALOG[t];

    // 1. CLK_48M sequential launches and endpoints
    if (t === '74LVC574A' && pm.CLK === 'CLK_48M') {
      const cq = getPartDelay(t, corner);
      for (let i = 0; i < 8; i++) {
        const qn = pm['Q' + i];
        if (qn && qn !== 'VCC' && qn !== 'GND') {
          if (!arrival.has(qn) || cq > arrival.get(qn)) {
            arrival.set(qn, cq);
            prevArc.set(qn, { src: null, chipId: chip.id, type: t, delay: cq });
          }
        }
        const dn = pm['D' + i];
        if (dn && dn !== 'VCC' && dn !== 'GND') {
          endpoints.push({ chipId: chip.id, type: t, pin: 'D' + i, net: dn, tSetupNs: spec.tSetupNs || 2.0 });
        }
      }
      continue;
    }

    if (t === '74LVC74A') {
      const cq = getPartDelay(t, corner);
      for (const h of ['1', '2']) {
        if (pm[h + 'CLK'] === 'CLK_48M') {
          for (const qp of [h + 'Q', h + 'Q_N']) {
            const qn = pm[qp];
            if (qn && qn !== 'VCC' && qn !== 'GND') {
              if (!arrival.has(qn) || cq > arrival.get(qn)) {
                arrival.set(qn, cq);
                prevArc.set(qn, { src: null, chipId: chip.id, type: t, delay: cq });
              }
            }
          }
          const dn = pm[h + 'D'];
          if (dn && dn !== 'VCC' && dn !== 'GND') {
            endpoints.push({ chipId: chip.id, type: t, pin: h + 'D', net: dn, tSetupNs: spec.tSetupNs || 2.0 });
          }
        }
      }
      continue;
    }

    if (t === '74LVC161' && pm.CP === 'CLK_48M') {
      const cq = getPartDelay(t, corner);
      const tc = getPartDelay(t, corner, true);
      for (let i = 0; i < 4; i++) {
        const qn = pm['Q' + i];
        if (qn && qn !== 'VCC' && qn !== 'GND') {
          if (!arrival.has(qn) || cq > arrival.get(qn)) {
            arrival.set(qn, cq);
            prevArc.set(qn, { src: null, chipId: chip.id, type: t, delay: cq });
          }
        }
      }
      if (pm.TC && pm.TC !== 'VCC' && pm.TC !== 'GND') {
        if (!arrival.has(pm.TC) || tc > arrival.get(pm.TC)) {
          arrival.set(pm.TC, tc);
          prevArc.set(pm.TC, { src: null, chipId: chip.id, type: t, delay: tc });
        }
        // CET -> TC combinational arc on 74LVC161
        if (pm.CET && pm.CET !== 'VCC' && pm.CET !== 'GND') {
          combEdges.push({ inNet: pm.CET, outNet: pm.TC, delay: tc, chipId: chip.id, type: t + '(CET->TC)' });
        }
      }
      for (const ep of ['PE_N', 'CEP', 'CET', 'D0', 'D1', 'D2', 'D3']) {
        const dn = pm[ep];
        if (dn && dn !== 'VCC' && dn !== 'GND') {
          endpoints.push({ chipId: chip.id, type: t, pin: ep, net: dn, tSetupNs: spec.tSetupNs || 2.5 });
        }
      }
      continue;
    }

    // 2. Combinational logic gates
    if (COMB_PIN_DEPS[t]) {
      const dly = getPartDelay(t, corner);
      for (const [outPin, inPins] of Object.entries(COMB_PIN_DEPS[t])) {
        const outNet = pm[outPin];
        if (!outNet || outNet === 'VCC' || outNet === 'GND') continue;
        for (const inPin of inPins) {
          const inNet = pm[inPin];
          if (!inNet || inNet === 'VCC' || inNet === 'GND') continue;
          combEdges.push({ inNet, outNet, delay: dly, chipId: chip.id, type: t });
        }
      }
      continue;
    }

    // 3. Read-only SRAM LUTs (IS61WV5128EDBLL with WE_N === 'VCC')
    if (t === 'IS61WV5128EDBLL' && pm.WE_N === 'VCC') {
      const dly = getPartDelay(t, corner);
      const addrNets = [];
      for (let i = 0; i < 19; i++) {
        const an = pm['A' + i];
        if (an && an !== 'VCC' && an !== 'GND') addrNets.push(an);
      }
      for (let i = 0; i < 8; i++) {
        const outNet = pm['IO' + i];
        if (!outNet || outNet === 'VCC' || outNet === 'GND') continue;
        for (const inNet of addrNets) {
          combEdges.push({ inNet, outNet, delay: dly, chipId: chip.id, type: t });
        }
      }
    }
  }

  // Bellman-Ford relaxation (up to 40 hops)
  const MAX_HOPS = 40;
  for (let iter = 0; iter < MAX_HOPS; iter++) {
    let changed = false;
    for (const e of combEdges) {
      if (!arrival.has(e.inNet)) continue;
      const cand = arrival.get(e.inNet) + e.delay;
      const cur = arrival.has(e.outNet) ? arrival.get(e.outNet) : -1;
      if (cand > cur + 1e-9) {
        arrival.set(e.outNet, cand);
        prevArc.set(e.outNet, { src: e.inNet, chipId: e.chipId, type: e.type, delay: e.delay });
        changed = true;
      }
    }
    if (!changed) break;
  }

  function tracePath(net) {
    const chain = [];
    const seen = new Set();
    let cur = net;
    while (cur && !seen.has(cur) && chain.length < 30) {
      seen.add(cur);
      const arc = prevArc.get(cur);
      if (!arc) break;
      chain.push(`${arc.chipId}(${cur}:${arc.delay.toFixed(1)}ns)`);
      cur = arc.src;
    }
    return chain.reverse().join(' -> ');
  }

  const results = [];
  let failingEndpoints = 0;
  let worstArrivalNs = 0;
  let worstSlackNs = Infinity;

  for (const ep of endpoints) {
    if (!arrival.has(ep.net)) continue;
    const arr = arrival.get(ep.net);
    const req = periodNs - ep.tSetupNs;
    const slack = req - arr;
    if (arr > worstArrivalNs) worstArrivalNs = arr;
    if (slack < worstSlackNs) worstSlackNs = slack;
    const failed = slack < -1e-6;
    if (failed) failingEndpoints++;
    results.push({
      endpoint: `${ep.chipId}.${ep.pin} (${ep.net})`,
      arrivalNs: +arr.toFixed(3),
      requiredNs: +req.toFixed(3),
      slackNs: +slack.toFixed(3),
      failed,
      path: failed ? tracePath(ep.net) : null
    });
  }

  results.sort((a, b) => a.slackNs - b.slackNs);
  return {
    corner,
    periodNs,
    passed: failingEndpoints === 0,
    totalEndpoints: results.length,
    failingEndpoints,
    worstArrivalNs: +worstArrivalNs.toFixed(3),
    worstSlackNs: Number.isFinite(worstSlackNs) ? +worstSlackNs.toFixed(3) : null,
    topFailingPaths: results.filter(r => r.failed).slice(0, 8)
  };
}

module.exports = { analyzeStaticTiming };
